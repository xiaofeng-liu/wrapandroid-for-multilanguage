#include "SRPWrapAndroidEngine_VSDHeader.h"

static class ClassOfSRPInterface *SRPInterface;
static void *StarActivity;
static void *mInflater;

static VS_INT32 MyButton_onClick(VS_ULONG FunctionChoice,void *EventPara)
{
	void *toast = SRPInterface->MallocObjectL(&VSOBJID_ToastClass,0,NULL);
	SRPInterface -> ScriptCall(toast,NULL,"makeText","(si)","Button is click", 0);
	SRPInterface -> ScriptCall(toast,NULL,"show","()");
    return 0;
}

static VS_INT32 SRPAPI MyAdapter_getCount(void *Object)
{
	return 20;
}

static VS_INT32 SRPAPI MyAdapter_getItem(void *Object,VS_INT32 Position)
{
	return Position;
}	
static VS_LONG SRPAPI MyAdapter_getItemId(void *Object,VS_INT32 Position)
{
	return Position;
}	
	
static VS_OBJPTR SRPAPI MyAdapter_getView(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent)
{
	void *i;
	struct MyHolder{
		void *img;
		void *title;
		void *info;
		void *view_btn;
	}*holder;
	
	if( convertView == NULL ){		
		int vlist2 = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","layout/vlist2");
        convertView = (void *)SRPInterface -> ScriptCall(mInflater,NULL,"inflate","(sio)o","LinearLayoutClass",vlist2, NULL);
        holder = (struct MyHolder *)SRPInterface -> MallocPrivateBuf(convertView,SRPInterface -> GetLayer(convertView),0,sizeof(struct MyHolder));

		int img = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/img");
        holder -> img = (void *)SRPInterface -> ScriptCall(convertView,NULL,"findViewById","(si)o","ImageViewClass", img);

		int title = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/title");
        holder -> title = (void *)SRPInterface -> ScriptCall(convertView,NULL,"findViewById","(si)o","TextViewClass", title);
        
		int info = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/info");
        holder -> info = (void *)SRPInterface -> ScriptCall(convertView,NULL,"findViewById","(si)o","TextViewClass", info);

		int view_btn = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/view_btn");
        holder -> view_btn = (void *)SRPInterface -> ScriptCall(convertView,NULL,"findViewById","(si)o","ButtonClass", view_btn);
	}else{
		holder = (struct MyHolder *)SRPInterface -> GetPrivateBuf(convertView,SRPInterface -> GetLayer(convertView),0,NULL);
	}
	int resid;
	switch( position % 3 ){
	case 0 : 
		resid = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","drawable/i1");
		SRPInterface -> ScriptCall(holder -> img,NULL,"setBackgroundResource","(i)",resid);
		SRPInterface -> ScriptCall(holder -> title,NULL,"setText","(s)","G1");
		SRPInterface -> ScriptCall(holder -> info,NULL,"setText","(s)","google 1");
		break;
	case 1 : 
		resid = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","drawable/i2");
		SRPInterface -> ScriptCall(holder -> img,NULL,"setBackgroundResource","(i)",resid);
		SRPInterface -> ScriptCall(holder -> title,NULL,"setText","(s)","G2");
		SRPInterface -> ScriptCall(holder -> info,NULL,"setText","(s)","google 2");
		break;
	case 2 : 
		resid = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","drawable/i3");
		SRPInterface -> ScriptCall(holder -> img,NULL,"setBackgroundResource","(i)",resid);
		SRPInterface -> ScriptCall(holder -> title,NULL,"setText","(s)","G3");
		SRPInterface -> ScriptCall(holder -> info,NULL,"setText","(s)","google 3");
		break;
	}
	SRPInterface -> RegEventFunction(holder -> view_btn,&VSOUTEVENTID_ViewClass_onClick,holder -> view_btn,(void *)MyButton_onClick,0);
	SRPInterface -> ScriptCall(holder -> view_btn,NULL,"setOnClickListener","()");
    return convertView;    
}

VS_BOOL StarCoreService_Init(class ClassOfStarCore *starcore)
{
	class ClassOfBasicSRPInterface *BasicSRPInterface;
	
	//--init star core
	BasicSRPInterface = starcore ->GetBasicInterface();	
	SRPInterface = BasicSRPInterface ->GetSRPInterface(BasicSRPInterface->QueryActiveService(NULL),"","");
		
	void *ActivityClass;
	ActivityClass = SRPInterface -> GetObjectEx(NULL,"ActivityClass");
	StarActivity = (void *)SRPInterface -> ScriptCall(ActivityClass,NULL,"getCurrent","()O");
	SRPInterface -> Print("Get Main Activity = %s", SRPInterface -> GetName(StarActivity));	
	
	//--create AbsoluteLayout        
    void *MyLayout = SRPInterface->MallocObject(StarActivity,VSATTRINDEX_ACTIVITYCLASS_VIEWGROUPQUEUE,&VSOBJID_AbsoluteLayoutClass,0,NULL);    
        
    mInflater = SRPInterface->MallocObjectL(&VSOBJID_LayoutInflaterClass,0,NULL);
    	
    void *MyAdapter = SRPInterface->MallocObjectL(&VSOBJID_BaseAdapterClass,0,NULL);
    SRPInterface -> CreateOVLFunction(MyAdapter,&VSFUNCID_BaseAdapterClass_getCount,(void *)MyAdapter_getCount,NULL);
    SRPInterface -> CreateOVLFunction(MyAdapter,&VSFUNCID_BaseAdapterClass_getItem,(void *)MyAdapter_getItem,NULL);
    SRPInterface -> CreateOVLFunction(MyAdapter,&VSFUNCID_BaseAdapterClass_getItemId,(void *)MyAdapter_getItemId,NULL);
    SRPInterface -> CreateOVLFunction(MyAdapter,&VSFUNCID_BaseAdapterClass_getView,(void *)MyAdapter_getView,NULL);

    void *MyListView = SRPInterface->MallocObject(MyLayout,VSATTRINDEX_VIEWGROUPCLASS_VIEWQUEUE,&VSOBJID_ListViewClass,0,NULL);
    SRPInterface -> ScriptCall(MyListView,NULL,"setAbsoluteLayoutParams","(iiii)",FILL_PARENT,FILL_PARENT,0,0);
    SRPInterface -> ScriptCall(MyListView,NULL,"setAdapter","(o)",MyAdapter);

	return VS_TRUE;
}

void StarCoreService_Term(class ClassOfStarCore *starcore)
{
	SRPInterface -> Release();
	return;
}
/*--------------------------------------------------*/
/*VirtualSociety System ServiceModuleTemplate Header File*/
/*CreateBy SRPLab                */
/*CreateDate: 2012-6-10  */
/*--------------------------------------------------*/
#ifndef SRPWRAPANDROIDENGINE_HEADERFILE
#define SRPWRAPANDROIDENGINE_HEADERFILE

#include "SRPWrapAndroidEngine.h"

#if( VS_OS_TYPE == VS_OS_WINDOWS )
#pragma warning (disable:4819)
#pragma warning (disable:4244)
#pragma warning (disable:4996)
#pragma warning (disable:4800)
#endif

#pragma pack(4)

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LOCATIONMANAGERCLASS                                                             "LocationManagerClass"
extern VS_UUID VSOBJID_LocationManagerClass;
#define VSATTRDEPEND_LOCATIONMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LOCATIONMANAGERCLASS                                                       2
extern VS_INT32 SRPCALLBACK LocationManagerClass_RequestRegisterObject( );

/*----output event: onGpsStatusChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onGpsStatusChanged;
/*----output event: onNmeaReceived[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onNmeaReceived;
/*----output event: onLocationChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onLocationChanged;
/*----output event: onProviderDisabled[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onProviderDisabled;
/*----output event: onProviderEnabled[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onProviderEnabled;
/*----output event: onStatusChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_LocationManagerClass_onStatusChanged;

/*------Variable Index Define */
#define VSATTRINDEX_LOCATIONMANAGERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_LOCATIONMANAGERCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_LOCATIONMANAGERCLASS                                                          2

struct StructOfAttachLocationManagerClass{
};
struct StructOfLocationManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWGROUP_LAYOUTPARAMSCLASS                                                      "ViewGroup_LayoutParamsClass"
extern VS_UUID VSOBJID_ViewGroup_LayoutParamsClass;
#define VSATTRDEPEND_VIEWGROUP_LAYOUTPARAMSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIEWGROUP_LAYOUTPARAMSCLASS                                                2
extern VS_INT32 SRPCALLBACK ViewGroup_LayoutParamsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWGROUP_LAYOUTPARAMSCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_VIEWGROUP_LAYOUTPARAMSCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_VIEWGROUP_LAYOUTPARAMSCLASS                                                   2

struct StructOfAttachViewGroup_LayoutParamsClass{
};
struct StructOfViewGroup_LayoutParamsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TOGGLEBUTTONCLASS                                                                "ToggleButtonClass"
extern VS_UUID VSOBJID_ToggleButtonClass;
#define VSATTRDEPEND_TOGGLEBUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TOGGLEBUTTONCLASS                                                          2
extern VS_INT32 SRPCALLBACK ToggleButtonClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TOGGLEBUTTONCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_TOGGLEBUTTONCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_TOGGLEBUTTONCLASS                                                             2

struct StructOfAttachToggleButtonClass{
};
struct StructOfToggleButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWSWITCHERCLASS                                                                "ViewSwitcherClass"
extern VS_UUID VSOBJID_ViewSwitcherClass;
#define VSATTRDEPEND_VIEWSWITCHERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_VIEWSWITCHERCLASS                                                          5
extern VS_INT32 SRPCALLBACK ViewSwitcherClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWSWITCHERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_VIEWSWITCHERCLASS_OBJECTLIST                                                   1
#define VSATTRINDEX_VIEWSWITCHERCLASS_VIEWGROUPQUEUE                                               2
#define VSATTRINDEX_VIEWSWITCHERCLASS_VIEWQUEUE                                                    3
#define VSATTRINDEX_VIEWSWITCHERCLASS_OBJECTQUEUE                                                  4
#define VSATTRNUMBER_VIEWSWITCHERCLASS                                                             5

struct StructOfAttachViewSwitcherClass{
};
struct StructOfViewSwitcherClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PROGRESSDIALOGCLASS                                                              "ProgressDialogClass"
extern VS_UUID VSOBJID_ProgressDialogClass;
#define VSATTRDEPEND_PROGRESSDIALOGCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}}
#define VSATTRDEPENDNUM_PROGRESSDIALOGCLASS                                                        3
extern VS_INT32 SRPCALLBACK ProgressDialogClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PROGRESSDIALOGCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_PROGRESSDIALOGCLASS_OBJECTLIST                                                 1
#define VSATTRINDEX_PROGRESSDIALOGCLASS_DIALOGINTERFACEQUEUE                                       2
#define VSATTRNUMBER_PROGRESSDIALOGCLASS                                                           3

struct StructOfAttachProgressDialogClass{
};
struct StructOfProgressDialogClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[AlertDialogClass] attribute
    void            *DialogInterfaceQueue;        //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MENUCLASS                                                                        "MenuClass"
extern VS_UUID VSOBJID_MenuClass;
#define VSATTRDEPEND_MENUCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MENUCLASS                                                                  2
extern VS_INT32 SRPCALLBACK MenuClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MENUCLASS_ANDROIDREFCOUNT                                                      0
#define VSATTRINDEX_MENUCLASS_OBJECTLIST                                                           1
#define VSATTRNUMBER_MENUCLASS                                                                     2

struct StructOfAttachMenuClass{
};
struct StructOfMenuClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SIMPLEADAPTERCLASS                                                               "SimpleAdapterClass"
extern VS_UUID VSOBJID_SimpleAdapterClass;
#define VSATTRDEPEND_SIMPLEADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SIMPLEADAPTERCLASS                                                         2
extern VS_INT32 SRPCALLBACK SimpleAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SIMPLEADAPTERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SIMPLEADAPTERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SIMPLEADAPTERCLASS                                                            2

struct StructOfAttachSimpleAdapterClass{
};
struct StructOfSimpleAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANIMATIONCLASS                                                                   "AnimationClass"
extern VS_UUID VSOBJID_AnimationClass;
#define VSATTRDEPEND_ANIMATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANIMATIONCLASS                                                             2
extern VS_INT32 SRPCALLBACK AnimationClass_RequestRegisterObject( );

/*----output event: onAnimationEnd[]  Static Event */
extern VS_UUID VSOUTEVENTID_AnimationClass_onAnimationEnd;
/*----output event: onAnimationRepeat[]  Static Event */
extern VS_UUID VSOUTEVENTID_AnimationClass_onAnimationRepeat;
/*----output event: onAnimationStart[]  Static Event */
extern VS_UUID VSOUTEVENTID_AnimationClass_onAnimationStart;

/*------Variable Index Define */
#define VSATTRINDEX_ANIMATIONCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_ANIMATIONCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_ANIMATIONCLASS                                                                2

struct StructOfAttachAnimationClass{
};
struct StructOfAnimationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_AUTOCOMPLETETEXTVIEWCLASS                                                        "AutoCompleteTextViewClass"
extern VS_UUID VSOBJID_AutoCompleteTextViewClass;
#define VSATTRDEPEND_AUTOCOMPLETETEXTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_AUTOCOMPLETETEXTVIEWCLASS                                                  2
extern VS_INT32 SRPCALLBACK AutoCompleteTextViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_AUTOCOMPLETETEXTVIEWCLASS_ANDROIDREFCOUNT                                      0
#define VSATTRINDEX_AUTOCOMPLETETEXTVIEWCLASS_OBJECTLIST                                           1
#define VSATTRNUMBER_AUTOCOMPLETETEXTVIEWCLASS                                                     2

struct StructOfAttachAutoCompleteTextViewClass{
};
struct StructOfAutoCompleteTextViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SMSMESSAGECLASS                                                                  "SmsMessageClass"
extern VS_UUID VSOBJID_SmsMessageClass;
#define VSATTRDEPEND_SMSMESSAGECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SMSMESSAGECLASS                                                            2
extern VS_INT32 SRPCALLBACK SmsMessageClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SMSMESSAGECLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_SMSMESSAGECLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_SMSMESSAGECLASS                                                               2

struct StructOfAttachSmsMessageClass{
};
struct StructOfSmsMessageClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTACTSCONTRACT_CONTACTSCLASS                                                   "ContactsContract_ContactsClass"
extern VS_UUID VSOBJID_ContactsContract_ContactsClass;
#define VSATTRDEPEND_CONTACTSCONTRACT_CONTACTSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTACTSCONTRACT_CONTACTSCLASS                                             2
extern VS_INT32 SRPCALLBACK ContactsContract_ContactsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTACTSCONTRACT_CONTACTSCLASS_ANDROIDREFCOUNT                                 0
#define VSATTRINDEX_CONTACTSCONTRACT_CONTACTSCLASS_OBJECTLIST                                      1
#define VSATTRNUMBER_CONTACTSCONTRACT_CONTACTSCLASS                                                2

struct StructOfAttachContactsContract_ContactsClass{
};
struct StructOfContactsContract_ContactsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SUMPATHEFFECTCLASS                                                               "SumPathEffectClass"
extern VS_UUID VSOBJID_SumPathEffectClass;
#define VSATTRDEPEND_SUMPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SUMPATHEFFECTCLASS                                                         2
extern VS_INT32 SRPCALLBACK SumPathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SUMPATHEFFECTCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SUMPATHEFFECTCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SUMPATHEFFECTCLASS                                                            2

struct StructOfAttachSumPathEffectClass{
};
struct StructOfSumPathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MASKFILTERCLASS                                                                  "MaskFilterClass"
extern VS_UUID VSOBJID_MaskFilterClass;
#define VSATTRDEPEND_MASKFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MASKFILTERCLASS                                                            2
extern VS_INT32 SRPCALLBACK MaskFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MASKFILTERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_MASKFILTERCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_MASKFILTERCLASS                                                               2

struct StructOfAttachMaskFilterClass{
};
struct StructOfMaskFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PAINTCLASS                                                                       "PaintClass"
extern VS_UUID VSOBJID_PaintClass;
#define VSATTRDEPEND_PAINTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PAINTCLASS                                                                 2
extern VS_INT32 SRPCALLBACK PaintClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PAINTCLASS_ANDROIDREFCOUNT                                                     0
#define VSATTRINDEX_PAINTCLASS_OBJECTLIST                                                          1
#define VSATTRNUMBER_PAINTCLASS                                                                    2

struct StructOfAttachPaintClass{
};
struct StructOfPaintClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COLORFILTERCLASS                                                                 "ColorFilterClass"
extern VS_UUID VSOBJID_ColorFilterClass;
#define VSATTRDEPEND_COLORFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COLORFILTERCLASS                                                           2
extern VS_INT32 SRPCALLBACK ColorFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COLORFILTERCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_COLORFILTERCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_COLORFILTERCLASS                                                              2

struct StructOfAttachColorFilterClass{
};
struct StructOfColorFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TEXTSWITCHERCLASS                                                                "TextSwitcherClass"
extern VS_UUID VSOBJID_TextSwitcherClass;
#define VSATTRDEPEND_TEXTSWITCHERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TEXTSWITCHERCLASS                                                          5
extern VS_INT32 SRPCALLBACK TextSwitcherClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TEXTSWITCHERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_TEXTSWITCHERCLASS_OBJECTLIST                                                   1
#define VSATTRINDEX_TEXTSWITCHERCLASS_VIEWGROUPQUEUE                                               2
#define VSATTRINDEX_TEXTSWITCHERCLASS_VIEWQUEUE                                                    3
#define VSATTRINDEX_TEXTSWITCHERCLASS_OBJECTQUEUE                                                  4
#define VSATTRNUMBER_TEXTSWITCHERCLASS                                                             5

struct StructOfAttachTextSwitcherClass{
};
struct StructOfTextSwitcherClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TOASTCLASS                                                                       "ToastClass"
extern VS_UUID VSOBJID_ToastClass;
#define VSATTRDEPEND_TOASTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TOASTCLASS                                                                 2
extern VS_INT32 SRPCALLBACK ToastClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TOASTCLASS_ANDROIDREFCOUNT                                                     0
#define VSATTRINDEX_TOASTCLASS_OBJECTLIST                                                          1
#define VSATTRNUMBER_TOASTCLASS                                                                    2

struct StructOfAttachToastClass{
};
struct StructOfToastClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WINDOWMANAGER_LAYOUTPARAMSCLASS                                                  "WindowManager_LayoutParamsClass"
extern VS_UUID VSOBJID_WindowManager_LayoutParamsClass;
#define VSATTRDEPEND_WINDOWMANAGER_LAYOUTPARAMSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_WINDOWMANAGER_LAYOUTPARAMSCLASS                                            2
extern VS_INT32 SRPCALLBACK WindowManager_LayoutParamsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WINDOWMANAGER_LAYOUTPARAMSCLASS_ANDROIDREFCOUNT                                0
#define VSATTRINDEX_WINDOWMANAGER_LAYOUTPARAMSCLASS_OBJECTLIST                                     1
#define VSATTRNUMBER_WINDOWMANAGER_LAYOUTPARAMSCLASS                                               2

struct StructOfAttachWindowManager_LayoutParamsClass{
};
struct StructOfWindowManager_LayoutParamsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RELATIVELAYOUTCLASS                                                              "RelativeLayoutClass"
extern VS_UUID VSOBJID_RelativeLayoutClass;
#define VSATTRDEPEND_RELATIVELAYOUTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_RELATIVELAYOUTCLASS                                                        5
extern VS_INT32 SRPCALLBACK RelativeLayoutClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RELATIVELAYOUTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_RELATIVELAYOUTCLASS_OBJECTLIST                                                 1
#define VSATTRINDEX_RELATIVELAYOUTCLASS_VIEWGROUPQUEUE                                             2
#define VSATTRINDEX_RELATIVELAYOUTCLASS_VIEWQUEUE                                                  3
#define VSATTRINDEX_RELATIVELAYOUTCLASS_OBJECTQUEUE                                                4
#define VSATTRNUMBER_RELATIVELAYOUTCLASS                                                           5

struct StructOfAttachRelativeLayoutClass{
};
struct StructOfRelativeLayoutClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TABLEROWCLASS                                                                    "TableRowClass"
extern VS_UUID VSOBJID_TableRowClass;
#define VSATTRDEPEND_TABLEROWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TABLEROWCLASS                                                              5
extern VS_INT32 SRPCALLBACK TableRowClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TABLEROWCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_TABLEROWCLASS_OBJECTLIST                                                       1
#define VSATTRINDEX_TABLEROWCLASS_VIEWGROUPQUEUE                                                   2
#define VSATTRINDEX_TABLEROWCLASS_VIEWQUEUE                                                        3
#define VSATTRINDEX_TABLEROWCLASS_OBJECTQUEUE                                                      4
#define VSATTRNUMBER_TABLEROWCLASS                                                                 5

struct StructOfAttachTableRowClass{
};
struct StructOfTableRowClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MATRIXCLASS                                                                      "MatrixClass"
extern VS_UUID VSOBJID_MatrixClass;
#define VSATTRDEPEND_MATRIXCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MATRIXCLASS                                                                2
extern VS_INT32 SRPCALLBACK MatrixClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MATRIXCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_MATRIXCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_MATRIXCLASS                                                                   2

struct StructOfAttachMatrixClass{
};
struct StructOfMatrixClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_XMLRESOURCEPARSERCLASS                                                           "XmlResourceParserClass"
extern VS_UUID VSOBJID_XmlResourceParserClass;
#define VSATTRDEPEND_XMLRESOURCEPARSERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_XMLRESOURCEPARSERCLASS                                                     2
extern VS_INT32 SRPCALLBACK XmlResourceParserClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_XMLRESOURCEPARSERCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_XMLRESOURCEPARSERCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_XMLRESOURCEPARSERCLASS                                                        2

struct StructOfAttachXmlResourceParserClass{
};
struct StructOfXmlResourceParserClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SPINNERCLASS                                                                     "SpinnerClass"
extern VS_UUID VSOBJID_SpinnerClass;
#define VSATTRDEPEND_SPINNERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_SPINNERCLASS                                                               5
extern VS_INT32 SRPCALLBACK SpinnerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SPINNERCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_SPINNERCLASS_OBJECTLIST                                                        1
#define VSATTRINDEX_SPINNERCLASS_VIEWGROUPQUEUE                                                    2
#define VSATTRINDEX_SPINNERCLASS_VIEWQUEUE                                                         3
#define VSATTRINDEX_SPINNERCLASS_OBJECTQUEUE                                                       4
#define VSATTRNUMBER_SPINNERCLASS                                                                  5

struct StructOfAttachSpinnerClass{
};
struct StructOfSpinnerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LISTACTIVITYCLASS                                                                "ListActivityClass"
extern VS_UUID VSOBJID_ListActivityClass;
#define VSATTRDEPEND_LISTACTIVITYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_LISTACTIVITYCLASS                                                          5
extern VS_INT32 SRPCALLBACK ListActivityClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LISTACTIVITYCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_LISTACTIVITYCLASS_OBJECTLIST                                                   1
#define VSATTRINDEX_LISTACTIVITYCLASS_VIEWGROUPQUEUE                                               2
#define VSATTRINDEX_LISTACTIVITYCLASS_VIEWQUEUE                                                    3
#define VSATTRINDEX_LISTACTIVITYCLASS_OBJECTQUEUE                                                  4
#define VSATTRNUMBER_LISTACTIVITYCLASS                                                             5

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ListActivityClass_onListItemClick;
#define VSFUNCRETURNDEPEND_LISTACTIVITYCLASS_ONLISTITEMCLICK(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_LISTACTIVITYCLASS_ONLISTITEMCLICK                                    1
#define VSFUNCPARAMDEPEND_LISTACTIVITYCLASS_ONLISTITEMCLICK(X)  {{X[0].Type=57;}{X[1].Type=57;}{X[2].Type=6;}{X[3].Type=9;}}
#define VSFUNCPARAMDEPENDNUM_LISTACTIVITYCLASS_ONLISTITEMCLICK                                     4

extern VS_BOOL SRPAPI ListActivityClass_onListItemClick(void *Object,VS_OBJPTR l,VS_OBJPTR v,VS_INT32 position,VS_LONG id);
typedef VS_BOOL (SRPAPI *ListActivityClass_onListItemClickProc)(void *Object,VS_OBJPTR l,VS_OBJPTR v,VS_INT32 position,VS_LONG id);

struct StructOfAttachListActivityClass{
};
struct StructOfListActivityClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ActivityClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CURSORADAPTERCLASS                                                               "CursorAdapterClass"
extern VS_UUID VSOBJID_CursorAdapterClass;
#define VSATTRDEPEND_CURSORADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CURSORADAPTERCLASS                                                         2
extern VS_INT32 SRPCALLBACK CursorAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CURSORADAPTERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_CURSORADAPTERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_CURSORADAPTERCLASS                                                            2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_CursorAdapterClass_bindView;
#define VSFUNCRETURNDEPEND_CURSORADAPTERCLASS_BINDVIEW(X)  {}
#define VSFUNCRETURNDEPENDNUM_CURSORADAPTERCLASS_BINDVIEW                                          0
#define VSFUNCPARAMDEPEND_CURSORADAPTERCLASS_BINDVIEW(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_CURSORADAPTERCLASS_BINDVIEW                                           2

extern void SRPAPI CursorAdapterClass_bindView(void *Object,VS_OBJPTR view,VS_OBJPTR cursor);
typedef void (SRPAPI *CursorAdapterClass_bindViewProc)(void *Object,VS_OBJPTR view,VS_OBJPTR cursor);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_CursorAdapterClass_newDropDownView;
#define VSFUNCRETURNDEPEND_CURSORADAPTERCLASS_NEWDROPDOWNVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_CURSORADAPTERCLASS_NEWDROPDOWNVIEW                                   1
#define VSFUNCPARAMDEPEND_CURSORADAPTERCLASS_NEWDROPDOWNVIEW(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_CURSORADAPTERCLASS_NEWDROPDOWNVIEW                                    2

extern VS_OBJPTR SRPAPI CursorAdapterClass_newDropDownView(void *Object,VS_OBJPTR cursor,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *CursorAdapterClass_newDropDownViewProc)(void *Object,VS_OBJPTR cursor,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_CursorAdapterClass_newView;
#define VSFUNCRETURNDEPEND_CURSORADAPTERCLASS_NEWVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_CURSORADAPTERCLASS_NEWVIEW                                           1
#define VSFUNCPARAMDEPEND_CURSORADAPTERCLASS_NEWVIEW(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_CURSORADAPTERCLASS_NEWVIEW                                            2

extern VS_OBJPTR SRPAPI CursorAdapterClass_newView(void *Object,VS_OBJPTR cursor,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *CursorAdapterClass_newViewProc)(void *Object,VS_OBJPTR cursor,VS_OBJPTR parent);

struct StructOfAttachCursorAdapterClass{
};
struct StructOfCursorAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SIMPLECURSORADAPTERCLASS                                                         "SimpleCursorAdapterClass"
extern VS_UUID VSOBJID_SimpleCursorAdapterClass;
#define VSATTRDEPEND_SIMPLECURSORADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SIMPLECURSORADAPTERCLASS                                                   2
extern VS_INT32 SRPCALLBACK SimpleCursorAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SIMPLECURSORADAPTERCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_SIMPLECURSORADAPTERCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_SIMPLECURSORADAPTERCLASS                                                      2

struct StructOfAttachSimpleCursorAdapterClass{
};
struct StructOfSimpleCursorAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DISCRETEPATHEFFECTCLASS                                                          "DiscretePathEffectClass"
extern VS_UUID VSOBJID_DiscretePathEffectClass;
#define VSATTRDEPEND_DISCRETEPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DISCRETEPATHEFFECTCLASS                                                    2
extern VS_INT32 SRPCALLBACK DiscretePathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DISCRETEPATHEFFECTCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_DISCRETEPATHEFFECTCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_DISCRETEPATHEFFECTCLASS                                                       2

struct StructOfAttachDiscretePathEffectClass{
};
struct StructOfDiscretePathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTEXTMENUCLASS                                                                 "ContextMenuClass"
extern VS_UUID VSOBJID_ContextMenuClass;
#define VSATTRDEPEND_CONTEXTMENUCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTEXTMENUCLASS                                                           2
extern VS_INT32 SRPCALLBACK ContextMenuClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTEXTMENUCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_CONTEXTMENUCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_CONTEXTMENUCLASS                                                              2

struct StructOfAttachContextMenuClass{
};
struct StructOfContextMenuClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GREGORIANCALENDARCLASS                                                           "GregorianCalendarClass"
extern VS_UUID VSOBJID_GregorianCalendarClass;
#define VSATTRDEPEND_GREGORIANCALENDARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GREGORIANCALENDARCLASS                                                     2
extern VS_INT32 SRPCALLBACK GregorianCalendarClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GREGORIANCALENDARCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_GREGORIANCALENDARCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_GREGORIANCALENDARCLASS                                                        2

struct StructOfAttachGregorianCalendarClass{
};
struct StructOfGregorianCalendarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ALPHAANIMATIONCLASS                                                              "AlphaAnimationClass"
extern VS_UUID VSOBJID_AlphaAnimationClass;
#define VSATTRDEPEND_ALPHAANIMATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ALPHAANIMATIONCLASS                                                        2
extern VS_INT32 SRPCALLBACK AlphaAnimationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ALPHAANIMATIONCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_ALPHAANIMATIONCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_ALPHAANIMATIONCLASS                                                           2

struct StructOfAttachAlphaAnimationClass{
};
struct StructOfAlphaAnimationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ABSOLUTELAYOUTCLASS                                                              "AbsoluteLayoutClass"
extern VS_UUID VSOBJID_AbsoluteLayoutClass;
#define VSATTRDEPEND_ABSOLUTELAYOUTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_ABSOLUTELAYOUTCLASS                                                        5
extern VS_INT32 SRPCALLBACK AbsoluteLayoutClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ABSOLUTELAYOUTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_ABSOLUTELAYOUTCLASS_OBJECTLIST                                                 1
#define VSATTRINDEX_ABSOLUTELAYOUTCLASS_VIEWGROUPQUEUE                                             2
#define VSATTRINDEX_ABSOLUTELAYOUTCLASS_VIEWQUEUE                                                  3
#define VSATTRINDEX_ABSOLUTELAYOUTCLASS_OBJECTQUEUE                                                4
#define VSATTRNUMBER_ABSOLUTELAYOUTCLASS                                                           5

struct StructOfAttachAbsoluteLayoutClass{
};
struct StructOfAbsoluteLayoutClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OVALSHAPECLASS                                                                   "OvalShapeClass"
extern VS_UUID VSOBJID_OvalShapeClass;
#define VSATTRDEPEND_OVALSHAPECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OVALSHAPECLASS                                                             2
extern VS_INT32 SRPCALLBACK OvalShapeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OVALSHAPECLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_OVALSHAPECLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_OVALSHAPECLASS                                                                2

struct StructOfAttachOvalShapeClass{
};
struct StructOfOvalShapeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COLORMATRIXCLASS                                                                 "ColorMatrixClass"
extern VS_UUID VSOBJID_ColorMatrixClass;
#define VSATTRDEPEND_COLORMATRIXCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COLORMATRIXCLASS                                                           2
extern VS_INT32 SRPCALLBACK ColorMatrixClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COLORMATRIXCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_COLORMATRIXCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_COLORMATRIXCLASS                                                              2

struct StructOfAttachColorMatrixClass{
};
struct StructOfColorMatrixClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ROTATEANIMATIONCLASS                                                             "RotateAnimationClass"
extern VS_UUID VSOBJID_RotateAnimationClass;
#define VSATTRDEPEND_ROTATEANIMATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ROTATEANIMATIONCLASS                                                       2
extern VS_INT32 SRPCALLBACK RotateAnimationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ROTATEANIMATIONCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_ROTATEANIMATIONCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_ROTATEANIMATIONCLASS                                                          2

struct StructOfAttachRotateAnimationClass{
};
struct StructOfRotateAnimationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTACTSCONTRACT_PHONELOOKUPCLASS                                                "ContactsContract_PhoneLookupClass"
extern VS_UUID VSOBJID_ContactsContract_PhoneLookupClass;
#define VSATTRDEPEND_CONTACTSCONTRACT_PHONELOOKUPCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTACTSCONTRACT_PHONELOOKUPCLASS                                          2
extern VS_INT32 SRPCALLBACK ContactsContract_PhoneLookupClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTACTSCONTRACT_PHONELOOKUPCLASS_ANDROIDREFCOUNT                              0
#define VSATTRINDEX_CONTACTSCONTRACT_PHONELOOKUPCLASS_OBJECTLIST                                   1
#define VSATTRNUMBER_CONTACTSCONTRACT_PHONELOOKUPCLASS                                             2

struct StructOfAttachContactsContract_PhoneLookupClass{
};
struct StructOfContactsContract_PhoneLookupClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MENUITEMCLASS                                                                    "MenuItemClass"
extern VS_UUID VSOBJID_MenuItemClass;
#define VSATTRDEPEND_MENUITEMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MENUITEMCLASS                                                              2
extern VS_INT32 SRPCALLBACK MenuItemClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MENUITEMCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_MENUITEMCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_MENUITEMCLASS                                                                 2

struct StructOfAttachMenuItemClass{
};
struct StructOfMenuItemClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RECTCLASS                                                                        "RectClass"
extern VS_UUID VSOBJID_RectClass;
#define VSATTRDEPEND_RECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=6;X[1].Offset=4;}{X[2].Type=6;X[2].Offset=8;}{X[3].Type=6;X[3].Offset=12;}}
#define VSATTRDEPENDNUM_RECTCLASS                                                                  4
extern VS_INT32 SRPCALLBACK RectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RECTCLASS_LEFT                                                                 0
#define VSATTRINDEX_RECTCLASS_TOP                                                                  1
#define VSATTRINDEX_RECTCLASS_RIGHT                                                                2
#define VSATTRINDEX_RECTCLASS_BOTTOM                                                               3
#define VSATTRNUMBER_RECTCLASS                                                                     4

struct StructOfAttachRectClass{
};
struct StructOfRectClass{
    //----local attribute
    VS_INT32        left;                         //
    VS_INT32        top;                          //
    VS_INT32        right;                        //
    VS_INT32        bottom;                       //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PROGRESSBARCLASS                                                                 "ProgressBarClass"
extern VS_UUID VSOBJID_ProgressBarClass;
#define VSATTRDEPEND_PROGRESSBARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PROGRESSBARCLASS                                                           2
extern VS_INT32 SRPCALLBACK ProgressBarClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PROGRESSBARCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_PROGRESSBARCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_PROGRESSBARCLASS                                                              2

struct StructOfAttachProgressBarClass{
};
struct StructOfProgressBarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INTENTFILTERCLASS                                                                "IntentFilterClass"
extern VS_UUID VSOBJID_IntentFilterClass;
#define VSATTRDEPEND_INTENTFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INTENTFILTERCLASS                                                          2
extern VS_INT32 SRPCALLBACK IntentFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INTENTFILTERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_INTENTFILTERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_INTENTFILTERCLASS                                                             2

struct StructOfAttachIntentFilterClass{
};
struct StructOfIntentFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EDITORINFOCLASS                                                                  "EditorInfoClass"
extern VS_UUID VSOBJID_EditorInfoClass;
#define VSATTRDEPEND_EDITORINFOCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EDITORINFOCLASS                                                            2
extern VS_INT32 SRPCALLBACK EditorInfoClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EDITORINFOCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_EDITORINFOCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_EDITORINFOCLASS                                                               2

struct StructOfAttachEditorInfoClass{
};
struct StructOfEditorInfoClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_URI_BUILDERCLASS                                                                 "Uri_BuilderClass"
extern VS_UUID VSOBJID_Uri_BuilderClass;
#define VSATTRDEPEND_URI_BUILDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_URI_BUILDERCLASS                                                           2
extern VS_INT32 SRPCALLBACK Uri_BuilderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_URI_BUILDERCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_URI_BUILDERCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_URI_BUILDERCLASS                                                              2

struct StructOfAttachUri_BuilderClass{
};
struct StructOfUri_BuilderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DISPLAYCLASS                                                                     "DisplayClass"
extern VS_UUID VSOBJID_DisplayClass;
#define VSATTRDEPEND_DISPLAYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DISPLAYCLASS                                                               2
extern VS_INT32 SRPCALLBACK DisplayClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DISPLAYCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_DISPLAYCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_DISPLAYCLASS                                                                  2

struct StructOfAttachDisplayClass{
};
struct StructOfDisplayClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_STATELISTDRAWABLECLASS                                                           "StateListDrawableClass"
extern VS_UUID VSOBJID_StateListDrawableClass;
#define VSATTRDEPEND_STATELISTDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_STATELISTDRAWABLECLASS                                                     2
extern VS_INT32 SRPCALLBACK StateListDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_STATELISTDRAWABLECLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_STATELISTDRAWABLECLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_STATELISTDRAWABLECLASS                                                        2

struct StructOfAttachStateListDrawableClass{
};
struct StructOfStateListDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SHAPECLASS                                                                       "ShapeClass"
extern VS_UUID VSOBJID_ShapeClass;
#define VSATTRDEPEND_SHAPECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SHAPECLASS                                                                 2
extern VS_INT32 SRPCALLBACK ShapeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SHAPECLASS_ANDROIDREFCOUNT                                                     0
#define VSATTRINDEX_SHAPECLASS_OBJECTLIST                                                          1
#define VSATTRNUMBER_SHAPECLASS                                                                    2

struct StructOfAttachShapeClass{
};
struct StructOfShapeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SYSTEMCLOCKCLASS                                                                 "SystemClockClass"
extern VS_UUID VSOBJID_SystemClockClass;
#define VSATTRDEPEND_SYSTEMCLOCKCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SYSTEMCLOCKCLASS                                                           2
extern VS_INT32 SRPCALLBACK SystemClockClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SYSTEMCLOCKCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_SYSTEMCLOCKCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_SYSTEMCLOCKCLASS                                                              2

struct StructOfAttachSystemClockClass{
};
struct StructOfSystemClockClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GESTUREDETECTORCLASS                                                             "GestureDetectorClass"
extern VS_UUID VSOBJID_GestureDetectorClass;
#define VSATTRDEPEND_GESTUREDETECTORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GESTUREDETECTORCLASS                                                       2
extern VS_INT32 SRPCALLBACK GestureDetectorClass_RequestRegisterObject( );

/*----output event: onDown[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onDown;
/*----output event: onFling[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onFling;
/*----output event: onLongPress[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onLongPress;
/*----output event: onScroll[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onScroll;
/*----output event: onShowPress[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onShowPress;
/*----output event: onSingleTapUp[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onSingleTapUp;
/*----output event: onDoubleTap[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onDoubleTap;
/*----output event: onDoubleTapEvent[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onDoubleTapEvent;
/*----output event: onSingleTapConfirmed[]  Static Event */
extern VS_UUID VSOUTEVENTID_GestureDetectorClass_onSingleTapConfirmed;

/*------Variable Index Define */
#define VSATTRINDEX_GESTUREDETECTORCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_GESTUREDETECTORCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_GESTUREDETECTORCLASS                                                          2

struct StructOfAttachGestureDetectorClass{
};
struct StructOfGestureDetectorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ALERTDIALOGCLASS                                                                 "AlertDialogClass"
extern VS_UUID VSOBJID_AlertDialogClass;
#define VSATTRDEPEND_ALERTDIALOGCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}}
#define VSATTRDEPENDNUM_ALERTDIALOGCLASS                                                           3
extern VS_INT32 SRPCALLBACK AlertDialogClass_RequestRegisterObject( );

/*----output event: onMultiChoiceClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialogClass_onMultiChoiceClick;
/*----output event: onClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialogClass_onClick;

/*------Variable Index Define */
#define VSATTRINDEX_ALERTDIALOGCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ALERTDIALOGCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_ALERTDIALOGCLASS_DIALOGINTERFACEQUEUE                                          2
#define VSATTRNUMBER_ALERTDIALOGCLASS                                                              3

struct StructOfAttachAlertDialogClass{
};
struct StructOfAlertDialogClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----local attribute
    void            *DialogInterfaceQueue;        //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TABLELAYOUTCLASS                                                                 "TableLayoutClass"
extern VS_UUID VSOBJID_TableLayoutClass;
#define VSATTRDEPEND_TABLELAYOUTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TABLELAYOUTCLASS                                                           5
extern VS_INT32 SRPCALLBACK TableLayoutClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TABLELAYOUTCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_TABLELAYOUTCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_TABLELAYOUTCLASS_VIEWGROUPQUEUE                                                2
#define VSATTRINDEX_TABLELAYOUTCLASS_VIEWQUEUE                                                     3
#define VSATTRINDEX_TABLELAYOUTCLASS_OBJECTQUEUE                                                   4
#define VSATTRNUMBER_TABLELAYOUTCLASS                                                              5

struct StructOfAttachTableLayoutClass{
};
struct StructOfTableLayoutClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DRAWABLECONTAINERCLASS                                                           "DrawableContainerClass"
extern VS_UUID VSOBJID_DrawableContainerClass;
#define VSATTRDEPEND_DRAWABLECONTAINERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DRAWABLECONTAINERCLASS                                                     2
extern VS_INT32 SRPCALLBACK DrawableContainerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DRAWABLECONTAINERCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_DRAWABLECONTAINERCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_DRAWABLECONTAINERCLASS                                                        2

struct StructOfAttachDrawableContainerClass{
};
struct StructOfDrawableContainerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ALARMMANAGERCLASS                                                                "AlarmManagerClass"
extern VS_UUID VSOBJID_AlarmManagerClass;
#define VSATTRDEPEND_ALARMMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ALARMMANAGERCLASS                                                          2
extern VS_INT32 SRPCALLBACK AlarmManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ALARMMANAGERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_ALARMMANAGERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_ALARMMANAGERCLASS                                                             2

struct StructOfAttachAlarmManagerClass{
};
struct StructOfAlarmManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SCROLLVIEWCLASS                                                                  "ScrollViewClass"
extern VS_UUID VSOBJID_ScrollViewClass;
#define VSATTRDEPEND_SCROLLVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_SCROLLVIEWCLASS                                                            5
extern VS_INT32 SRPCALLBACK ScrollViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SCROLLVIEWCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_SCROLLVIEWCLASS_OBJECTLIST                                                     1
#define VSATTRINDEX_SCROLLVIEWCLASS_VIEWGROUPQUEUE                                                 2
#define VSATTRINDEX_SCROLLVIEWCLASS_VIEWQUEUE                                                      3
#define VSATTRINDEX_SCROLLVIEWCLASS_OBJECTQUEUE                                                    4
#define VSATTRNUMBER_SCROLLVIEWCLASS                                                               5

struct StructOfAttachScrollViewClass{
};
struct StructOfScrollViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWCLASS                                                                        "ViewClass"
extern VS_UUID VSOBJID_ViewClass;
#define VSATTRDEPEND_VIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIEWCLASS                                                                  2
extern VS_INT32 SRPCALLBACK ViewClass_RequestRegisterObject( );

/*----output event: onClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onClick;
/*----output event: onLongClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onLongClick;
/*----output event: onKey[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onKey;
/*----output event: onFocusChange[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onFocusChange;
/*----output event: onCreateContextMenu[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onCreateContextMenu;
/*----output event: onTouch[]  Static Event */
extern VS_UUID VSOUTEVENTID_ViewClass_onTouch;

/*------Variable Index Define */
#define VSATTRINDEX_VIEWCLASS_ANDROIDREFCOUNT                                                      0
#define VSATTRINDEX_VIEWCLASS_OBJECTLIST                                                           1
#define VSATTRNUMBER_VIEWCLASS                                                                     2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onCreateInputConnection;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONCREATEINPUTCONNECTION(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONCREATEINPUTCONNECTION                                    1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONCREATEINPUTCONNECTION(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONCREATEINPUTCONNECTION                                     1

extern VS_OBJPTR SRPAPI ViewClass_onCreateInputConnection(void *Object,VS_OBJPTR outAttrs);
typedef VS_OBJPTR (SRPAPI *ViewClass_onCreateInputConnectionProc)(void *Object,VS_OBJPTR outAttrs);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onDraw;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONDRAW(X)  {}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONDRAW                                                     0
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONDRAW(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONDRAW                                                      1

extern void SRPAPI ViewClass_onDraw(void *Object,VS_OBJPTR canvas);
typedef void (SRPAPI *ViewClass_onDrawProc)(void *Object,VS_OBJPTR canvas);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onTouchEvent;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONTOUCHEVENT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONTOUCHEVENT                                               1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONTOUCHEVENT(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONTOUCHEVENT                                                1

extern VS_BOOL SRPAPI ViewClass_onTouchEvent(void *Object,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewClass_onTouchEventProc)(void *Object,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onLayout;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONLAYOUT(X)  {}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONLAYOUT                                                   0
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONLAYOUT(X)  {{X[0].Type=1;}{X[1].Type=6;}{X[2].Type=6;}{X[3].Type=6;}{X[4].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONLAYOUT                                                    5

extern void SRPAPI ViewClass_onLayout(void *Object,VS_BOOL changed,VS_INT32 left,VS_INT32 top,VS_INT32 right,VS_INT32 bottom);
typedef void (SRPAPI *ViewClass_onLayoutProc)(void *Object,VS_BOOL changed,VS_INT32 left,VS_INT32 top,VS_INT32 right,VS_INT32 bottom);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onMeasure;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONMEASURE(X)  {}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONMEASURE                                                  0
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONMEASURE(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONMEASURE                                                   2

extern void SRPAPI ViewClass_onMeasure(void *Object,VS_INT32 widthMeasureSpec,VS_INT32 heightMeasureSpec);
typedef void (SRPAPI *ViewClass_onMeasureProc)(void *Object,VS_INT32 widthMeasureSpec,VS_INT32 heightMeasureSpec);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onSizeChanged;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONSIZECHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONSIZECHANGED                                              0
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONSIZECHANGED(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=6;}{X[3].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONSIZECHANGED                                               4

extern void SRPAPI ViewClass_onSizeChanged(void *Object,VS_INT32 w,VS_INT32 h,VS_INT32 oldw,VS_INT32 oldh);
typedef void (SRPAPI *ViewClass_onSizeChangedProc)(void *Object,VS_INT32 w,VS_INT32 h,VS_INT32 oldw,VS_INT32 oldh);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onKeyDown;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONKEYDOWN(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONKEYDOWN                                                  1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONKEYDOWN(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONKEYDOWN                                                   2

extern VS_BOOL SRPAPI ViewClass_onKeyDown(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewClass_onKeyDownProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onKeyLongPress;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONKEYLONGPRESS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONKEYLONGPRESS                                             1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONKEYLONGPRESS(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONKEYLONGPRESS                                              2

extern VS_BOOL SRPAPI ViewClass_onKeyLongPress(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewClass_onKeyLongPressProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onKeyMultiple;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONKEYMULTIPLE(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONKEYMULTIPLE                                              1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONKEYMULTIPLE(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONKEYMULTIPLE                                               3

extern VS_BOOL SRPAPI ViewClass_onKeyMultiple(void *Object,VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewClass_onKeyMultipleProc)(void *Object,VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewClass_onKeyUp;
#define VSFUNCRETURNDEPEND_VIEWCLASS_ONKEYUP(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWCLASS_ONKEYUP                                                    1
#define VSFUNCPARAMDEPEND_VIEWCLASS_ONKEYUP(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWCLASS_ONKEYUP                                                     2

extern VS_BOOL SRPAPI ViewClass_onKeyUp(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewClass_onKeyUpProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

struct StructOfAttachViewClass{
};
struct StructOfViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWFLIPPERCLASS                                                                 "ViewFlipperClass"
extern VS_UUID VSOBJID_ViewFlipperClass;
#define VSATTRDEPEND_VIEWFLIPPERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_VIEWFLIPPERCLASS                                                           5
extern VS_INT32 SRPCALLBACK ViewFlipperClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWFLIPPERCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_VIEWFLIPPERCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_VIEWFLIPPERCLASS_VIEWGROUPQUEUE                                                2
#define VSATTRINDEX_VIEWFLIPPERCLASS_VIEWQUEUE                                                     3
#define VSATTRINDEX_VIEWFLIPPERCLASS_OBJECTQUEUE                                                   4
#define VSATTRNUMBER_VIEWFLIPPERCLASS                                                              5

struct StructOfAttachViewFlipperClass{
};
struct StructOfViewFlipperClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DIGITALCLOCKCLASS                                                                "DigitalClockClass"
extern VS_UUID VSOBJID_DigitalClockClass;
#define VSATTRDEPEND_DIGITALCLOCKCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DIGITALCLOCKCLASS                                                          2
extern VS_INT32 SRPCALLBACK DigitalClockClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DIGITALCLOCKCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_DIGITALCLOCKCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_DIGITALCLOCKCLASS                                                             2

struct StructOfAttachDigitalClockClass{
};
struct StructOfDigitalClockClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SCALEANIMATIONCLASS                                                              "ScaleAnimationClass"
extern VS_UUID VSOBJID_ScaleAnimationClass;
#define VSATTRDEPEND_SCALEANIMATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SCALEANIMATIONCLASS                                                        2
extern VS_INT32 SRPCALLBACK ScaleAnimationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SCALEANIMATIONCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_SCALEANIMATIONCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_SCALEANIMATIONCLASS                                                           2

struct StructOfAttachScaleAnimationClass{
};
struct StructOfScaleAnimationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SEEKBARCLASS                                                                     "SeekBarClass"
extern VS_UUID VSOBJID_SeekBarClass;
#define VSATTRDEPEND_SEEKBARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SEEKBARCLASS                                                               2
extern VS_INT32 SRPCALLBACK SeekBarClass_RequestRegisterObject( );

/*----output event: onProgressChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_SeekBarClass_onProgressChanged;
/*----output event: onStartTrackingTouch[]  Static Event */
extern VS_UUID VSOUTEVENTID_SeekBarClass_onStartTrackingTouch;
/*----output event: onStopTrackingTouch[]  Static Event */
extern VS_UUID VSOUTEVENTID_SeekBarClass_onStopTrackingTouch;

/*------Variable Index Define */
#define VSATTRINDEX_SEEKBARCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_SEEKBARCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_SEEKBARCLASS                                                                  2

struct StructOfAttachSeekBarClass{
};
struct StructOfSeekBarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INPUTSTREAMCLASS                                                                 "InputStreamClass"
extern VS_UUID VSOBJID_InputStreamClass;
#define VSATTRDEPEND_INPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INPUTSTREAMCLASS                                                           2
extern VS_INT32 SRPCALLBACK InputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INPUTSTREAMCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_INPUTSTREAMCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_INPUTSTREAMCLASS                                                              2

struct StructOfAttachInputStreamClass{
};
struct StructOfInputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RADIOGROUPCLASS                                                                  "RadioGroupClass"
extern VS_UUID VSOBJID_RadioGroupClass;
#define VSATTRDEPEND_RADIOGROUPCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_RADIOGROUPCLASS                                                            5
extern VS_INT32 SRPCALLBACK RadioGroupClass_RequestRegisterObject( );

/*----output event: onCheckedChanged[LParam=RadioButton; Script( Event, RadioButton )]  Static Event */
extern VS_UUID VSOUTEVENTID_RadioGroupClass_onCheckedChanged;
/*----output event: onChildViewAdded[]  Static Event */
extern VS_UUID VSOUTEVENTID_RadioGroupClass_onChildViewAdded;
/*----output event: onChildViewRemoved[]  Static Event */
extern VS_UUID VSOUTEVENTID_RadioGroupClass_onChildViewRemoved;

/*------Variable Index Define */
#define VSATTRINDEX_RADIOGROUPCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_RADIOGROUPCLASS_OBJECTLIST                                                     1
#define VSATTRINDEX_RADIOGROUPCLASS_VIEWGROUPQUEUE                                                 2
#define VSATTRINDEX_RADIOGROUPCLASS_VIEWQUEUE                                                      3
#define VSATTRINDEX_RADIOGROUPCLASS_OBJECTQUEUE                                                    4
#define VSATTRNUMBER_RADIOGROUPCLASS                                                               5

struct StructOfAttachRadioGroupClass{
};
struct StructOfRadioGroupClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GPSSATELLITECLASS                                                                "GpsSatelliteClass"
extern VS_UUID VSOBJID_GpsSatelliteClass;
#define VSATTRDEPEND_GPSSATELLITECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GPSSATELLITECLASS                                                          2
extern VS_INT32 SRPCALLBACK GpsSatelliteClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GPSSATELLITECLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_GPSSATELLITECLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_GPSSATELLITECLASS                                                             2

struct StructOfAttachGpsSatelliteClass{
};
struct StructOfGpsSatelliteClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMMONDATAKINDS_PHONECLASS                                                       "CommonDataKinds_PhoneClass"
extern VS_UUID VSOBJID_CommonDataKinds_PhoneClass;
#define VSATTRDEPEND_COMMONDATAKINDS_PHONECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMMONDATAKINDS_PHONECLASS                                                 2
extern VS_INT32 SRPCALLBACK CommonDataKinds_PhoneClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COMMONDATAKINDS_PHONECLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_COMMONDATAKINDS_PHONECLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_COMMONDATAKINDS_PHONECLASS                                                    2

struct StructOfAttachCommonDataKinds_PhoneClass{
};
struct StructOfCommonDataKinds_PhoneClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TRANSITIONDRAWABLECLASS                                                          "TransitionDrawableClass"
extern VS_UUID VSOBJID_TransitionDrawableClass;
#define VSATTRDEPEND_TRANSITIONDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TRANSITIONDRAWABLECLASS                                                    2
extern VS_INT32 SRPCALLBACK TransitionDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TRANSITIONDRAWABLECLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_TRANSITIONDRAWABLECLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_TRANSITIONDRAWABLECLASS                                                       2

struct StructOfAttachTransitionDrawableClass{
};
struct StructOfTransitionDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TYPEFACECLASS                                                                    "TypefaceClass"
extern VS_UUID VSOBJID_TypefaceClass;
#define VSATTRDEPEND_TYPEFACECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TYPEFACECLASS                                                              2
extern VS_INT32 SRPCALLBACK TypefaceClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TYPEFACECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_TYPEFACECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_TYPEFACECLASS                                                                 2

struct StructOfAttachTypefaceClass{
};
struct StructOfTypefaceClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_QUICKCONTACTBADGECLASS                                                           "QuickContactBadgeClass"
extern VS_UUID VSOBJID_QuickContactBadgeClass;
#define VSATTRDEPEND_QUICKCONTACTBADGECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_QUICKCONTACTBADGECLASS                                                     2
extern VS_INT32 SRPCALLBACK QuickContactBadgeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_QUICKCONTACTBADGECLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_QUICKCONTACTBADGECLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_QUICKCONTACTBADGECLASS                                                        2

struct StructOfAttachQuickContactBadgeClass{
};
struct StructOfQuickContactBadgeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANDROIDCONSTANTCLASS                                                             "AndroidConstantClass"
extern VS_UUID VSOBJID_AndroidConstantClass;
#define VSATTRDEPEND_ANDROIDCONSTANTCLASS(X)  {}
#define VSATTRDEPENDNUM_ANDROIDCONSTANTCLASS                                                       0
extern VS_INT32 SRPCALLBACK AndroidConstantClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRNUMBER_ANDROIDCONSTANTCLASS                                                          0

struct StructOfAttachAndroidConstantClass{
};
struct StructOfAndroidConstantClass{
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_NOTIFICATIONMANAGERCLASS                                                         "NotificationManagerClass"
extern VS_UUID VSOBJID_NotificationManagerClass;
#define VSATTRDEPEND_NOTIFICATIONMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_NOTIFICATIONMANAGERCLASS                                                   2
extern VS_INT32 SRPCALLBACK NotificationManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_NOTIFICATIONMANAGERCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_NOTIFICATIONMANAGERCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_NOTIFICATIONMANAGERCLASS                                                      2

struct StructOfAttachNotificationManagerClass{
};
struct StructOfNotificationManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ASSETMANAGERCLASS                                                                "AssetManagerClass"
extern VS_UUID VSOBJID_AssetManagerClass;
#define VSATTRDEPEND_ASSETMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ASSETMANAGERCLASS                                                          2
extern VS_INT32 SRPCALLBACK AssetManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ASSETMANAGERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_ASSETMANAGERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_ASSETMANAGERCLASS                                                             2

struct StructOfAttachAssetManagerClass{
};
struct StructOfAssetManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SURFACEVIEWCLASS                                                                 "SurfaceViewClass"
extern VS_UUID VSOBJID_SurfaceViewClass;
#define VSATTRDEPEND_SURFACEVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SURFACEVIEWCLASS                                                           2
extern VS_INT32 SRPCALLBACK SurfaceViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SURFACEVIEWCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_SURFACEVIEWCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_SURFACEVIEWCLASS                                                              2

struct StructOfAttachSurfaceViewClass{
};
struct StructOfSurfaceViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ADAPTERCONTEXTMENUINFOCLASS                                                      "AdapterContextMenuInfoClass"
extern VS_UUID VSOBJID_AdapterContextMenuInfoClass;
#define VSATTRDEPEND_ADAPTERCONTEXTMENUINFOCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ADAPTERCONTEXTMENUINFOCLASS                                                2
extern VS_INT32 SRPCALLBACK AdapterContextMenuInfoClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ADAPTERCONTEXTMENUINFOCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_ADAPTERCONTEXTMENUINFOCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_ADAPTERCONTEXTMENUINFOCLASS                                                   2

struct StructOfAttachAdapterContextMenuInfoClass{
};
struct StructOfAdapterContextMenuInfoClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TIMEPICKERCLASS                                                                  "TimePickerClass"
extern VS_UUID VSOBJID_TimePickerClass;
#define VSATTRDEPEND_TIMEPICKERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TIMEPICKERCLASS                                                            5
extern VS_INT32 SRPCALLBACK TimePickerClass_RequestRegisterObject( );

/*----output event: onTimeChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TimePickerClass_onTimeChanged;

/*------Variable Index Define */
#define VSATTRINDEX_TIMEPICKERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_TIMEPICKERCLASS_OBJECTLIST                                                     1
#define VSATTRINDEX_TIMEPICKERCLASS_VIEWGROUPQUEUE                                                 2
#define VSATTRINDEX_TIMEPICKERCLASS_VIEWQUEUE                                                      3
#define VSATTRINDEX_TIMEPICKERCLASS_OBJECTQUEUE                                                    4
#define VSATTRNUMBER_TIMEPICKERCLASS                                                               5

struct StructOfAttachTimePickerClass{
};
struct StructOfTimePickerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANALOGCLOCKCLASS                                                                 "AnalogClockClass"
extern VS_UUID VSOBJID_AnalogClockClass;
#define VSATTRDEPEND_ANALOGCLOCKCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANALOGCLOCKCLASS                                                           2
extern VS_INT32 SRPCALLBACK AnalogClockClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANALOGCLOCKCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ANALOGCLOCKCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_ANALOGCLOCKCLASS                                                              2

struct StructOfAttachAnalogClockClass{
};
struct StructOfAnalogClockClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONFIGURATIONCLASS                                                               "ConfigurationClass"
extern VS_UUID VSOBJID_ConfigurationClass;
#define VSATTRDEPEND_CONFIGURATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONFIGURATIONCLASS                                                         2
extern VS_INT32 SRPCALLBACK ConfigurationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONFIGURATIONCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_CONFIGURATIONCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_CONFIGURATIONCLASS                                                            2

struct StructOfAttachConfigurationClass{
};
struct StructOfConfigurationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ALERTDIALOG_BUILDERCLASS                                                         "AlertDialog_BuilderClass"
extern VS_UUID VSOBJID_AlertDialog_BuilderClass;
#define VSATTRDEPEND_ALERTDIALOG_BUILDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ALERTDIALOG_BUILDERCLASS                                                   2
extern VS_INT32 SRPCALLBACK AlertDialog_BuilderClass_RequestRegisterObject( );

/*----output event: onKey[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onKey;
/*----output event: onCancel[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onCancel;
/*----output event: onMultiChoiceClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onMultiChoiceClick;
/*----output event: onDismiss[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onDismiss;
/*----output event: onShow[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onShow;
/*----output event: onClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_AlertDialog_BuilderClass_onClick;

/*------Variable Index Define */
#define VSATTRINDEX_ALERTDIALOG_BUILDERCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_ALERTDIALOG_BUILDERCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_ALERTDIALOG_BUILDERCLASS                                                      2

struct StructOfAttachAlertDialog_BuilderClass{
};
struct StructOfAlertDialog_BuilderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SHADERCLASS                                                                      "ShaderClass"
extern VS_UUID VSOBJID_ShaderClass;
#define VSATTRDEPEND_SHADERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SHADERCLASS                                                                2
extern VS_INT32 SRPCALLBACK ShaderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SHADERCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_SHADERCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_SHADERCLASS                                                                   2

struct StructOfAttachShaderClass{
};
struct StructOfShaderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OBJECTBASECLASS                                                                  "ObjectBaseClass"
extern VS_UUID VSOBJID_ObjectBaseClass;
#define VSATTRDEPEND_OBJECTBASECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OBJECTBASECLASS                                                            2
extern VS_INT32 SRPCALLBACK ObjectBaseClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OBJECTBASECLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_OBJECTBASECLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_OBJECTBASECLASS                                                               2

struct StructOfAttachObjectBaseClass{
};
struct StructOfObjectBaseClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LINEARLAYOUTCLASS                                                                "LinearLayoutClass"
extern VS_UUID VSOBJID_LinearLayoutClass;
#define VSATTRDEPEND_LINEARLAYOUTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_LINEARLAYOUTCLASS                                                          5
extern VS_INT32 SRPCALLBACK LinearLayoutClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LINEARLAYOUTCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_LINEARLAYOUTCLASS_OBJECTLIST                                                   1
#define VSATTRINDEX_LINEARLAYOUTCLASS_VIEWGROUPQUEUE                                               2
#define VSATTRINDEX_LINEARLAYOUTCLASS_VIEWQUEUE                                                    3
#define VSATTRINDEX_LINEARLAYOUTCLASS_OBJECTQUEUE                                                  4
#define VSATTRNUMBER_LINEARLAYOUTCLASS                                                             5

struct StructOfAttachLinearLayoutClass{
};
struct StructOfLinearLayoutClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ACTIVITYCLASS                                                                    "ActivityClass"
extern VS_UUID VSOBJID_ActivityClass;
#define VSATTRDEPEND_ACTIVITYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_ACTIVITYCLASS                                                              5
extern VS_INT32 SRPCALLBACK ActivityClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ACTIVITYCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_ACTIVITYCLASS_OBJECTLIST                                                       1
#define VSATTRINDEX_ACTIVITYCLASS_VIEWGROUPQUEUE                                                   2
#define VSATTRINDEX_ACTIVITYCLASS_VIEWQUEUE                                                        3
#define VSATTRINDEX_ACTIVITYCLASS_OBJECTQUEUE                                                      4
#define VSATTRNUMBER_ACTIVITYCLASS                                                                 5

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onStart;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONSTART(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONSTART                                                0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONSTART(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONSTART                                                 0

extern void SRPAPI ActivityClass_onStart(void *Object);
typedef void (SRPAPI *ActivityClass_onStartProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onRestart;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONRESTART(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONRESTART                                              0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONRESTART(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONRESTART                                               0

extern void SRPAPI ActivityClass_onRestart(void *Object);
typedef void (SRPAPI *ActivityClass_onRestartProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onStop;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONSTOP(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONSTOP                                                 0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONSTOP(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONSTOP                                                  0

extern void SRPAPI ActivityClass_onStop(void *Object);
typedef void (SRPAPI *ActivityClass_onStopProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onSaveInstanceState;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONSAVEINSTANCESTATE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONSAVEINSTANCESTATE                                    0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONSAVEINSTANCESTATE(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONSAVEINSTANCESTATE                                     1

extern void SRPAPI ActivityClass_onSaveInstanceState(void *Object,VS_OBJPTR savedInstanceState);
typedef void (SRPAPI *ActivityClass_onSaveInstanceStateProc)(void *Object,VS_OBJPTR savedInstanceState);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onRestoreInstanceState;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONRESTOREINSTANCESTATE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONRESTOREINSTANCESTATE                                 0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONRESTOREINSTANCESTATE(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONRESTOREINSTANCESTATE                                  1

extern void SRPAPI ActivityClass_onRestoreInstanceState(void *Object,VS_OBJPTR savedInstanceState);
typedef void (SRPAPI *ActivityClass_onRestoreInstanceStateProc)(void *Object,VS_OBJPTR savedInstanceState);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onPause;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONPAUSE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONPAUSE                                                0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONPAUSE(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONPAUSE                                                 0

extern void SRPAPI ActivityClass_onPause(void *Object);
typedef void (SRPAPI *ActivityClass_onPauseProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onResume;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONRESUME(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONRESUME                                               0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONRESUME(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONRESUME                                                0

extern void SRPAPI ActivityClass_onResume(void *Object);
typedef void (SRPAPI *ActivityClass_onResumeProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onDestroy;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONDESTROY(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONDESTROY                                              0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONDESTROY(X)  {}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONDESTROY                                               0

extern void SRPAPI ActivityClass_onDestroy(void *Object);
typedef void (SRPAPI *ActivityClass_onDestroyProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onCreateDialog;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONCREATEDIALOG(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONCREATEDIALOG                                         1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONCREATEDIALOG(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONCREATEDIALOG                                          1

extern VS_OBJPTR SRPAPI ActivityClass_onCreateDialog(void *Object,VS_INT32 id);
typedef VS_OBJPTR (SRPAPI *ActivityClass_onCreateDialogProc)(void *Object,VS_INT32 id);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onCreateDialog1;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONCREATEDIALOG1(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONCREATEDIALOG1                                        1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONCREATEDIALOG1(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONCREATEDIALOG1                                         2

extern VS_OBJPTR SRPAPI ActivityClass_onCreateDialog1(void *Object,VS_INT32 id,VS_OBJPTR args);
typedef VS_OBJPTR (SRPAPI *ActivityClass_onCreateDialog1Proc)(void *Object,VS_INT32 id,VS_OBJPTR args);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onPrepareDialog;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONPREPAREDIALOG(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONPREPAREDIALOG                                        1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONPREPAREDIALOG(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONPREPAREDIALOG                                         2

extern VS_BOOL SRPAPI ActivityClass_onPrepareDialog(void *Object,VS_INT32 id,VS_OBJPTR dialog);
typedef VS_BOOL (SRPAPI *ActivityClass_onPrepareDialogProc)(void *Object,VS_INT32 id,VS_OBJPTR dialog);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onPrepareDialog1;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONPREPAREDIALOG1(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONPREPAREDIALOG1                                       1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONPREPAREDIALOG1(X)  {{X[0].Type=6;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONPREPAREDIALOG1                                        3

extern VS_BOOL SRPAPI ActivityClass_onPrepareDialog1(void *Object,VS_INT32 id,VS_OBJPTR dialog,VS_OBJPTR args);
typedef VS_BOOL (SRPAPI *ActivityClass_onPrepareDialog1Proc)(void *Object,VS_INT32 id,VS_OBJPTR dialog,VS_OBJPTR args);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onActivityResult;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONACTIVITYRESULT(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONACTIVITYRESULT                                       0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONACTIVITYRESULT(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONACTIVITYRESULT                                        3

extern void SRPAPI ActivityClass_onActivityResult(void *Object,VS_INT32 requestCode,VS_INT32 resultCode,VS_OBJPTR data);
typedef void (SRPAPI *ActivityClass_onActivityResultProc)(void *Object,VS_INT32 requestCode,VS_INT32 resultCode,VS_OBJPTR data);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onTouchEvent;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONTOUCHEVENT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONTOUCHEVENT                                           1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONTOUCHEVENT(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONTOUCHEVENT                                            1

extern VS_BOOL SRPAPI ActivityClass_onTouchEvent(void *Object,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ActivityClass_onTouchEventProc)(void *Object,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onCreateOptionsMenu;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONCREATEOPTIONSMENU(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONCREATEOPTIONSMENU                                    1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONCREATEOPTIONSMENU(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONCREATEOPTIONSMENU                                     1

extern VS_BOOL SRPAPI ActivityClass_onCreateOptionsMenu(void *Object,VS_OBJPTR menu);
typedef VS_BOOL (SRPAPI *ActivityClass_onCreateOptionsMenuProc)(void *Object,VS_OBJPTR menu);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onPrepareOptionsMenu;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONPREPAREOPTIONSMENU(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONPREPAREOPTIONSMENU                                   1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONPREPAREOPTIONSMENU(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONPREPAREOPTIONSMENU                                    1

extern VS_BOOL SRPAPI ActivityClass_onPrepareOptionsMenu(void *Object,VS_OBJPTR menu);
typedef VS_BOOL (SRPAPI *ActivityClass_onPrepareOptionsMenuProc)(void *Object,VS_OBJPTR menu);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onOptionsItemSelected;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONOPTIONSITEMSELECTED(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONOPTIONSITEMSELECTED                                  1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONOPTIONSITEMSELECTED(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONOPTIONSITEMSELECTED                                   1

extern VS_BOOL SRPAPI ActivityClass_onOptionsItemSelected(void *Object,VS_OBJPTR item);
typedef VS_BOOL (SRPAPI *ActivityClass_onOptionsItemSelectedProc)(void *Object,VS_OBJPTR item);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onCreateContextMenu;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONCREATECONTEXTMENU(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONCREATECONTEXTMENU                                    0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONCREATECONTEXTMENU(X)  {{X[0].Type=57;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONCREATECONTEXTMENU                                     3

extern void SRPAPI ActivityClass_onCreateContextMenu(void *Object,VS_OBJPTR menu,VS_OBJPTR v,VS_OBJPTR menuInfo);
typedef void (SRPAPI *ActivityClass_onCreateContextMenuProc)(void *Object,VS_OBJPTR menu,VS_OBJPTR v,VS_OBJPTR menuInfo);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onContextItemSelected;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONCONTEXTITEMSELECTED(X)  {}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONCONTEXTITEMSELECTED                                  0
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONCONTEXTITEMSELECTED(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONCONTEXTITEMSELECTED                                   1

extern void SRPAPI ActivityClass_onContextItemSelected(void *Object,VS_OBJPTR item);
typedef void (SRPAPI *ActivityClass_onContextItemSelectedProc)(void *Object,VS_OBJPTR item);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onKeyDown;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONKEYDOWN(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONKEYDOWN                                              1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONKEYDOWN(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONKEYDOWN                                               2

extern VS_BOOL SRPAPI ActivityClass_onKeyDown(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ActivityClass_onKeyDownProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onKeyLongPress;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONKEYLONGPRESS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONKEYLONGPRESS                                         1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONKEYLONGPRESS(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONKEYLONGPRESS                                          2

extern VS_BOOL SRPAPI ActivityClass_onKeyLongPress(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ActivityClass_onKeyLongPressProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onKeyMultiple;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONKEYMULTIPLE(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONKEYMULTIPLE                                          1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONKEYMULTIPLE(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONKEYMULTIPLE                                           3

extern VS_BOOL SRPAPI ActivityClass_onKeyMultiple(void *Object,VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ActivityClass_onKeyMultipleProc)(void *Object,VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ActivityClass_onKeyUp;
#define VSFUNCRETURNDEPEND_ACTIVITYCLASS_ONKEYUP(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ACTIVITYCLASS_ONKEYUP                                                1
#define VSFUNCPARAMDEPEND_ACTIVITYCLASS_ONKEYUP(X)  {{X[0].Type=6;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ACTIVITYCLASS_ONKEYUP                                                 2

extern VS_BOOL SRPAPI ActivityClass_onKeyUp(void *Object,VS_INT32 keyCode,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ActivityClass_onKeyUpProc)(void *Object,VS_INT32 keyCode,VS_OBJPTR event);

struct StructOfAttachActivityClass{
};
struct StructOfActivityClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----local attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LOCALECLASS                                                                      "LocaleClass"
extern VS_UUID VSOBJID_LocaleClass;
#define VSATTRDEPEND_LOCALECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LOCALECLASS                                                                2
extern VS_INT32 SRPCALLBACK LocaleClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LOCALECLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_LOCALECLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_LOCALECLASS                                                                   2

struct StructOfAttachLocaleClass{
};
struct StructOfLocaleClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_XMLPULLPARSERCLASS                                                               "XmlPullParserClass"
extern VS_UUID VSOBJID_XmlPullParserClass;
#define VSATTRDEPEND_XMLPULLPARSERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_XMLPULLPARSERCLASS                                                         2
extern VS_INT32 SRPCALLBACK XmlPullParserClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_XMLPULLPARSERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_XMLPULLPARSERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_XMLPULLPARSERCLASS                                                            2

struct StructOfAttachXmlPullParserClass{
};
struct StructOfXmlPullParserClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RADIOBUTTONCLASS                                                                 "RadioButtonClass"
extern VS_UUID VSOBJID_RadioButtonClass;
#define VSATTRDEPEND_RADIOBUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RADIOBUTTONCLASS                                                           2
extern VS_INT32 SRPCALLBACK RadioButtonClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RADIOBUTTONCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_RADIOBUTTONCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_RADIOBUTTONCLASS                                                              2

struct StructOfAttachRadioButtonClass{
};
struct StructOfRadioButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTEXTMENUINFOCLASS                                                             "ContextMenuInfoClass"
extern VS_UUID VSOBJID_ContextMenuInfoClass;
#define VSATTRDEPEND_CONTEXTMENUINFOCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTEXTMENUINFOCLASS                                                       2
extern VS_INT32 SRPCALLBACK ContextMenuInfoClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTEXTMENUINFOCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_CONTEXTMENUINFOCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_CONTEXTMENUINFOCLASS                                                          2

struct StructOfAttachContextMenuInfoClass{
};
struct StructOfContextMenuInfoClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SLIDINGDRAWERCLASS                                                               "SlidingDrawerClass"
extern VS_UUID VSOBJID_SlidingDrawerClass;
#define VSATTRDEPEND_SLIDINGDRAWERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_SLIDINGDRAWERCLASS                                                         5
extern VS_INT32 SRPCALLBACK SlidingDrawerClass_RequestRegisterObject( );

/*----output event: onDrawerClosed[]  Static Event */
extern VS_UUID VSOUTEVENTID_SlidingDrawerClass_onDrawerClosed;
/*----output event: onDrawerOpened[]  Static Event */
extern VS_UUID VSOUTEVENTID_SlidingDrawerClass_onDrawerOpened;
/*----output event: onScrollEnded[]  Static Event */
extern VS_UUID VSOUTEVENTID_SlidingDrawerClass_onScrollEnded;
/*----output event: onScrollStarted[]  Static Event */
extern VS_UUID VSOUTEVENTID_SlidingDrawerClass_onScrollStarted;

/*------Variable Index Define */
#define VSATTRINDEX_SLIDINGDRAWERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SLIDINGDRAWERCLASS_OBJECTLIST                                                  1
#define VSATTRINDEX_SLIDINGDRAWERCLASS_VIEWGROUPQUEUE                                              2
#define VSATTRINDEX_SLIDINGDRAWERCLASS_VIEWQUEUE                                                   3
#define VSATTRINDEX_SLIDINGDRAWERCLASS_OBJECTQUEUE                                                 4
#define VSATTRNUMBER_SLIDINGDRAWERCLASS                                                            5

struct StructOfAttachSlidingDrawerClass{
};
struct StructOfSlidingDrawerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GSMCELLLOCATIONCLASS                                                             "GsmCellLocationClass"
extern VS_UUID VSOBJID_GsmCellLocationClass;
#define VSATTRDEPEND_GSMCELLLOCATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GSMCELLLOCATIONCLASS                                                       2
extern VS_INT32 SRPCALLBACK GsmCellLocationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GSMCELLLOCATIONCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_GSMCELLLOCATIONCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_GSMCELLLOCATIONCLASS                                                          2

struct StructOfAttachGsmCellLocationClass{
};
struct StructOfGsmCellLocationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INTENTCLASS                                                                      "IntentClass"
extern VS_UUID VSOBJID_IntentClass;
#define VSATTRDEPEND_INTENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INTENTCLASS                                                                2
extern VS_INT32 SRPCALLBACK IntentClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INTENTCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_INTENTCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_INTENTCLASS                                                                   2

struct StructOfAttachIntentClass{
};
struct StructOfIntentClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EMBOSSMASKFILTERCLASS                                                            "EmbossMaskFilterClass"
extern VS_UUID VSOBJID_EmbossMaskFilterClass;
#define VSATTRDEPEND_EMBOSSMASKFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EMBOSSMASKFILTERCLASS                                                      2
extern VS_INT32 SRPCALLBACK EmbossMaskFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EMBOSSMASKFILTERCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_EMBOSSMASKFILTERCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_EMBOSSMASKFILTERCLASS                                                         2

struct StructOfAttachEmbossMaskFilterClass{
};
struct StructOfEmbossMaskFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_NETWORKINFOCLASS                                                                 "NetworkInfoClass"
extern VS_UUID VSOBJID_NetworkInfoClass;
#define VSATTRDEPEND_NETWORKINFOCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_NETWORKINFOCLASS                                                           2
extern VS_INT32 SRPCALLBACK NetworkInfoClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_NETWORKINFOCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_NETWORKINFOCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_NETWORKINFOCLASS                                                              2

struct StructOfAttachNetworkInfoClass{
};
struct StructOfNetworkInfoClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DATEPICKERCLASS                                                                  "DatePickerClass"
extern VS_UUID VSOBJID_DatePickerClass;
#define VSATTRDEPEND_DATEPICKERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_DATEPICKERCLASS                                                            5
extern VS_INT32 SRPCALLBACK DatePickerClass_RequestRegisterObject( );

/*----output event: onDateChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_DatePickerClass_onDateChanged;

/*------Variable Index Define */
#define VSATTRINDEX_DATEPICKERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_DATEPICKERCLASS_OBJECTLIST                                                     1
#define VSATTRINDEX_DATEPICKERCLASS_VIEWGROUPQUEUE                                                 2
#define VSATTRINDEX_DATEPICKERCLASS_VIEWQUEUE                                                      3
#define VSATTRINDEX_DATEPICKERCLASS_OBJECTQUEUE                                                    4
#define VSATTRNUMBER_DATEPICKERCLASS                                                               5

struct StructOfAttachDatePickerClass{
};
struct StructOfDatePickerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_AUDIOMANAGERCLASS                                                                "AudioManagerClass"
extern VS_UUID VSOBJID_AudioManagerClass;
#define VSATTRDEPEND_AUDIOMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_AUDIOMANAGERCLASS                                                          2
extern VS_INT32 SRPCALLBACK AudioManagerClass_RequestRegisterObject( );

/*----output event: onAudioFocusChange[]  Static Event */
extern VS_UUID VSOUTEVENTID_AudioManagerClass_onAudioFocusChange;

/*------Variable Index Define */
#define VSATTRINDEX_AUDIOMANAGERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_AUDIOMANAGERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_AUDIOMANAGERCLASS                                                             2

struct StructOfAttachAudioManagerClass{
};
struct StructOfAudioManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INPUTEVENTCLASS                                                                  "InputEventClass"
extern VS_UUID VSOBJID_InputEventClass;
#define VSATTRDEPEND_INPUTEVENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INPUTEVENTCLASS                                                            2
extern VS_INT32 SRPCALLBACK InputEventClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INPUTEVENTCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_INPUTEVENTCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_INPUTEVENTCLASS                                                               2

struct StructOfAttachInputEventClass{
};
struct StructOfInputEventClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ADAPTERCLASS                                                                     "AdapterClass"
extern VS_UUID VSOBJID_AdapterClass;
#define VSATTRDEPEND_ADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ADAPTERCLASS                                                               2
extern VS_INT32 SRPCALLBACK AdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ADAPTERCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_ADAPTERCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_ADAPTERCLASS                                                                  2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getCount;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETCOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETCOUNT                                                1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETCOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETCOUNT                                                 0

extern VS_INT32 SRPAPI AdapterClass_getCount(void *Object);
typedef VS_INT32 (SRPAPI *AdapterClass_getCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getItem;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETITEM(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETITEM                                                 1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETITEM(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETITEM                                                  1

extern VS_INT32 SRPAPI AdapterClass_getItem(void *Object,VS_INT32 position);
typedef VS_INT32 (SRPAPI *AdapterClass_getItemProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getItemId;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETITEMID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETITEMID                                               1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETITEMID(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETITEMID                                                1

extern VS_LONG SRPAPI AdapterClass_getItemId(void *Object,VS_INT32 position);
typedef VS_LONG (SRPAPI *AdapterClass_getItemIdProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getViewTypeCount;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETVIEWTYPECOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETVIEWTYPECOUNT                                        1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETVIEWTYPECOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETVIEWTYPECOUNT                                         0

extern VS_INT32 SRPAPI AdapterClass_getViewTypeCount(void *Object);
typedef VS_INT32 (SRPAPI *AdapterClass_getViewTypeCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getItemViewType;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETITEMVIEWTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETITEMVIEWTYPE                                         1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETITEMVIEWTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETITEMVIEWTYPE                                          1

extern VS_INT32 SRPAPI AdapterClass_getItemViewType(void *Object,VS_INT32 position);
typedef VS_INT32 (SRPAPI *AdapterClass_getItemViewTypeProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_getView;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_GETVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_GETVIEW                                                 1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_GETVIEW(X)  {{X[0].Type=6;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_GETVIEW                                                  3

extern VS_OBJPTR SRPAPI AdapterClass_getView(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *AdapterClass_getViewProc)(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AdapterClass_isEmpty;
#define VSFUNCRETURNDEPEND_ADAPTERCLASS_ISEMPTY(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_ADAPTERCLASS_ISEMPTY                                                 1
#define VSFUNCPARAMDEPEND_ADAPTERCLASS_ISEMPTY(X)  {}
#define VSFUNCPARAMDEPENDNUM_ADAPTERCLASS_ISEMPTY                                                  0

extern VS_BOOL SRPAPI AdapterClass_isEmpty(void *Object);
typedef VS_BOOL (SRPAPI *AdapterClass_isEmptyProc)(void *Object);

struct StructOfAttachAdapterClass{
};
struct StructOfAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BLURMASKFILTERCLASS                                                              "BlurMaskFilterClass"
extern VS_UUID VSOBJID_BlurMaskFilterClass;
#define VSATTRDEPEND_BLURMASKFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BLURMASKFILTERCLASS                                                        2
extern VS_INT32 SRPCALLBACK BlurMaskFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BLURMASKFILTERCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_BLURMASKFILTERCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_BLURMASKFILTERCLASS                                                           2

struct StructOfAttachBlurMaskFilterClass{
};
struct StructOfBlurMaskFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OVERSHOOTINTERPOLATORCLASS                                                       "OvershootInterpolatorClass"
extern VS_UUID VSOBJID_OvershootInterpolatorClass;
#define VSATTRDEPEND_OVERSHOOTINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OVERSHOOTINTERPOLATORCLASS                                                 2
extern VS_INT32 SRPCALLBACK OvershootInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OVERSHOOTINTERPOLATORCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_OVERSHOOTINTERPOLATORCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_OVERSHOOTINTERPOLATORCLASS                                                    2

struct StructOfAttachOvershootInterpolatorClass{
};
struct StructOfOvershootInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COLORDRAWABLECLASS                                                               "ColorDrawableClass"
extern VS_UUID VSOBJID_ColorDrawableClass;
#define VSATTRDEPEND_COLORDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COLORDRAWABLECLASS                                                         2
extern VS_INT32 SRPCALLBACK ColorDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COLORDRAWABLECLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_COLORDRAWABLECLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_COLORDRAWABLECLASS                                                            2

struct StructOfAttachColorDrawableClass{
};
struct StructOfColorDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BITMAPDRAWABLECLASS                                                              "BitmapDrawableClass"
extern VS_UUID VSOBJID_BitmapDrawableClass;
#define VSATTRDEPEND_BITMAPDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BITMAPDRAWABLECLASS                                                        2
extern VS_INT32 SRPCALLBACK BitmapDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BITMAPDRAWABLECLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_BITMAPDRAWABLECLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_BITMAPDRAWABLECLASS                                                           2

struct StructOfAttachBitmapDrawableClass{
};
struct StructOfBitmapDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANTICIPATEINTERPOLATORCLASS                                                      "AnticipateInterpolatorClass"
extern VS_UUID VSOBJID_AnticipateInterpolatorClass;
#define VSATTRDEPEND_ANTICIPATEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANTICIPATEINTERPOLATORCLASS                                                2
extern VS_INT32 SRPCALLBACK AnticipateInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANTICIPATEINTERPOLATORCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_ANTICIPATEINTERPOLATORCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_ANTICIPATEINTERPOLATORCLASS                                                   2

struct StructOfAttachAnticipateInterpolatorClass{
};
struct StructOfAnticipateInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TABSPECCLASS                                                                     "TabSpecClass"
extern VS_UUID VSOBJID_TabSpecClass;
#define VSATTRDEPEND_TABSPECCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TABSPECCLASS                                                               2
extern VS_INT32 SRPCALLBACK TabSpecClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TABSPECCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_TABSPECCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_TABSPECCLASS                                                                  2

struct StructOfAttachTabSpecClass{
};
struct StructOfTabSpecClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BITMAPSHADERCLASS                                                                "BitmapShaderClass"
extern VS_UUID VSOBJID_BitmapShaderClass;
#define VSATTRDEPEND_BITMAPSHADERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BITMAPSHADERCLASS                                                          2
extern VS_INT32 SRPCALLBACK BitmapShaderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BITMAPSHADERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_BITMAPSHADERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_BITMAPSHADERCLASS                                                             2

struct StructOfAttachBitmapShaderClass{
};
struct StructOfBitmapShaderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EDITTEXTCLASS                                                                    "EditTextClass"
extern VS_UUID VSOBJID_EditTextClass;
#define VSATTRDEPEND_EDITTEXTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EDITTEXTCLASS                                                              2
extern VS_INT32 SRPCALLBACK EditTextClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EDITTEXTCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_EDITTEXTCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_EDITTEXTCLASS                                                                 2

struct StructOfAttachEditTextClass{
};
struct StructOfEditTextClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANDROIDBASECLASS                                                                 "AndroidBaseClass"
extern VS_UUID VSOBJID_AndroidBaseClass;
#define VSATTRDEPEND_ANDROIDBASECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANDROIDBASECLASS                                                           2
extern VS_INT32 SRPCALLBACK AndroidBaseClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANDROIDBASECLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ANDROIDBASECLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_ANDROIDBASECLASS                                                              2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_AndroidBaseClass_onDownPreExecute;
#define VSFUNCRETURNDEPEND_ANDROIDBASECLASS_ONDOWNPREEXECUTE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ANDROIDBASECLASS_ONDOWNPREEXECUTE                                    0
#define VSFUNCPARAMDEPEND_ANDROIDBASECLASS_ONDOWNPREEXECUTE(X)  {{X[0].Type=6;}{X[1].Type=30;}{X[2].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_ANDROIDBASECLASS_ONDOWNPREEXECUTE                                     3

extern void SRPAPI AndroidBaseClass_onDownPreExecute(void *Object,VS_INT32 downloadId,VS_CHAR * url,VS_CHAR * fileName);
typedef void (SRPAPI *AndroidBaseClass_onDownPreExecuteProc)(void *Object,VS_INT32 downloadId,VS_CHAR * url,VS_CHAR * fileName);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AndroidBaseClass_onDownProgressUpdate;
#define VSFUNCRETURNDEPEND_ANDROIDBASECLASS_ONDOWNPROGRESSUPDATE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ANDROIDBASECLASS_ONDOWNPROGRESSUPDATE                                0
#define VSFUNCPARAMDEPEND_ANDROIDBASECLASS_ONDOWNPROGRESSUPDATE(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_ANDROIDBASECLASS_ONDOWNPROGRESSUPDATE                                 3

extern void SRPAPI AndroidBaseClass_onDownProgressUpdate(void *Object,VS_INT32 downloadId,VS_INT32 downloadSize,VS_INT32 maxSize);
typedef void (SRPAPI *AndroidBaseClass_onDownProgressUpdateProc)(void *Object,VS_INT32 downloadId,VS_INT32 downloadSize,VS_INT32 maxSize);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_AndroidBaseClass_onDownPostExecute;
#define VSFUNCRETURNDEPEND_ANDROIDBASECLASS_ONDOWNPOSTEXECUTE(X)  {}
#define VSFUNCRETURNDEPENDNUM_ANDROIDBASECLASS_ONDOWNPOSTEXECUTE                                   0
#define VSFUNCPARAMDEPEND_ANDROIDBASECLASS_ONDOWNPOSTEXECUTE(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=6;}{X[3].Type=30;}{X[4].Type=59;}}
#define VSFUNCPARAMDEPENDNUM_ANDROIDBASECLASS_ONDOWNPOSTEXECUTE                                    5

extern void SRPAPI AndroidBaseClass_onDownPostExecute(void *Object,VS_INT32 downloadId,VS_INT32 result,VS_INT32 maxDownloadSize,VS_CHAR * fileName,VS_BINBUFPTR binbuf);
typedef void (SRPAPI *AndroidBaseClass_onDownPostExecuteProc)(void *Object,VS_INT32 downloadId,VS_INT32 result,VS_INT32 maxDownloadSize,VS_CHAR * fileName,VS_BINBUFPTR binbuf);

struct StructOfAttachAndroidBaseClass{
};
struct StructOfAndroidBaseClass{
    //----local attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_FILEOUTPUTSTREAMCLASS                                                            "FileOutputStreamClass"
extern VS_UUID VSOBJID_FileOutputStreamClass;
#define VSATTRDEPEND_FILEOUTPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_FILEOUTPUTSTREAMCLASS                                                      2
extern VS_INT32 SRPCALLBACK FileOutputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_FILEOUTPUTSTREAMCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_FILEOUTPUTSTREAMCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_FILEOUTPUTSTREAMCLASS                                                         2

struct StructOfAttachFileOutputStreamClass{
};
struct StructOfFileOutputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CORNERPATHEFFECTCLASS                                                            "CornerPathEffectClass"
extern VS_UUID VSOBJID_CornerPathEffectClass;
#define VSATTRDEPEND_CORNERPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CORNERPATHEFFECTCLASS                                                      2
extern VS_INT32 SRPCALLBACK CornerPathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CORNERPATHEFFECTCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_CORNERPATHEFFECTCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_CORNERPATHEFFECTCLASS                                                         2

struct StructOfAttachCornerPathEffectClass{
};
struct StructOfCornerPathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BROADCASTRECEIVERCLASS                                                           "BroadcastReceiverClass"
extern VS_UUID VSOBJID_BroadcastReceiverClass;
#define VSATTRDEPEND_BROADCASTRECEIVERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BROADCASTRECEIVERCLASS                                                     2
extern VS_INT32 SRPCALLBACK BroadcastReceiverClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BROADCASTRECEIVERCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_BROADCASTRECEIVERCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_BROADCASTRECEIVERCLASS                                                        2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_BroadcastReceiverClass_onReceive;
#define VSFUNCRETURNDEPEND_BROADCASTRECEIVERCLASS_ONRECEIVE(X)  {}
#define VSFUNCRETURNDEPENDNUM_BROADCASTRECEIVERCLASS_ONRECEIVE                                     0
#define VSFUNCPARAMDEPEND_BROADCASTRECEIVERCLASS_ONRECEIVE(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_BROADCASTRECEIVERCLASS_ONRECEIVE                                      1

extern void SRPAPI BroadcastReceiverClass_onReceive(void *Object,VS_OBJPTR intent);
typedef void (SRPAPI *BroadcastReceiverClass_onReceiveProc)(void *Object,VS_OBJPTR intent);

struct StructOfAttachBroadcastReceiverClass{
};
struct StructOfBroadcastReceiverClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_FILEDESCRIPTORCLASS                                                              "FileDescriptorClass"
extern VS_UUID VSOBJID_FileDescriptorClass;
#define VSATTRDEPEND_FILEDESCRIPTORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_FILEDESCRIPTORCLASS                                                        2
extern VS_INT32 SRPCALLBACK FileDescriptorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_FILEDESCRIPTORCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_FILEDESCRIPTORCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_FILEDESCRIPTORCLASS                                                           2

struct StructOfAttachFileDescriptorClass{
};
struct StructOfFileDescriptorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_REMOTEVIEWSCLASS                                                                 "RemoteViewsClass"
extern VS_UUID VSOBJID_RemoteViewsClass;
#define VSATTRDEPEND_REMOTEVIEWSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_REMOTEVIEWSCLASS                                                           2
extern VS_INT32 SRPCALLBACK RemoteViewsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_REMOTEVIEWSCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_REMOTEVIEWSCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_REMOTEVIEWSCLASS                                                              2

struct StructOfAttachRemoteViewsClass{
};
struct StructOfRemoteViewsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWANIMATORCLASS                                                                "ViewAnimatorClass"
extern VS_UUID VSOBJID_ViewAnimatorClass;
#define VSATTRDEPEND_VIEWANIMATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_VIEWANIMATORCLASS                                                          5
extern VS_INT32 SRPCALLBACK ViewAnimatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWANIMATORCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_VIEWANIMATORCLASS_OBJECTLIST                                                   1
#define VSATTRINDEX_VIEWANIMATORCLASS_VIEWGROUPQUEUE                                               2
#define VSATTRINDEX_VIEWANIMATORCLASS_VIEWQUEUE                                                    3
#define VSATTRINDEX_VIEWANIMATORCLASS_OBJECTQUEUE                                                  4
#define VSATTRNUMBER_VIEWANIMATORCLASS                                                             5

struct StructOfAttachViewAnimatorClass{
};
struct StructOfViewAnimatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SURFACEHOLDERCLASS                                                               "SurfaceHolderClass"
extern VS_UUID VSOBJID_SurfaceHolderClass;
#define VSATTRDEPEND_SURFACEHOLDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SURFACEHOLDERCLASS                                                         2
extern VS_INT32 SRPCALLBACK SurfaceHolderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SURFACEHOLDERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SURFACEHOLDERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SURFACEHOLDERCLASS                                                            2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_SurfaceHolderClass_surfaceChanged;
#define VSFUNCRETURNDEPEND_SURFACEHOLDERCLASS_SURFACECHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_SURFACEHOLDERCLASS_SURFACECHANGED                                    0
#define VSFUNCPARAMDEPEND_SURFACEHOLDERCLASS_SURFACECHANGED(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_SURFACEHOLDERCLASS_SURFACECHANGED                                     3

extern void SRPAPI SurfaceHolderClass_surfaceChanged(void *Object,VS_INT32 format,VS_INT32 width,VS_INT32 height);
typedef void (SRPAPI *SurfaceHolderClass_surfaceChangedProc)(void *Object,VS_INT32 format,VS_INT32 width,VS_INT32 height);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_SurfaceHolderClass_surfaceCreated;
#define VSFUNCRETURNDEPEND_SURFACEHOLDERCLASS_SURFACECREATED(X)  {}
#define VSFUNCRETURNDEPENDNUM_SURFACEHOLDERCLASS_SURFACECREATED                                    0
#define VSFUNCPARAMDEPEND_SURFACEHOLDERCLASS_SURFACECREATED(X)  {}
#define VSFUNCPARAMDEPENDNUM_SURFACEHOLDERCLASS_SURFACECREATED                                     0

extern void SRPAPI SurfaceHolderClass_surfaceCreated(void *Object);
typedef void (SRPAPI *SurfaceHolderClass_surfaceCreatedProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_SurfaceHolderClass_surfaceDestroyed;
#define VSFUNCRETURNDEPEND_SURFACEHOLDERCLASS_SURFACEDESTROYED(X)  {}
#define VSFUNCRETURNDEPENDNUM_SURFACEHOLDERCLASS_SURFACEDESTROYED                                  0
#define VSFUNCPARAMDEPEND_SURFACEHOLDERCLASS_SURFACEDESTROYED(X)  {}
#define VSFUNCPARAMDEPENDNUM_SURFACEHOLDERCLASS_SURFACEDESTROYED                                   0

extern void SRPAPI SurfaceHolderClass_surfaceDestroyed(void *Object);
typedef void (SRPAPI *SurfaceHolderClass_surfaceDestroyedProc)(void *Object);

struct StructOfAttachSurfaceHolderClass{
};
struct StructOfSurfaceHolderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TABCONTENTFACTORYCLASS                                                           "TabContentFactoryClass"
extern VS_UUID VSOBJID_TabContentFactoryClass;
#define VSATTRDEPEND_TABCONTENTFACTORYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TABCONTENTFACTORYCLASS                                                     2
extern VS_INT32 SRPCALLBACK TabContentFactoryClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TABCONTENTFACTORYCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_TABCONTENTFACTORYCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_TABCONTENTFACTORYCLASS                                                        2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_TabContentFactoryClass_createTabContent;
#define VSFUNCRETURNDEPEND_TABCONTENTFACTORYCLASS_CREATETABCONTENT(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_TABCONTENTFACTORYCLASS_CREATETABCONTENT                              1
#define VSFUNCPARAMDEPEND_TABCONTENTFACTORYCLASS_CREATETABCONTENT(X)  {{X[0].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_TABCONTENTFACTORYCLASS_CREATETABCONTENT                               1

extern VS_OBJPTR SRPAPI TabContentFactoryClass_createTabContent(void *Object,VS_CHAR * tag);
typedef VS_OBJPTR (SRPAPI *TabContentFactoryClass_createTabContentProc)(void *Object,VS_CHAR * tag);

struct StructOfAttachTabContentFactoryClass{
};
struct StructOfTabContentFactoryClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BITMAPCLASS                                                                      "BitmapClass"
extern VS_UUID VSOBJID_BitmapClass;
#define VSATTRDEPEND_BITMAPCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BITMAPCLASS                                                                2
extern VS_INT32 SRPCALLBACK BitmapClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BITMAPCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_BITMAPCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_BITMAPCLASS                                                                   2

struct StructOfAttachBitmapClass{
};
struct StructOfBitmapClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SENSOREVENTCLASS                                                                 "SensorEventClass"
extern VS_UUID VSOBJID_SensorEventClass;
#define VSATTRDEPEND_SENSOREVENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SENSOREVENTCLASS                                                           2
extern VS_INT32 SRPCALLBACK SensorEventClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SENSOREVENTCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_SENSOREVENTCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_SENSOREVENTCLASS                                                              2

struct StructOfAttachSensorEventClass{
};
struct StructOfSensorEventClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SIMPLETIMEZONECLASS                                                              "SimpleTimeZoneClass"
extern VS_UUID VSOBJID_SimpleTimeZoneClass;
#define VSATTRDEPEND_SIMPLETIMEZONECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SIMPLETIMEZONECLASS                                                        2
extern VS_INT32 SRPCALLBACK SimpleTimeZoneClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SIMPLETIMEZONECLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_SIMPLETIMEZONECLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_SIMPLETIMEZONECLASS                                                           2

struct StructOfAttachSimpleTimeZoneClass{
};
struct StructOfSimpleTimeZoneClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PATHDASHPATHEFFECTCLASS                                                          "PathDashPathEffectClass"
extern VS_UUID VSOBJID_PathDashPathEffectClass;
#define VSATTRDEPEND_PATHDASHPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PATHDASHPATHEFFECTCLASS                                                    2
extern VS_INT32 SRPCALLBACK PathDashPathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PATHDASHPATHEFFECTCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_PATHDASHPATHEFFECTCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_PATHDASHPATHEFFECTCLASS                                                       2

struct StructOfAttachPathDashPathEffectClass{
};
struct StructOfPathDashPathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CELLLOCATIONCLASS                                                                "CellLocationClass"
extern VS_UUID VSOBJID_CellLocationClass;
#define VSATTRDEPEND_CELLLOCATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CELLLOCATIONCLASS                                                          2
extern VS_INT32 SRPCALLBACK CellLocationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CELLLOCATIONCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_CELLLOCATIONCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_CELLLOCATIONCLASS                                                             2

struct StructOfAttachCellLocationClass{
};
struct StructOfCellLocationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_FRAMELAYOUTCLASS                                                                 "FrameLayoutClass"
extern VS_UUID VSOBJID_FrameLayoutClass;
#define VSATTRDEPEND_FRAMELAYOUTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_FRAMELAYOUTCLASS                                                           5
extern VS_INT32 SRPCALLBACK FrameLayoutClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_FRAMELAYOUTCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_FRAMELAYOUTCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_FRAMELAYOUTCLASS_VIEWGROUPQUEUE                                                2
#define VSATTRINDEX_FRAMELAYOUTCLASS_VIEWQUEUE                                                     3
#define VSATTRINDEX_FRAMELAYOUTCLASS_OBJECTQUEUE                                                   4
#define VSATTRNUMBER_FRAMELAYOUTCLASS                                                              5

struct StructOfAttachFrameLayoutClass{
};
struct StructOfFrameLayoutClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_URIMATCHERCLASS                                                                  "UriMatcherClass"
extern VS_UUID VSOBJID_UriMatcherClass;
#define VSATTRDEPEND_URIMATCHERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_URIMATCHERCLASS                                                            2
extern VS_INT32 SRPCALLBACK UriMatcherClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_URIMATCHERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_URIMATCHERCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_URIMATCHERCLASS                                                               2

struct StructOfAttachUriMatcherClass{
};
struct StructOfUriMatcherClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_FILECLASS                                                                        "FileClass"
extern VS_UUID VSOBJID_FileClass;
#define VSATTRDEPEND_FILECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_FILECLASS                                                                  2
extern VS_INT32 SRPCALLBACK FileClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_FILECLASS_ANDROIDREFCOUNT                                                      0
#define VSATTRINDEX_FILECLASS_OBJECTLIST                                                           1
#define VSATTRNUMBER_FILECLASS                                                                     2

struct StructOfAttachFileClass{
};
struct StructOfFileClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RATINGBARCLASS                                                                   "RatingBarClass"
extern VS_UUID VSOBJID_RatingBarClass;
#define VSATTRDEPEND_RATINGBARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RATINGBARCLASS                                                             2
extern VS_INT32 SRPCALLBACK RatingBarClass_RequestRegisterObject( );

/*----output event: onRatingChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_RatingBarClass_onRatingChanged;

/*------Variable Index Define */
#define VSATTRINDEX_RATINGBARCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_RATINGBARCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_RATINGBARCLASS                                                                2

struct StructOfAttachRatingBarClass{
};
struct StructOfRatingBarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ACCELERATEINTERPOLATORCLASS                                                      "AccelerateInterpolatorClass"
extern VS_UUID VSOBJID_AccelerateInterpolatorClass;
#define VSATTRDEPEND_ACCELERATEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ACCELERATEINTERPOLATORCLASS                                                2
extern VS_INT32 SRPCALLBACK AccelerateInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ACCELERATEINTERPOLATORCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_ACCELERATEINTERPOLATORCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_ACCELERATEINTERPOLATORCLASS                                                   2

struct StructOfAttachAccelerateInterpolatorClass{
};
struct StructOfAccelerateInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MENUINFLATERCLASS                                                                "MenuInflaterClass"
extern VS_UUID VSOBJID_MenuInflaterClass;
#define VSATTRDEPEND_MENUINFLATERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MENUINFLATERCLASS                                                          2
extern VS_INT32 SRPCALLBACK MenuInflaterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MENUINFLATERCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_MENUINFLATERCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_MENUINFLATERCLASS                                                             2

struct StructOfAttachMenuInflaterClass{
};
struct StructOfMenuInflaterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MEDIARECORDERCLASS                                                               "MediaRecorderClass"
extern VS_UUID VSOBJID_MediaRecorderClass;
#define VSATTRDEPEND_MEDIARECORDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MEDIARECORDERCLASS                                                         2
extern VS_INT32 SRPCALLBACK MediaRecorderClass_RequestRegisterObject( );

/*----output event: onError[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaRecorderClass_onError;
/*----output event: onInfo[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaRecorderClass_onInfo;

/*------Variable Index Define */
#define VSATTRINDEX_MEDIARECORDERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_MEDIARECORDERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_MEDIARECORDERCLASS                                                            2

struct StructOfAttachMediaRecorderClass{
};
struct StructOfMediaRecorderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DIALOGCLASS                                                                      "DialogClass"
extern VS_UUID VSOBJID_DialogClass;
#define VSATTRDEPEND_DIALOGCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DIALOGCLASS                                                                2
extern VS_INT32 SRPCALLBACK DialogClass_RequestRegisterObject( );

/*----output event: onKey[]  Static Event */
extern VS_UUID VSOUTEVENTID_DialogClass_onKey;
/*----output event: onCancel[]  Static Event */
extern VS_UUID VSOUTEVENTID_DialogClass_onCancel;
/*----output event: onDismiss[]  Static Event */
extern VS_UUID VSOUTEVENTID_DialogClass_onDismiss;
/*----output event: onShow[]  Static Event */
extern VS_UUID VSOUTEVENTID_DialogClass_onShow;

/*------Variable Index Define */
#define VSATTRINDEX_DIALOGCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_DIALOGCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_DIALOGCLASS                                                                   2

struct StructOfAttachDialogClass{
};
struct StructOfDialogClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SRPWRAPANDROIDENGINE                                                             "SRPWrapAndroidEngine"
extern VS_UUID VSOBJID_SRPWrapAndroidEngine;

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PATHEFFECTCLASS                                                                  "PathEffectClass"
extern VS_UUID VSOBJID_PathEffectClass;
#define VSATTRDEPEND_PATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PATHEFFECTCLASS                                                            2
extern VS_INT32 SRPCALLBACK PathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PATHEFFECTCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_PATHEFFECTCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_PATHEFFECTCLASS                                                               2

struct StructOfAttachPathEffectClass{
};
struct StructOfPathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RECTFCLASS                                                                       "RectFClass"
extern VS_UUID VSOBJID_RectFClass;
#define VSATTRDEPEND_RECTFCLASS(X)  {{X[0].Type=8;X[0].Offset=0;}{X[1].Type=8;X[1].Offset=4;}{X[2].Type=8;X[2].Offset=8;}{X[3].Type=8;X[3].Offset=12;}}
#define VSATTRDEPENDNUM_RECTFCLASS                                                                 4
extern VS_INT32 SRPCALLBACK RectFClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RECTFCLASS_LEFT                                                                0
#define VSATTRINDEX_RECTFCLASS_TOP                                                                 1
#define VSATTRINDEX_RECTFCLASS_RIGHT                                                               2
#define VSATTRINDEX_RECTFCLASS_BOTTOM                                                              3
#define VSATTRNUMBER_RECTFCLASS                                                                    4

struct StructOfAttachRectFClass{
};
struct StructOfRectFClass{
    //----local attribute
    VS_FLOAT        left;                         //
    VS_FLOAT        top;                          //
    VS_FLOAT        right;                        //
    VS_FLOAT        bottom;                       //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ZOOMBUTTONCLASS                                                                  "ZoomButtonClass"
extern VS_UUID VSOBJID_ZoomButtonClass;
#define VSATTRDEPEND_ZOOMBUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ZOOMBUTTONCLASS                                                            2
extern VS_INT32 SRPCALLBACK ZoomButtonClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ZOOMBUTTONCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_ZOOMBUTTONCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_ZOOMBUTTONCLASS                                                               2

struct StructOfAttachZoomButtonClass{
};
struct StructOfZoomButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_IMAGEBUTTONCLASS                                                                 "ImageButtonClass"
extern VS_UUID VSOBJID_ImageButtonClass;
#define VSATTRDEPEND_IMAGEBUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_IMAGEBUTTONCLASS                                                           2
extern VS_INT32 SRPCALLBACK ImageButtonClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_IMAGEBUTTONCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_IMAGEBUTTONCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_IMAGEBUTTONCLASS                                                              2

struct StructOfAttachImageButtonClass{
};
struct StructOfImageButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_STRINGARRAYADAPTERCLASS                                                          "StringArrayAdapterClass"
extern VS_UUID VSOBJID_StringArrayAdapterClass;
#define VSATTRDEPEND_STRINGARRAYADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_STRINGARRAYADAPTERCLASS                                                    2
extern VS_INT32 SRPCALLBACK StringArrayAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_STRINGARRAYADAPTERCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_STRINGARRAYADAPTERCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_STRINGARRAYADAPTERCLASS                                                       2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_StringArrayAdapterClass_getView;
#define VSFUNCRETURNDEPEND_STRINGARRAYADAPTERCLASS_GETVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_STRINGARRAYADAPTERCLASS_GETVIEW                                      1
#define VSFUNCPARAMDEPEND_STRINGARRAYADAPTERCLASS_GETVIEW(X)  {{X[0].Type=6;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_STRINGARRAYADAPTERCLASS_GETVIEW                                       3

extern VS_OBJPTR SRPAPI StringArrayAdapterClass_getView(void *Object,VS_INT32 Position,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *StringArrayAdapterClass_getViewProc)(void *Object,VS_INT32 Position,VS_OBJPTR convertView,VS_OBJPTR parent);

struct StructOfAttachStringArrayAdapterClass{
};
struct StructOfStringArrayAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMPONENTNAMECLASS                                                               "ComponentNameClass"
extern VS_UUID VSOBJID_ComponentNameClass;
#define VSATTRDEPEND_COMPONENTNAMECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMPONENTNAMECLASS                                                         2
extern VS_INT32 SRPCALLBACK ComponentNameClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COMPONENTNAMECLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_COMPONENTNAMECLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_COMPONENTNAMECLASS                                                            2

struct StructOfAttachComponentNameClass{
};
struct StructOfComponentNameClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CRITERIACLASS                                                                    "CriteriaClass"
extern VS_UUID VSOBJID_CriteriaClass;
#define VSATTRDEPEND_CRITERIACLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CRITERIACLASS                                                              2
extern VS_INT32 SRPCALLBACK CriteriaClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CRITERIACLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_CRITERIACLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_CRITERIACLASS                                                                 2

struct StructOfAttachCriteriaClass{
};
struct StructOfCriteriaClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SUBMENUCLASS                                                                     "SubMenuClass"
extern VS_UUID VSOBJID_SubMenuClass;
#define VSATTRDEPEND_SUBMENUCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SUBMENUCLASS                                                               2
extern VS_INT32 SRPCALLBACK SubMenuClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SUBMENUCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_SUBMENUCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_SUBMENUCLASS                                                                  2

struct StructOfAttachSubMenuClass{
};
struct StructOfSubMenuClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIBRATORCLASS                                                                    "VibratorClass"
extern VS_UUID VSOBJID_VibratorClass;
#define VSATTRDEPEND_VIBRATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIBRATORCLASS                                                              2
extern VS_INT32 SRPCALLBACK VibratorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIBRATORCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_VIBRATORCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_VIBRATORCLASS                                                                 2

struct StructOfAttachVibratorClass{
};
struct StructOfVibratorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PATHCLASS                                                                        "PathClass"
extern VS_UUID VSOBJID_PathClass;
#define VSATTRDEPEND_PATHCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PATHCLASS                                                                  2
extern VS_INT32 SRPCALLBACK PathClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PATHCLASS_ANDROIDREFCOUNT                                                      0
#define VSATTRINDEX_PATHCLASS_OBJECTLIST                                                           1
#define VSATTRNUMBER_PATHCLASS                                                                     2

struct StructOfAttachPathClass{
};
struct StructOfPathClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ROUNDRECTSHAPECLASS                                                              "RoundRectShapeClass"
extern VS_UUID VSOBJID_RoundRectShapeClass;
#define VSATTRDEPEND_ROUNDRECTSHAPECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ROUNDRECTSHAPECLASS                                                        2
extern VS_INT32 SRPCALLBACK RoundRectShapeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ROUNDRECTSHAPECLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_ROUNDRECTSHAPECLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_ROUNDRECTSHAPECLASS                                                           2

struct StructOfAttachRoundRectShapeClass{
};
struct StructOfRoundRectShapeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTENTOBSERVERCLASS                                                             "ContentObserverClass"
extern VS_UUID VSOBJID_ContentObserverClass;
#define VSATTRDEPEND_CONTENTOBSERVERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTENTOBSERVERCLASS                                                       2
extern VS_INT32 SRPCALLBACK ContentObserverClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTENTOBSERVERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_CONTENTOBSERVERCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_CONTENTOBSERVERCLASS                                                          2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ContentObserverClass_deliverSelfNotifications;
#define VSFUNCRETURNDEPEND_CONTENTOBSERVERCLASS_DELIVERSELFNOTIFICATIONS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_CONTENTOBSERVERCLASS_DELIVERSELFNOTIFICATIONS                        1
#define VSFUNCPARAMDEPEND_CONTENTOBSERVERCLASS_DELIVERSELFNOTIFICATIONS(X)  {}
#define VSFUNCPARAMDEPENDNUM_CONTENTOBSERVERCLASS_DELIVERSELFNOTIFICATIONS                         0

extern VS_BOOL SRPAPI ContentObserverClass_deliverSelfNotifications(void *Object);
typedef VS_BOOL (SRPAPI *ContentObserverClass_deliverSelfNotificationsProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_ContentObserverClass_onChange;
#define VSFUNCRETURNDEPEND_CONTENTOBSERVERCLASS_ONCHANGE(X)  {}
#define VSFUNCRETURNDEPENDNUM_CONTENTOBSERVERCLASS_ONCHANGE                                        0
#define VSFUNCPARAMDEPEND_CONTENTOBSERVERCLASS_ONCHANGE(X)  {{X[0].Type=1;}}
#define VSFUNCPARAMDEPENDNUM_CONTENTOBSERVERCLASS_ONCHANGE                                         1

extern void SRPAPI ContentObserverClass_onChange(void *Object,VS_BOOL selfChange);
typedef void (SRPAPI *ContentObserverClass_onChangeProc)(void *Object,VS_BOOL selfChange);

struct StructOfAttachContentObserverClass{
};
struct StructOfContentObserverClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SHAPEDRAWABLECLASS                                                               "ShapeDrawableClass"
extern VS_UUID VSOBJID_ShapeDrawableClass;
#define VSATTRDEPEND_SHAPEDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SHAPEDRAWABLECLASS                                                         2
extern VS_INT32 SRPCALLBACK ShapeDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SHAPEDRAWABLECLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SHAPEDRAWABLECLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SHAPEDRAWABLECLASS                                                            2

struct StructOfAttachShapeDrawableClass{
};
struct StructOfShapeDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BITMAPFACTORYCLASS                                                               "BitmapFactoryClass"
extern VS_UUID VSOBJID_BitmapFactoryClass;
#define VSATTRDEPEND_BITMAPFACTORYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BITMAPFACTORYCLASS                                                         2
extern VS_INT32 SRPCALLBACK BitmapFactoryClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BITMAPFACTORYCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_BITMAPFACTORYCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_BITMAPFACTORYCLASS                                                            2

struct StructOfAttachBitmapFactoryClass{
};
struct StructOfBitmapFactoryClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TEXTVIEWCLASS                                                                    "TextViewClass"
extern VS_UUID VSOBJID_TextViewClass;
#define VSATTRDEPEND_TEXTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TEXTVIEWCLASS                                                              2
extern VS_INT32 SRPCALLBACK TextViewClass_RequestRegisterObject( );

/*----output event: onTextChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TextViewClass_onTextChanged;
/*----output event: beforeTextChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TextViewClass_beforeTextChanged;
/*----output event: afterTextChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TextViewClass_afterTextChanged;

/*------Variable Index Define */
#define VSATTRINDEX_TEXTVIEWCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_TEXTVIEWCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_TEXTVIEWCLASS                                                                 2

struct StructOfAttachTextViewClass{
};
struct StructOfTextViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_URICLASS                                                                         "UriClass"
extern VS_UUID VSOBJID_UriClass;
#define VSATTRDEPEND_URICLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_URICLASS                                                                   2
extern VS_INT32 SRPCALLBACK UriClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_URICLASS_ANDROIDREFCOUNT                                                       0
#define VSATTRINDEX_URICLASS_OBJECTLIST                                                            1
#define VSATTRNUMBER_URICLASS                                                                      2

struct StructOfAttachUriClass{
};
struct StructOfUriClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OUTPUTSTREAMCLASS                                                                "OutputStreamClass"
extern VS_UUID VSOBJID_OutputStreamClass;
#define VSATTRDEPEND_OUTPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OUTPUTSTREAMCLASS                                                          2
extern VS_INT32 SRPCALLBACK OutputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OUTPUTSTREAMCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_OUTPUTSTREAMCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_OUTPUTSTREAMCLASS                                                             2

struct StructOfAttachOutputStreamClass{
};
struct StructOfOutputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ARCSHAPECLASS                                                                    "ArcShapeClass"
extern VS_UUID VSOBJID_ArcShapeClass;
#define VSATTRDEPEND_ARCSHAPECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ARCSHAPECLASS                                                              2
extern VS_INT32 SRPCALLBACK ArcShapeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ARCSHAPECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_ARCSHAPECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_ARCSHAPECLASS                                                                 2

struct StructOfAttachArcShapeClass{
};
struct StructOfArcShapeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LAYERDRAWABLECLASS                                                               "LayerDrawableClass"
extern VS_UUID VSOBJID_LayerDrawableClass;
#define VSATTRDEPEND_LAYERDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LAYERDRAWABLECLASS                                                         2
extern VS_INT32 SRPCALLBACK LayerDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LAYERDRAWABLECLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_LAYERDRAWABLECLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_LAYERDRAWABLECLASS                                                            2

struct StructOfAttachLayerDrawableClass{
};
struct StructOfLayerDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_KEYEVENTCLASS                                                                    "KeyEventClass"
extern VS_UUID VSOBJID_KeyEventClass;
#define VSATTRDEPEND_KEYEVENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_KEYEVENTCLASS                                                              2
extern VS_INT32 SRPCALLBACK KeyEventClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_KEYEVENTCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_KEYEVENTCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_KEYEVENTCLASS                                                                 2

struct StructOfAttachKeyEventClass{
};
struct StructOfKeyEventClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TIMEPICKERDIALOGCLASS                                                            "TimePickerDialogClass"
extern VS_UUID VSOBJID_TimePickerDialogClass;
#define VSATTRDEPEND_TIMEPICKERDIALOGCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}}
#define VSATTRDEPENDNUM_TIMEPICKERDIALOGCLASS                                                      3
extern VS_INT32 SRPCALLBACK TimePickerDialogClass_RequestRegisterObject( );

/*----output event: onTimeSet[]  Static Event */
extern VS_UUID VSOUTEVENTID_TimePickerDialogClass_onTimeSet;

/*------Variable Index Define */
#define VSATTRINDEX_TIMEPICKERDIALOGCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_TIMEPICKERDIALOGCLASS_OBJECTLIST                                               1
#define VSATTRINDEX_TIMEPICKERDIALOGCLASS_DIALOGINTERFACEQUEUE                                     2
#define VSATTRNUMBER_TIMEPICKERDIALOGCLASS                                                         3

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_TimePickerDialogClass_onTimeChanged;
#define VSFUNCRETURNDEPEND_TIMEPICKERDIALOGCLASS_ONTIMECHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_TIMEPICKERDIALOGCLASS_ONTIMECHANGED                                  0
#define VSFUNCPARAMDEPEND_TIMEPICKERDIALOGCLASS_ONTIMECHANGED(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_TIMEPICKERDIALOGCLASS_ONTIMECHANGED                                   2

extern void SRPAPI TimePickerDialogClass_onTimeChanged(void *Object,VS_INT32 hourOfDay,VS_INT32 minute);
typedef void (SRPAPI *TimePickerDialogClass_onTimeChangedProc)(void *Object,VS_INT32 hourOfDay,VS_INT32 minute);

struct StructOfAttachTimePickerDialogClass{
};
struct StructOfTimePickerDialogClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[AlertDialogClass] attribute
    void            *DialogInterfaceQueue;        //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SMSMANAGERCLASS                                                                  "SmsManagerClass"
extern VS_UUID VSOBJID_SmsManagerClass;
#define VSATTRDEPEND_SMSMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SMSMANAGERCLASS                                                            2
extern VS_INT32 SRPCALLBACK SmsManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SMSMANAGERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_SMSMANAGERCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_SMSMANAGERCLASS                                                               2

struct StructOfAttachSmsManagerClass{
};
struct StructOfSmsManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIDEOVIEWCLASS                                                                   "VideoViewClass"
extern VS_UUID VSOBJID_VideoViewClass;
#define VSATTRDEPEND_VIDEOVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIDEOVIEWCLASS                                                             2
extern VS_INT32 SRPCALLBACK VideoViewClass_RequestRegisterObject( );

/*----output event: onCompletion[]  Static Event */
extern VS_UUID VSOUTEVENTID_VideoViewClass_onCompletion;
/*----output event: onError[]  Static Event */
extern VS_UUID VSOUTEVENTID_VideoViewClass_onError;
/*----output event: onPrepared[]  Static Event */
extern VS_UUID VSOUTEVENTID_VideoViewClass_onPrepared;

/*------Variable Index Define */
#define VSATTRINDEX_VIDEOVIEWCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_VIDEOVIEWCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_VIDEOVIEWCLASS                                                                2

struct StructOfAttachVideoViewClass{
};
struct StructOfVideoViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BASEEXPANDABLELISTADAPTERCLASS                                                   "BaseExpandableListAdapterClass"
extern VS_UUID VSOBJID_BaseExpandableListAdapterClass;
#define VSATTRDEPEND_BASEEXPANDABLELISTADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS                                             2
extern VS_INT32 SRPCALLBACK BaseExpandableListAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BASEEXPANDABLELISTADAPTERCLASS_ANDROIDREFCOUNT                                 0
#define VSATTRINDEX_BASEEXPANDABLELISTADAPTERCLASS_OBJECTLIST                                      1
#define VSATTRNUMBER_BASEEXPANDABLELISTADAPTERCLASS                                                2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_areAllItemsEnabled;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_AREALLITEMSENABLED(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_AREALLITEMSENABLED                    1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_AREALLITEMSENABLED(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_AREALLITEMSENABLED                     0

extern VS_BOOL SRPAPI BaseExpandableListAdapterClass_areAllItemsEnabled(void *Object);
typedef VS_BOOL (SRPAPI *BaseExpandableListAdapterClass_areAllItemsEnabledProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChild;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILD(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILD                              1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILD(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILD                               2

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getChild(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getChildProc)(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChildId;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDID                            1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDID(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDID                             2

extern VS_LONG SRPAPI BaseExpandableListAdapterClass_getChildId(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);
typedef VS_LONG (SRPAPI *BaseExpandableListAdapterClass_getChildIdProc)(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChildView;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDVIEW                          1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDVIEW(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=1;}{X[3].Type=57;}{X[4].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDVIEW                           5

extern VS_OBJPTR SRPAPI BaseExpandableListAdapterClass_getChildView(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition,VS_BOOL isLastChild,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *BaseExpandableListAdapterClass_getChildViewProc)(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition,VS_BOOL isLastChild,VS_OBJPTR convertView,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChildrenCount;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDRENCOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDRENCOUNT                      1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDRENCOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDRENCOUNT                       1

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getChildrenCount(void *Object,VS_INT32 groupPosition);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getChildrenCountProc)(void *Object,VS_INT32 groupPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChildType;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPE                          1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPE(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPE                           2

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getChildType(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getChildTypeProc)(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getChildTypeCount;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPECOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPECOUNT                     1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPECOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCHILDTYPECOUNT                      0

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getChildTypeCount(void *Object);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getChildTypeCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getCombinedChildId;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDCHILDID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDCHILDID                    1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDCHILDID(X)  {{X[0].Type=9;}{X[1].Type=9;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDCHILDID                     2

extern VS_LONG SRPAPI BaseExpandableListAdapterClass_getCombinedChildId(void *Object,VS_LONG groupId,VS_LONG childId);
typedef VS_LONG (SRPAPI *BaseExpandableListAdapterClass_getCombinedChildIdProc)(void *Object,VS_LONG groupId,VS_LONG childId);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getCombinedGroupId;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDGROUPID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDGROUPID                    1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDGROUPID(X)  {{X[0].Type=9;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETCOMBINEDGROUPID                     1

extern VS_LONG SRPAPI BaseExpandableListAdapterClass_getCombinedGroupId(void *Object,VS_LONG groupId);
typedef VS_LONG (SRPAPI *BaseExpandableListAdapterClass_getCombinedGroupIdProc)(void *Object,VS_LONG groupId);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroup;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUP(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUP                              1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUP(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUP                               1

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getGroup(void *Object,VS_INT32 groupPosition);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getGroupProc)(void *Object,VS_INT32 groupPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroupCount;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPCOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPCOUNT                         1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPCOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPCOUNT                          0

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getGroupCount(void *Object);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getGroupCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroupId;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPID                            1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPID(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPID                             1

extern VS_LONG SRPAPI BaseExpandableListAdapterClass_getGroupId(void *Object,VS_INT32 groupPosition);
typedef VS_LONG (SRPAPI *BaseExpandableListAdapterClass_getGroupIdProc)(void *Object,VS_INT32 groupPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroupView;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPVIEW                          1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPVIEW(X)  {{X[0].Type=6;}{X[1].Type=1;}{X[2].Type=57;}{X[3].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPVIEW                           4

extern VS_OBJPTR SRPAPI BaseExpandableListAdapterClass_getGroupView(void *Object,VS_INT32 groupPosition,VS_BOOL isExpanded,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *BaseExpandableListAdapterClass_getGroupViewProc)(void *Object,VS_INT32 groupPosition,VS_BOOL isExpanded,VS_OBJPTR convertView,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_hasStableIds;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_HASSTABLEIDS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_HASSTABLEIDS                          1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_HASSTABLEIDS(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_HASSTABLEIDS                           0

extern VS_BOOL SRPAPI BaseExpandableListAdapterClass_hasStableIds(void *Object);
typedef VS_BOOL (SRPAPI *BaseExpandableListAdapterClass_hasStableIdsProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_isChildSelectable;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ISCHILDSELECTABLE(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ISCHILDSELECTABLE                     1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ISCHILDSELECTABLE(X)  {{X[0].Type=6;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ISCHILDSELECTABLE                      2

extern VS_BOOL SRPAPI BaseExpandableListAdapterClass_isChildSelectable(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);
typedef VS_BOOL (SRPAPI *BaseExpandableListAdapterClass_isChildSelectableProc)(void *Object,VS_INT32 groupPosition,VS_INT32 childPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroupType;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPE                          1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPE                           1

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getGroupType(void *Object,VS_INT32 groupPosition);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getGroupTypeProc)(void *Object,VS_INT32 groupPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_getGroupTypeCount;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPECOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPECOUNT                     1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPECOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_GETGROUPTYPECOUNT                      0

extern VS_INT32 SRPAPI BaseExpandableListAdapterClass_getGroupTypeCount(void *Object);
typedef VS_INT32 (SRPAPI *BaseExpandableListAdapterClass_getGroupTypeCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_isEmpty;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ISEMPTY(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ISEMPTY                               1
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ISEMPTY(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ISEMPTY                                0

extern VS_BOOL SRPAPI BaseExpandableListAdapterClass_isEmpty(void *Object);
typedef VS_BOOL (SRPAPI *BaseExpandableListAdapterClass_isEmptyProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_onGroupCollapsed;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPCOLLAPSED(X)  {}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPCOLLAPSED                      0
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPCOLLAPSED(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPCOLLAPSED                       1

extern void SRPAPI BaseExpandableListAdapterClass_onGroupCollapsed(void *Object,VS_INT32 groupPosition);
typedef void (SRPAPI *BaseExpandableListAdapterClass_onGroupCollapsedProc)(void *Object,VS_INT32 groupPosition);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseExpandableListAdapterClass_onGroupExpanded;
#define VSFUNCRETURNDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPEXPANDED(X)  {}
#define VSFUNCRETURNDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPEXPANDED                       0
#define VSFUNCPARAMDEPEND_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPEXPANDED(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEEXPANDABLELISTADAPTERCLASS_ONGROUPEXPANDED                        1

extern void SRPAPI BaseExpandableListAdapterClass_onGroupExpanded(void *Object,VS_INT32 groupPosition);
typedef void (SRPAPI *BaseExpandableListAdapterClass_onGroupExpandedProc)(void *Object,VS_INT32 groupPosition);

struct StructOfAttachBaseExpandableListAdapterClass{
};
struct StructOfBaseExpandableListAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CURSORCLASS                                                                      "CursorClass"
extern VS_UUID VSOBJID_CursorClass;
#define VSATTRDEPEND_CURSORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CURSORCLASS                                                                2
extern VS_INT32 SRPCALLBACK CursorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CURSORCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_CURSORCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_CURSORCLASS                                                                   2

struct StructOfAttachCursorClass{
};
struct StructOfCursorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CYCLEINTERPOLATORCLASS                                                           "CycleInterpolatorClass"
extern VS_UUID VSOBJID_CycleInterpolatorClass;
#define VSATTRDEPEND_CYCLEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CYCLEINTERPOLATORCLASS                                                     2
extern VS_INT32 SRPCALLBACK CycleInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CYCLEINTERPOLATORCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_CYCLEINTERPOLATORCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_CYCLEINTERPOLATORCLASS                                                        2

struct StructOfAttachCycleInterpolatorClass{
};
struct StructOfCycleInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WINDOWCLASS                                                                      "WindowClass"
extern VS_UUID VSOBJID_WindowClass;
#define VSATTRDEPEND_WINDOWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_WINDOWCLASS                                                                2
extern VS_INT32 SRPCALLBACK WindowClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WINDOWCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_WINDOWCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_WINDOWCLASS                                                                   2

struct StructOfAttachWindowClass{
};
struct StructOfWindowClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LIGHTINGCOLORFILTERCLASS                                                         "LightingColorFilterClass"
extern VS_UUID VSOBJID_LightingColorFilterClass;
#define VSATTRDEPEND_LIGHTINGCOLORFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LIGHTINGCOLORFILTERCLASS                                                   2
extern VS_INT32 SRPCALLBACK LightingColorFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LIGHTINGCOLORFILTERCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_LIGHTINGCOLORFILTERCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_LIGHTINGCOLORFILTERCLASS                                                      2

struct StructOfAttachLightingColorFilterClass{
};
struct StructOfLightingColorFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MEDIAPLAYERCLASS                                                                 "MediaPlayerClass"
extern VS_UUID VSOBJID_MediaPlayerClass;
#define VSATTRDEPEND_MEDIAPLAYERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MEDIAPLAYERCLASS                                                           2
extern VS_INT32 SRPCALLBACK MediaPlayerClass_RequestRegisterObject( );

/*----output event: onBufferingUpdate[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onBufferingUpdate;
/*----output event: onCompletion[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onCompletion;
/*----output event: onError[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onError;
/*----output event: onInfo[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onInfo;
/*----output event: onPrepared[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onPrepared;
/*----output event: onSeekComplete[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onSeekComplete;
/*----output event: onVideoSizeChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaPlayerClass_onVideoSizeChanged;

/*------Variable Index Define */
#define VSATTRINDEX_MEDIAPLAYERCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_MEDIAPLAYERCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_MEDIAPLAYERCLASS                                                              2

struct StructOfAttachMediaPlayerClass{
};
struct StructOfMediaPlayerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INPUTCONNECTIONCLASS                                                             "InputConnectionClass"
extern VS_UUID VSOBJID_InputConnectionClass;
#define VSATTRDEPEND_INPUTCONNECTIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INPUTCONNECTIONCLASS                                                       2
extern VS_INT32 SRPCALLBACK InputConnectionClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INPUTCONNECTIONCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_INPUTCONNECTIONCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_INPUTCONNECTIONCLASS                                                          2

struct StructOfAttachInputConnectionClass{
};
struct StructOfInputConnectionClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTENTRESOLVERCLASS                                                             "ContentResolverClass"
extern VS_UUID VSOBJID_ContentResolverClass;
#define VSATTRDEPEND_CONTENTRESOLVERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTENTRESOLVERCLASS                                                       2
extern VS_INT32 SRPCALLBACK ContentResolverClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTENTRESOLVERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_CONTENTRESOLVERCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_CONTENTRESOLVERCLASS                                                          2

struct StructOfAttachContentResolverClass{
};
struct StructOfContentResolverClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BOUNCEINTERPOLATORCLASS                                                          "BounceInterpolatorClass"
extern VS_UUID VSOBJID_BounceInterpolatorClass;
#define VSATTRDEPEND_BOUNCEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BOUNCEINTERPOLATORCLASS                                                    2
extern VS_INT32 SRPCALLBACK BounceInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BOUNCEINTERPOLATORCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_BOUNCEINTERPOLATORCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_BOUNCEINTERPOLATORCLASS                                                       2

struct StructOfAttachBounceInterpolatorClass{
};
struct StructOfBounceInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RESOURCESCLASS                                                                   "ResourcesClass"
extern VS_UUID VSOBJID_ResourcesClass;
#define VSATTRDEPEND_RESOURCESCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RESOURCESCLASS                                                             2
extern VS_INT32 SRPCALLBACK ResourcesClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RESOURCESCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_RESOURCESCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_RESOURCESCLASS                                                                2

struct StructOfAttachResourcesClass{
};
struct StructOfResourcesClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_FILEINPUTSTREAMCLASS                                                             "FileInputStreamClass"
extern VS_UUID VSOBJID_FileInputStreamClass;
#define VSATTRDEPEND_FILEINPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_FILEINPUTSTREAMCLASS                                                       2
extern VS_INT32 SRPCALLBACK FileInputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_FILEINPUTSTREAMCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_FILEINPUTSTREAMCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_FILEINPUTSTREAMCLASS                                                          2

struct StructOfAttachFileInputStreamClass{
};
struct StructOfFileInputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CHECKBOXCLASS                                                                    "CheckBoxClass"
extern VS_UUID VSOBJID_CheckBoxClass;
#define VSATTRDEPEND_CHECKBOXCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CHECKBOXCLASS                                                              2
extern VS_INT32 SRPCALLBACK CheckBoxClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CHECKBOXCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_CHECKBOXCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_CHECKBOXCLASS                                                                 2

struct StructOfAttachCheckBoxClass{
};
struct StructOfCheckBoxClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ENVIRONMENTCLASS                                                                 "EnvironmentClass"
extern VS_UUID VSOBJID_EnvironmentClass;
#define VSATTRDEPEND_ENVIRONMENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ENVIRONMENTCLASS                                                           2
extern VS_INT32 SRPCALLBACK EnvironmentClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ENVIRONMENTCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ENVIRONMENTCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_ENVIRONMENTCLASS                                                              2

struct StructOfAttachEnvironmentClass{
};
struct StructOfEnvironmentClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LISTVIEWCLASS                                                                    "ListViewClass"
extern VS_UUID VSOBJID_ListViewClass;
#define VSATTRDEPEND_LISTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_LISTVIEWCLASS                                                              5
extern VS_INT32 SRPCALLBACK ListViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LISTVIEWCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_LISTVIEWCLASS_OBJECTLIST                                                       1
#define VSATTRINDEX_LISTVIEWCLASS_VIEWGROUPQUEUE                                                   2
#define VSATTRINDEX_LISTVIEWCLASS_VIEWQUEUE                                                        3
#define VSATTRINDEX_LISTVIEWCLASS_OBJECTQUEUE                                                      4
#define VSATTRNUMBER_LISTVIEWCLASS                                                                 5

struct StructOfAttachListViewClass{
};
struct StructOfListViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TABHOSTCLASS                                                                     "TabHostClass"
extern VS_UUID VSOBJID_TabHostClass;
#define VSATTRDEPEND_TABHOSTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TABHOSTCLASS                                                               5
extern VS_INT32 SRPCALLBACK TabHostClass_RequestRegisterObject( );

/*----output event: onTabChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TabHostClass_onTabChanged;

/*------Variable Index Define */
#define VSATTRINDEX_TABHOSTCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_TABHOSTCLASS_OBJECTLIST                                                        1
#define VSATTRINDEX_TABHOSTCLASS_VIEWGROUPQUEUE                                                    2
#define VSATTRINDEX_TABHOSTCLASS_VIEWQUEUE                                                         3
#define VSATTRINDEX_TABHOSTCLASS_OBJECTQUEUE                                                       4
#define VSATTRNUMBER_TABHOSTCLASS                                                                  5

struct StructOfAttachTabHostClass{
};
struct StructOfTabHostClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANDROIDINITCLASS                                                                 "AndroidInitClass"
extern VS_UUID VSOBJID_AndroidInitClass;
#define VSATTRDEPEND_ANDROIDINITCLASS(X)  {}
#define VSATTRDEPENDNUM_ANDROIDINITCLASS                                                           0
extern VS_INT32 SRPCALLBACK AndroidInitClass_RequestRegisterObject( );

/*----output event: onInitClass[]  Static Event */
extern VS_UUID VSOUTEVENTID_AndroidInitClass_onInitClass;

/*------Variable Index Define */
#define VSATTRNUMBER_ANDROIDINITCLASS                                                              0

struct StructOfAttachAndroidInitClass{
};
struct StructOfAndroidInitClass{
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_IMAGEVIEWCLASS                                                                   "ImageViewClass"
extern VS_UUID VSOBJID_ImageViewClass;
#define VSATTRDEPEND_IMAGEVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_IMAGEVIEWCLASS                                                             2
extern VS_INT32 SRPCALLBACK ImageViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_IMAGEVIEWCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_IMAGEVIEWCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_IMAGEVIEWCLASS                                                                2

struct StructOfAttachImageViewClass{
};
struct StructOfImageViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BYTEARRAYINPUTSTREAMCLASS                                                        "ByteArrayInputStreamClass"
extern VS_UUID VSOBJID_ByteArrayInputStreamClass;
#define VSATTRDEPEND_BYTEARRAYINPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BYTEARRAYINPUTSTREAMCLASS                                                  2
extern VS_INT32 SRPCALLBACK ByteArrayInputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BYTEARRAYINPUTSTREAMCLASS_ANDROIDREFCOUNT                                      0
#define VSATTRINDEX_BYTEARRAYINPUTSTREAMCLASS_OBJECTLIST                                           1
#define VSATTRNUMBER_BYTEARRAYINPUTSTREAMCLASS                                                     2

struct StructOfAttachByteArrayInputStreamClass{
};
struct StructOfByteArrayInputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LOCATIONCLASS                                                                    "LocationClass"
extern VS_UUID VSOBJID_LocationClass;
#define VSATTRDEPEND_LOCATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LOCATIONCLASS                                                              2
extern VS_INT32 SRPCALLBACK LocationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LOCATIONCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_LOCATIONCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_LOCATIONCLASS                                                                 2

struct StructOfAttachLocationClass{
};
struct StructOfLocationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SIMPLEPACKAGEMANAGERCLASS                                                        "SimplePackageManagerClass"
extern VS_UUID VSOBJID_SimplePackageManagerClass;
#define VSATTRDEPEND_SIMPLEPACKAGEMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SIMPLEPACKAGEMANAGERCLASS                                                  2
extern VS_INT32 SRPCALLBACK SimplePackageManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SIMPLEPACKAGEMANAGERCLASS_ANDROIDREFCOUNT                                      0
#define VSATTRINDEX_SIMPLEPACKAGEMANAGERCLASS_OBJECTLIST                                           1
#define VSATTRNUMBER_SIMPLEPACKAGEMANAGERCLASS                                                     2

struct StructOfAttachSimplePackageManagerClass{
};
struct StructOfSimplePackageManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_NOTIFICATIONCLASS                                                                "NotificationClass"
extern VS_UUID VSOBJID_NotificationClass;
#define VSATTRDEPEND_NOTIFICATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_NOTIFICATIONCLASS                                                          2
extern VS_INT32 SRPCALLBACK NotificationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_NOTIFICATIONCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_NOTIFICATIONCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_NOTIFICATIONCLASS                                                             2

struct StructOfAttachNotificationClass{
};
struct StructOfNotificationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ABSSPINNERCLASS                                                                  "AbsSpinnerClass"
extern VS_UUID VSOBJID_AbsSpinnerClass;
#define VSATTRDEPEND_ABSSPINNERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_ABSSPINNERCLASS                                                            5
extern VS_INT32 SRPCALLBACK AbsSpinnerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ABSSPINNERCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_ABSSPINNERCLASS_OBJECTLIST                                                     1
#define VSATTRINDEX_ABSSPINNERCLASS_VIEWGROUPQUEUE                                                 2
#define VSATTRINDEX_ABSSPINNERCLASS_VIEWQUEUE                                                      3
#define VSATTRINDEX_ABSSPINNERCLASS_OBJECTQUEUE                                                    4
#define VSATTRNUMBER_ABSSPINNERCLASS                                                               5

struct StructOfAttachAbsSpinnerClass{
};
struct StructOfAbsSpinnerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CHECKEDTEXTVIEWCLASS                                                             "CheckedTextViewClass"
extern VS_UUID VSOBJID_CheckedTextViewClass;
#define VSATTRDEPEND_CHECKEDTEXTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CHECKEDTEXTVIEWCLASS                                                       2
extern VS_INT32 SRPCALLBACK CheckedTextViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CHECKEDTEXTVIEWCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_CHECKEDTEXTVIEWCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_CHECKEDTEXTVIEWCLASS                                                          2

struct StructOfAttachCheckedTextViewClass{
};
struct StructOfCheckedTextViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EXPANDABLELISTCONTEXTMENUINFOCLASS                                               "ExpandableListContextMenuInfoClass"
extern VS_UUID VSOBJID_ExpandableListContextMenuInfoClass;
#define VSATTRDEPEND_EXPANDABLELISTCONTEXTMENUINFOCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EXPANDABLELISTCONTEXTMENUINFOCLASS                                         2
extern VS_INT32 SRPCALLBACK ExpandableListContextMenuInfoClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EXPANDABLELISTCONTEXTMENUINFOCLASS_ANDROIDREFCOUNT                             0
#define VSATTRINDEX_EXPANDABLELISTCONTEXTMENUINFOCLASS_OBJECTLIST                                  1
#define VSATTRNUMBER_EXPANDABLELISTCONTEXTMENUINFOCLASS                                            2

struct StructOfAttachExpandableListContextMenuInfoClass{
};
struct StructOfExpandableListContextMenuInfoClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OBJECTSCLASS                                                                     "ObjectsClass"
extern VS_UUID VSOBJID_ObjectsClass;
#define VSATTRDEPEND_OBJECTSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OBJECTSCLASS                                                               2
extern VS_INT32 SRPCALLBACK ObjectsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OBJECTSCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_OBJECTSCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_OBJECTSCLASS                                                                  2

struct StructOfAttachObjectsClass{
};
struct StructOfObjectsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LAYOUTINFLATERCLASS                                                              "LayoutInflaterClass"
extern VS_UUID VSOBJID_LayoutInflaterClass;
#define VSATTRDEPEND_LAYOUTINFLATERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LAYOUTINFLATERCLASS                                                        2
extern VS_INT32 SRPCALLBACK LayoutInflaterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LAYOUTINFLATERCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_LAYOUTINFLATERCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_LAYOUTINFLATERCLASS                                                           2

struct StructOfAttachLayoutInflaterClass{
};
struct StructOfLayoutInflaterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_STATFSCLASS                                                                      "StatFsClass"
extern VS_UUID VSOBJID_StatFsClass;
#define VSATTRDEPEND_STATFSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_STATFSCLASS                                                                2
extern VS_INT32 SRPCALLBACK StatFsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_STATFSCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_STATFSCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_STATFSCLASS                                                                   2

struct StructOfAttachStatFsClass{
};
struct StructOfStatFsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SWEEPGRADIENTCLASS                                                               "SweepGradientClass"
extern VS_UUID VSOBJID_SweepGradientClass;
#define VSATTRDEPEND_SWEEPGRADIENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SWEEPGRADIENTCLASS                                                         2
extern VS_INT32 SRPCALLBACK SweepGradientClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SWEEPGRADIENTCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SWEEPGRADIENTCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SWEEPGRADIENTCLASS                                                            2

struct StructOfAttachSweepGradientClass{
};
struct StructOfSweepGradientClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TYPEDVALUECLASS                                                                  "TypedValueClass"
extern VS_UUID VSOBJID_TypedValueClass;
#define VSATTRDEPEND_TYPEDVALUECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TYPEDVALUECLASS                                                            2
extern VS_INT32 SRPCALLBACK TypedValueClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TYPEDVALUECLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_TYPEDVALUECLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_TYPEDVALUECLASS                                                               2

struct StructOfAttachTypedValueClass{
};
struct StructOfTypedValueClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EDITABLECLASS                                                                    "EditableClass"
extern VS_UUID VSOBJID_EditableClass;
#define VSATTRDEPEND_EDITABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EDITABLECLASS                                                              2
extern VS_INT32 SRPCALLBACK EditableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EDITABLECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_EDITABLECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_EDITABLECLASS                                                                 2

struct StructOfAttachEditableClass{
};
struct StructOfEditableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DASHPATHEFFECTCLASS                                                              "DashPathEffectClass"
extern VS_UUID VSOBJID_DashPathEffectClass;
#define VSATTRDEPEND_DASHPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DASHPATHEFFECTCLASS                                                        2
extern VS_INT32 SRPCALLBACK DashPathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DASHPATHEFFECTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_DASHPATHEFFECTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_DASHPATHEFFECTCLASS                                                           2

struct StructOfAttachDashPathEffectClass{
};
struct StructOfDashPathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WEBCHROMECLIENTCLASS                                                             "WebChromeClientClass"
extern VS_UUID VSOBJID_WebChromeClientClass;
#define VSATTRDEPEND_WEBCHROMECLIENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_WEBCHROMECLIENTCLASS                                                       2
extern VS_INT32 SRPCALLBACK WebChromeClientClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WEBCHROMECLIENTCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_WEBCHROMECLIENTCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_WEBCHROMECLIENTCLASS                                                          2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onCloseWindow;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONCLOSEWINDOW(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONCLOSEWINDOW                                   0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONCLOSEWINDOW(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONCLOSEWINDOW                                    1

extern void SRPAPI WebChromeClientClass_onCloseWindow(void *Object,VS_OBJPTR window);
typedef void (SRPAPI *WebChromeClientClass_onCloseWindowProc)(void *Object,VS_OBJPTR window);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onConsoleMessage;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONCONSOLEMESSAGE(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONCONSOLEMESSAGE                                0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONCONSOLEMESSAGE(X)  {{X[0].Type=30;}{X[1].Type=6;}{X[2].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONCONSOLEMESSAGE                                 3

extern void SRPAPI WebChromeClientClass_onConsoleMessage(void *Object,VS_CHAR * message,VS_INT32 lineNumber,VS_CHAR * sourceID);
typedef void (SRPAPI *WebChromeClientClass_onConsoleMessageProc)(void *Object,VS_CHAR * message,VS_INT32 lineNumber,VS_CHAR * sourceID);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onGeolocationPermissionsHidePrompt;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONGEOLOCATIONPERMISSIONSHIDEPROMPT(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONGEOLOCATIONPERMISSIONSHIDEPROMPT              0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONGEOLOCATIONPERMISSIONSHIDEPROMPT(X)  {}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONGEOLOCATIONPERMISSIONSHIDEPROMPT               0

extern void SRPAPI WebChromeClientClass_onGeolocationPermissionsHidePrompt(void *Object);
typedef void (SRPAPI *WebChromeClientClass_onGeolocationPermissionsHidePromptProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onHideCustomView;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONHIDECUSTOMVIEW(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONHIDECUSTOMVIEW                                0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONHIDECUSTOMVIEW(X)  {}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONHIDECUSTOMVIEW                                 0

extern void SRPAPI WebChromeClientClass_onHideCustomView(void *Object);
typedef void (SRPAPI *WebChromeClientClass_onHideCustomViewProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onJsAlert;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONJSALERT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSALERT                                       1
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONJSALERT(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=30;}{X[3].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSALERT                                        4

extern VS_BOOL SRPAPI WebChromeClientClass_onJsAlert(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);
typedef VS_BOOL (SRPAPI *WebChromeClientClass_onJsAlertProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onJsBeforeUnload;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONJSBEFOREUNLOAD(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSBEFOREUNLOAD                                1
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONJSBEFOREUNLOAD(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=30;}{X[3].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSBEFOREUNLOAD                                 4

extern VS_BOOL SRPAPI WebChromeClientClass_onJsBeforeUnload(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);
typedef VS_BOOL (SRPAPI *WebChromeClientClass_onJsBeforeUnloadProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onJsConfirm;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONJSCONFIRM(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSCONFIRM                                     1
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONJSCONFIRM(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=30;}{X[3].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSCONFIRM                                      4

extern VS_BOOL SRPAPI WebChromeClientClass_onJsConfirm(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);
typedef VS_BOOL (SRPAPI *WebChromeClientClass_onJsConfirmProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_OBJPTR result);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onJsPrompt;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONJSPROMPT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSPROMPT                                      1
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONJSPROMPT(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=30;}{X[3].Type=30;}{X[4].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSPROMPT                                       5

extern VS_BOOL SRPAPI WebChromeClientClass_onJsPrompt(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_CHAR * defaultValue,VS_OBJPTR result);
typedef VS_BOOL (SRPAPI *WebChromeClientClass_onJsPromptProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_CHAR * message,VS_CHAR * defaultValue,VS_OBJPTR result);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onJsTimeout;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONJSTIMEOUT(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSTIMEOUT                                     0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONJSTIMEOUT(X)  {}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONJSTIMEOUT                                      0

extern void SRPAPI WebChromeClientClass_onJsTimeout(void *Object);
typedef void (SRPAPI *WebChromeClientClass_onJsTimeoutProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onProgressChanged;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONPROGRESSCHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONPROGRESSCHANGED                               0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONPROGRESSCHANGED(X)  {{X[0].Type=57;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONPROGRESSCHANGED                                2

extern void SRPAPI WebChromeClientClass_onProgressChanged(void *Object,VS_OBJPTR view,VS_INT32 newProgress);
typedef void (SRPAPI *WebChromeClientClass_onProgressChangedProc)(void *Object,VS_OBJPTR view,VS_INT32 newProgress);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onReceivedIcon;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDICON(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDICON                                  0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDICON(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDICON                                   2

extern void SRPAPI WebChromeClientClass_onReceivedIcon(void *Object,VS_OBJPTR view,VS_OBJPTR icon);
typedef void (SRPAPI *WebChromeClientClass_onReceivedIconProc)(void *Object,VS_OBJPTR view,VS_OBJPTR icon);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onReceivedTitle;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDTITLE(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDTITLE                                 0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDTITLE(X)  {{X[0].Type=57;}{X[1].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDTITLE                                  2

extern void SRPAPI WebChromeClientClass_onReceivedTitle(void *Object,VS_OBJPTR view,VS_CHAR * title);
typedef void (SRPAPI *WebChromeClientClass_onReceivedTitleProc)(void *Object,VS_OBJPTR view,VS_CHAR * title);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onReceivedTouchIconUrl;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDTOUCHICONURL(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDTOUCHICONURL                          0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONRECEIVEDTOUCHICONURL(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=1;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONRECEIVEDTOUCHICONURL                           3

extern void SRPAPI WebChromeClientClass_onReceivedTouchIconUrl(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_BOOL precomposed);
typedef void (SRPAPI *WebChromeClientClass_onReceivedTouchIconUrlProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_BOOL precomposed);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebChromeClientClass_onRequestFocus;
#define VSFUNCRETURNDEPEND_WEBCHROMECLIENTCLASS_ONREQUESTFOCUS(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBCHROMECLIENTCLASS_ONREQUESTFOCUS                                  0
#define VSFUNCPARAMDEPEND_WEBCHROMECLIENTCLASS_ONREQUESTFOCUS(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBCHROMECLIENTCLASS_ONREQUESTFOCUS                                   1

extern void SRPAPI WebChromeClientClass_onRequestFocus(void *Object,VS_OBJPTR view);
typedef void (SRPAPI *WebChromeClientClass_onRequestFocusProc)(void *Object,VS_OBJPTR view);

struct StructOfAttachWebChromeClientClass{
};
struct StructOfWebChromeClientClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MOTIONEVENTCLASS                                                                 "MotionEventClass"
extern VS_UUID VSOBJID_MotionEventClass;
#define VSATTRDEPEND_MOTIONEVENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_MOTIONEVENTCLASS                                                           2
extern VS_INT32 SRPCALLBACK MotionEventClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_MOTIONEVENTCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_MOTIONEVENTCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_MOTIONEVENTCLASS                                                              2

struct StructOfAttachMotionEventClass{
};
struct StructOfMotionEventClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTENTURISCLASS                                                                 "ContentUrisClass"
extern VS_UUID VSOBJID_ContentUrisClass;
#define VSATTRDEPEND_CONTENTURISCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTENTURISCLASS                                                           2
extern VS_INT32 SRPCALLBACK ContentUrisClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTENTURISCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_CONTENTURISCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_CONTENTURISCLASS                                                              2

struct StructOfAttachContentUrisClass{
};
struct StructOfContentUrisClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ASSETFILEDESCRIPTORCLASS                                                         "AssetFileDescriptorClass"
extern VS_UUID VSOBJID_AssetFileDescriptorClass;
#define VSATTRDEPEND_ASSETFILEDESCRIPTORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ASSETFILEDESCRIPTORCLASS                                                   2
extern VS_INT32 SRPCALLBACK AssetFileDescriptorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ASSETFILEDESCRIPTORCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_ASSETFILEDESCRIPTORCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_ASSETFILEDESCRIPTORCLASS                                                      2

struct StructOfAttachAssetFileDescriptorClass{
};
struct StructOfAssetFileDescriptorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BITMAPFACTORY_OPTIONSCLASS                                                       "BitmapFactory_OptionsClass"
extern VS_UUID VSOBJID_BitmapFactory_OptionsClass;
#define VSATTRDEPEND_BITMAPFACTORY_OPTIONSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BITMAPFACTORY_OPTIONSCLASS                                                 2
extern VS_INT32 SRPCALLBACK BitmapFactory_OptionsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BITMAPFACTORY_OPTIONSCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_BITMAPFACTORY_OPTIONSCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_BITMAPFACTORY_OPTIONSCLASS                                                    2

struct StructOfAttachBitmapFactory_OptionsClass{
};
struct StructOfBitmapFactory_OptionsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_MEDIACONTROLLERCLASS                                                             "MediaControllerClass"
extern VS_UUID VSOBJID_MediaControllerClass;
#define VSATTRDEPEND_MEDIACONTROLLERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_MEDIACONTROLLERCLASS                                                       5
extern VS_INT32 SRPCALLBACK MediaControllerClass_RequestRegisterObject( );

/*----output event: onPrev[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaControllerClass_onPrev;
/*----output event: onNext[]  Static Event */
extern VS_UUID VSOUTEVENTID_MediaControllerClass_onNext;

/*------Variable Index Define */
#define VSATTRINDEX_MEDIACONTROLLERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_MEDIACONTROLLERCLASS_OBJECTLIST                                                1
#define VSATTRINDEX_MEDIACONTROLLERCLASS_VIEWGROUPQUEUE                                            2
#define VSATTRINDEX_MEDIACONTROLLERCLASS_VIEWQUEUE                                                 3
#define VSATTRINDEX_MEDIACONTROLLERCLASS_OBJECTQUEUE                                               4
#define VSATTRNUMBER_MEDIACONTROLLERCLASS                                                          5

struct StructOfAttachMediaControllerClass{
};
struct StructOfMediaControllerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RINGTONECLASS                                                                    "RingtoneClass"
extern VS_UUID VSOBJID_RingtoneClass;
#define VSATTRDEPEND_RINGTONECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RINGTONECLASS                                                              2
extern VS_INT32 SRPCALLBACK RingtoneClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RINGTONECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_RINGTONECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_RINGTONECLASS                                                                 2

struct StructOfAttachRingtoneClass{
};
struct StructOfRingtoneClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WEBSETTINGSCLASS                                                                 "WebSettingsClass"
extern VS_UUID VSOBJID_WebSettingsClass;
#define VSATTRDEPEND_WEBSETTINGSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_WEBSETTINGSCLASS                                                           2
extern VS_INT32 SRPCALLBACK WebSettingsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WEBSETTINGSCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_WEBSETTINGSCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_WEBSETTINGSCLASS                                                              2

struct StructOfAttachWebSettingsClass{
};
struct StructOfWebSettingsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COLORSTATELISTCLASS                                                              "ColorStateListClass"
extern VS_UUID VSOBJID_ColorStateListClass;
#define VSATTRDEPEND_COLORSTATELISTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COLORSTATELISTCLASS                                                        2
extern VS_INT32 SRPCALLBACK ColorStateListClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COLORSTATELISTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_COLORSTATELISTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_COLORSTATELISTCLASS                                                           2

struct StructOfAttachColorStateListClass{
};
struct StructOfColorStateListClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EXPANDABLELISTVIEWCLASS                                                          "ExpandableListViewClass"
extern VS_UUID VSOBJID_ExpandableListViewClass;
#define VSATTRDEPEND_EXPANDABLELISTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_EXPANDABLELISTVIEWCLASS                                                    5
extern VS_INT32 SRPCALLBACK ExpandableListViewClass_RequestRegisterObject( );

/*----output event: onChildClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_ExpandableListViewClass_onChildClick;
/*----output event: onGroupClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_ExpandableListViewClass_onGroupClick;
/*----output event: onGroupCollapse[]  Static Event */
extern VS_UUID VSOUTEVENTID_ExpandableListViewClass_onGroupCollapse;
/*----output event: onGroupExpand[]  Static Event */
extern VS_UUID VSOUTEVENTID_ExpandableListViewClass_onGroupExpand;

/*------Variable Index Define */
#define VSATTRINDEX_EXPANDABLELISTVIEWCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_EXPANDABLELISTVIEWCLASS_OBJECTLIST                                             1
#define VSATTRINDEX_EXPANDABLELISTVIEWCLASS_VIEWGROUPQUEUE                                         2
#define VSATTRINDEX_EXPANDABLELISTVIEWCLASS_VIEWQUEUE                                              3
#define VSATTRINDEX_EXPANDABLELISTVIEWCLASS_OBJECTQUEUE                                            4
#define VSATTRNUMBER_EXPANDABLELISTVIEWCLASS                                                       5

struct StructOfAttachExpandableListViewClass{
};
struct StructOfExpandableListViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BASEADAPTERCLASS                                                                 "BaseAdapterClass"
extern VS_UUID VSOBJID_BaseAdapterClass;
#define VSATTRDEPEND_BASEADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BASEADAPTERCLASS                                                           2
extern VS_INT32 SRPCALLBACK BaseAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BASEADAPTERCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_BASEADAPTERCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_BASEADAPTERCLASS                                                              2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_areAllItemsEnabled;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_AREALLITEMSENABLED(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_AREALLITEMSENABLED                                  1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_AREALLITEMSENABLED(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_AREALLITEMSENABLED                                   0

extern VS_BOOL SRPAPI BaseAdapterClass_areAllItemsEnabled(void *Object);
typedef VS_BOOL (SRPAPI *BaseAdapterClass_areAllItemsEnabledProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_isEnabled;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_ISENABLED(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_ISENABLED                                           1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_ISENABLED(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_ISENABLED                                            1

extern VS_BOOL SRPAPI BaseAdapterClass_isEnabled(void *Object,VS_INT32 position);
typedef VS_BOOL (SRPAPI *BaseAdapterClass_isEnabledProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getDropDownView;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETDROPDOWNVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETDROPDOWNVIEW                                     1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETDROPDOWNVIEW(X)  {{X[0].Type=6;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETDROPDOWNVIEW                                      3

extern VS_OBJPTR SRPAPI BaseAdapterClass_getDropDownView(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *BaseAdapterClass_getDropDownViewProc)(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getCount;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETCOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETCOUNT                                            1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETCOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETCOUNT                                             0

extern VS_INT32 SRPAPI BaseAdapterClass_getCount(void *Object);
typedef VS_INT32 (SRPAPI *BaseAdapterClass_getCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getItem;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETITEM(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETITEM                                             1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETITEM(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETITEM                                              1

extern VS_INT32 SRPAPI BaseAdapterClass_getItem(void *Object,VS_INT32 position);
typedef VS_INT32 (SRPAPI *BaseAdapterClass_getItemProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getItemId;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETITEMID(X)  {{X[0].Type=9;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETITEMID                                           1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETITEMID(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETITEMID                                            1

extern VS_LONG SRPAPI BaseAdapterClass_getItemId(void *Object,VS_INT32 position);
typedef VS_LONG (SRPAPI *BaseAdapterClass_getItemIdProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getViewTypeCount;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETVIEWTYPECOUNT(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETVIEWTYPECOUNT                                    1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETVIEWTYPECOUNT(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETVIEWTYPECOUNT                                     0

extern VS_INT32 SRPAPI BaseAdapterClass_getViewTypeCount(void *Object);
typedef VS_INT32 (SRPAPI *BaseAdapterClass_getViewTypeCountProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getItemViewType;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETITEMVIEWTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETITEMVIEWTYPE                                     1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETITEMVIEWTYPE(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETITEMVIEWTYPE                                      1

extern VS_INT32 SRPAPI BaseAdapterClass_getItemViewType(void *Object,VS_INT32 position);
typedef VS_INT32 (SRPAPI *BaseAdapterClass_getItemViewTypeProc)(void *Object,VS_INT32 position);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_getView;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_GETVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_GETVIEW                                             1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_GETVIEW(X)  {{X[0].Type=6;}{X[1].Type=57;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_GETVIEW                                              3

extern VS_OBJPTR SRPAPI BaseAdapterClass_getView(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);
typedef VS_OBJPTR (SRPAPI *BaseAdapterClass_getViewProc)(void *Object,VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_hasStableIds;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_HASSTABLEIDS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_HASSTABLEIDS                                        1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_HASSTABLEIDS(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_HASSTABLEIDS                                         0

extern VS_BOOL SRPAPI BaseAdapterClass_hasStableIds(void *Object);
typedef VS_BOOL (SRPAPI *BaseAdapterClass_hasStableIdsProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseAdapterClass_isEmpty;
#define VSFUNCRETURNDEPEND_BASEADAPTERCLASS_ISEMPTY(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEADAPTERCLASS_ISEMPTY                                             1
#define VSFUNCPARAMDEPEND_BASEADAPTERCLASS_ISEMPTY(X)  {}
#define VSFUNCPARAMDEPENDNUM_BASEADAPTERCLASS_ISEMPTY                                              0

extern VS_BOOL SRPAPI BaseAdapterClass_isEmpty(void *Object);
typedef VS_BOOL (SRPAPI *BaseAdapterClass_isEmptyProc)(void *Object);

struct StructOfAttachBaseAdapterClass{
};
struct StructOfBaseAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SENSORMANAGERCLASS                                                               "SensorManagerClass"
extern VS_UUID VSOBJID_SensorManagerClass;
#define VSATTRDEPEND_SENSORMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SENSORMANAGERCLASS                                                         2
extern VS_INT32 SRPCALLBACK SensorManagerClass_RequestRegisterObject( );

/*----output event: onAccuracyChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_SensorManagerClass_onAccuracyChanged;
/*----output event: onSensorChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_SensorManagerClass_onSensorChanged;

/*------Variable Index Define */
#define VSATTRINDEX_SENSORMANAGERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_SENSORMANAGERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_SENSORMANAGERCLASS                                                            2

struct StructOfAttachSensorManagerClass{
};
struct StructOfSensorManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_IMAGESWITCHERCLASS                                                               "ImageSwitcherClass"
extern VS_UUID VSOBJID_ImageSwitcherClass;
#define VSATTRDEPEND_IMAGESWITCHERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_IMAGESWITCHERCLASS                                                         5
extern VS_INT32 SRPCALLBACK ImageSwitcherClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_IMAGESWITCHERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_IMAGESWITCHERCLASS_OBJECTLIST                                                  1
#define VSATTRINDEX_IMAGESWITCHERCLASS_VIEWGROUPQUEUE                                              2
#define VSATTRINDEX_IMAGESWITCHERCLASS_VIEWQUEUE                                                   3
#define VSATTRINDEX_IMAGESWITCHERCLASS_OBJECTQUEUE                                                 4
#define VSATTRNUMBER_IMAGESWITCHERCLASS                                                            5

struct StructOfAttachImageSwitcherClass{
};
struct StructOfImageSwitcherClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INTERPOLATORCLASS                                                                "InterpolatorClass"
extern VS_UUID VSOBJID_InterpolatorClass;
#define VSATTRDEPEND_INTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INTERPOLATORCLASS                                                          2
extern VS_INT32 SRPCALLBACK InterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INTERPOLATORCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_INTERPOLATORCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_INTERPOLATORCLASS                                                             2

struct StructOfAttachInterpolatorClass{
};
struct StructOfInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DRAWABLECLASS                                                                    "DrawableClass"
extern VS_UUID VSOBJID_DrawableClass;
#define VSATTRDEPEND_DRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DRAWABLECLASS                                                              2
extern VS_INT32 SRPCALLBACK DrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DRAWABLECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_DRAWABLECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_DRAWABLECLASS                                                                 2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_DrawableClass_draw;
#define VSFUNCRETURNDEPEND_DRAWABLECLASS_DRAW(X)  {}
#define VSFUNCRETURNDEPENDNUM_DRAWABLECLASS_DRAW                                                   0
#define VSFUNCPARAMDEPEND_DRAWABLECLASS_DRAW(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_DRAWABLECLASS_DRAW                                                    1

extern void SRPAPI DrawableClass_draw(void *Object,VS_OBJPTR canvas);
typedef void (SRPAPI *DrawableClass_drawProc)(void *Object,VS_OBJPTR canvas);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_DrawableClass_getOpacity;
#define VSFUNCRETURNDEPEND_DRAWABLECLASS_GETOPACITY(X)  {{X[0].Type=6;}}
#define VSFUNCRETURNDEPENDNUM_DRAWABLECLASS_GETOPACITY                                             1
#define VSFUNCPARAMDEPEND_DRAWABLECLASS_GETOPACITY(X)  {}
#define VSFUNCPARAMDEPENDNUM_DRAWABLECLASS_GETOPACITY                                              0

extern VS_INT32 SRPAPI DrawableClass_getOpacity(void *Object);
typedef VS_INT32 (SRPAPI *DrawableClass_getOpacityProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_DrawableClass_setAlpha;
#define VSFUNCRETURNDEPEND_DRAWABLECLASS_SETALPHA(X)  {}
#define VSFUNCRETURNDEPENDNUM_DRAWABLECLASS_SETALPHA                                               0
#define VSFUNCPARAMDEPEND_DRAWABLECLASS_SETALPHA(X)  {{X[0].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_DRAWABLECLASS_SETALPHA                                                1

extern void SRPAPI DrawableClass_setAlpha(void *Object,VS_INT32 setAlpha);
typedef void (SRPAPI *DrawableClass_setAlphaProc)(void *Object,VS_INT32 setAlpha);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_DrawableClass_setColorFilter;
#define VSFUNCRETURNDEPEND_DRAWABLECLASS_SETCOLORFILTER(X)  {}
#define VSFUNCRETURNDEPENDNUM_DRAWABLECLASS_SETCOLORFILTER                                         0
#define VSFUNCPARAMDEPEND_DRAWABLECLASS_SETCOLORFILTER(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_DRAWABLECLASS_SETCOLORFILTER                                          1

extern void SRPAPI DrawableClass_setColorFilter(void *Object,VS_OBJPTR cf);
typedef void (SRPAPI *DrawableClass_setColorFilterProc)(void *Object,VS_OBJPTR cf);

struct StructOfAttachDrawableClass{
};
struct StructOfDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GALLERYCLASS                                                                     "GalleryClass"
extern VS_UUID VSOBJID_GalleryClass;
#define VSATTRDEPEND_GALLERYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_GALLERYCLASS                                                               5
extern VS_INT32 SRPCALLBACK GalleryClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GALLERYCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_GALLERYCLASS_OBJECTLIST                                                        1
#define VSATTRINDEX_GALLERYCLASS_VIEWGROUPQUEUE                                                    2
#define VSATTRINDEX_GALLERYCLASS_VIEWQUEUE                                                         3
#define VSATTRINDEX_GALLERYCLASS_OBJECTQUEUE                                                       4
#define VSATTRNUMBER_GALLERYCLASS                                                                  5

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onDown;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONDOWN(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONDOWN                                                  1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONDOWN(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONDOWN                                                   1

extern VS_BOOL SRPAPI GalleryClass_onDown(void *Object,VS_OBJPTR e);
typedef VS_BOOL (SRPAPI *GalleryClass_onDownProc)(void *Object,VS_OBJPTR e);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onFling;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONFLING(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONFLING                                                 1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONFLING(X)  {{X[0].Type=57;}{X[1].Type=57;}{X[2].Type=8;}{X[3].Type=8;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONFLING                                                  4

extern VS_BOOL SRPAPI GalleryClass_onFling(void *Object,VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT velocityX,VS_FLOAT velocityY);
typedef VS_BOOL (SRPAPI *GalleryClass_onFlingProc)(void *Object,VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT velocityX,VS_FLOAT velocityY);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onLongPress;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONLONGPRESS(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONLONGPRESS                                             1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONLONGPRESS(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONLONGPRESS                                              1

extern VS_BOOL SRPAPI GalleryClass_onLongPress(void *Object,VS_OBJPTR e);
typedef VS_BOOL (SRPAPI *GalleryClass_onLongPressProc)(void *Object,VS_OBJPTR e);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onScroll;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONSCROLL(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONSCROLL                                                1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONSCROLL(X)  {{X[0].Type=57;}{X[1].Type=57;}{X[2].Type=8;}{X[3].Type=8;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONSCROLL                                                 4

extern VS_BOOL SRPAPI GalleryClass_onScroll(void *Object,VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT distanceX,VS_FLOAT distanceY);
typedef VS_BOOL (SRPAPI *GalleryClass_onScrollProc)(void *Object,VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT distanceX,VS_FLOAT distanceY);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onShowPress;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONSHOWPRESS(X)  {}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONSHOWPRESS                                             0
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONSHOWPRESS(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONSHOWPRESS                                              1

extern void SRPAPI GalleryClass_onShowPress(void *Object,VS_OBJPTR e);
typedef void (SRPAPI *GalleryClass_onShowPressProc)(void *Object,VS_OBJPTR e);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onSingleTapUp;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONSINGLETAPUP(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONSINGLETAPUP                                           1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONSINGLETAPUP(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONSINGLETAPUP                                            1

extern VS_BOOL SRPAPI GalleryClass_onSingleTapUp(void *Object,VS_OBJPTR e);
typedef VS_BOOL (SRPAPI *GalleryClass_onSingleTapUpProc)(void *Object,VS_OBJPTR e);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_GalleryClass_onTouchEvent;
#define VSFUNCRETURNDEPEND_GALLERYCLASS_ONTOUCHEVENT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_GALLERYCLASS_ONTOUCHEVENT                                            1
#define VSFUNCPARAMDEPEND_GALLERYCLASS_ONTOUCHEVENT(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_GALLERYCLASS_ONTOUCHEVENT                                             1

extern VS_BOOL SRPAPI GalleryClass_onTouchEvent(void *Object,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *GalleryClass_onTouchEventProc)(void *Object,VS_OBJPTR event);

struct StructOfAttachGalleryClass{
};
struct StructOfGalleryClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DECELERATEINTERPOLATORCLASS                                                      "DecelerateInterpolatorClass"
extern VS_UUID VSOBJID_DecelerateInterpolatorClass;
#define VSATTRDEPEND_DECELERATEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DECELERATEINTERPOLATORCLASS                                                2
extern VS_INT32 SRPCALLBACK DecelerateInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DECELERATEINTERPOLATORCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_DECELERATEINTERPOLATORCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_DECELERATEINTERPOLATORCLASS                                                   2

struct StructOfAttachDecelerateInterpolatorClass{
};
struct StructOfDecelerateInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GPSSTATUSCLASS                                                                   "GpsStatusClass"
extern VS_UUID VSOBJID_GpsStatusClass;
#define VSATTRDEPEND_GPSSTATUSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GPSSTATUSCLASS                                                             2
extern VS_INT32 SRPCALLBACK GpsStatusClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GPSSTATUSCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_GPSSTATUSCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_GPSSTATUSCLASS                                                                2

struct StructOfAttachGpsStatusClass{
};
struct StructOfGpsStatusClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWGROUPCLASS                                                                   "ViewGroupClass"
extern VS_UUID VSOBJID_ViewGroupClass;
#define VSATTRDEPEND_VIEWGROUPCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_VIEWGROUPCLASS                                                             5
extern VS_INT32 SRPCALLBACK ViewGroupClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWGROUPCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_VIEWGROUPCLASS_OBJECTLIST                                                      1
#define VSATTRINDEX_VIEWGROUPCLASS_VIEWGROUPQUEUE                                                  2
#define VSATTRINDEX_VIEWGROUPCLASS_VIEWQUEUE                                                       3
#define VSATTRINDEX_VIEWGROUPCLASS_OBJECTQUEUE                                                     4
#define VSATTRNUMBER_VIEWGROUPCLASS                                                                5

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewGroupClass_onInterceptTouchEvent;
#define VSFUNCRETURNDEPEND_VIEWGROUPCLASS_ONINTERCEPTTOUCHEVENT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_VIEWGROUPCLASS_ONINTERCEPTTOUCHEVENT                                 1
#define VSFUNCPARAMDEPEND_VIEWGROUPCLASS_ONINTERCEPTTOUCHEVENT(X)  {{X[0].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_VIEWGROUPCLASS_ONINTERCEPTTOUCHEVENT                                  1

extern VS_BOOL SRPAPI ViewGroupClass_onInterceptTouchEvent(void *Object,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *ViewGroupClass_onInterceptTouchEventProc)(void *Object,VS_OBJPTR event);

struct StructOfAttachViewGroupClass{
};
struct StructOfViewGroupClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----local attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANIMATIONUTILSCLASS                                                              "AnimationUtilsClass"
extern VS_UUID VSOBJID_AnimationUtilsClass;
#define VSATTRDEPEND_ANIMATIONUTILSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANIMATIONUTILSCLASS                                                        2
extern VS_INT32 SRPCALLBACK AnimationUtilsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANIMATIONUTILSCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_ANIMATIONUTILSCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_ANIMATIONUTILSCLASS                                                           2

struct StructOfAttachAnimationUtilsClass{
};
struct StructOfAnimationUtilsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SETOBJECTCLASS                                                                   "SetObjectClass"
extern VS_UUID VSOBJID_SetObjectClass;
#define VSATTRDEPEND_SETOBJECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SETOBJECTCLASS                                                             2
extern VS_INT32 SRPCALLBACK SetObjectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SETOBJECTCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_SETOBJECTCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_SETOBJECTCLASS                                                                2

struct StructOfAttachSetObjectClass{
};
struct StructOfSetObjectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SOUNDPOOLCLASS                                                                   "SoundPoolClass"
extern VS_UUID VSOBJID_SoundPoolClass;
#define VSATTRDEPEND_SOUNDPOOLCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SOUNDPOOLCLASS                                                             2
extern VS_INT32 SRPCALLBACK SoundPoolClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SOUNDPOOLCLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_SOUNDPOOLCLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_SOUNDPOOLCLASS                                                                2

struct StructOfAttachSoundPoolClass{
};
struct StructOfSoundPoolClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TWOLINELISTITEMCLASS                                                             "TwoLineListItemClass"
extern VS_UUID VSOBJID_TwoLineListItemClass;
#define VSATTRDEPEND_TWOLINELISTITEMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_TWOLINELISTITEMCLASS                                                       5
extern VS_INT32 SRPCALLBACK TwoLineListItemClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TWOLINELISTITEMCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_TWOLINELISTITEMCLASS_OBJECTLIST                                                1
#define VSATTRINDEX_TWOLINELISTITEMCLASS_VIEWGROUPQUEUE                                            2
#define VSATTRINDEX_TWOLINELISTITEMCLASS_VIEWQUEUE                                                 3
#define VSATTRINDEX_TWOLINELISTITEMCLASS_OBJECTQUEUE                                               4
#define VSATTRNUMBER_TWOLINELISTITEMCLASS                                                          5

struct StructOfAttachTwoLineListItemClass{
};
struct StructOfTwoLineListItemClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DATEPICKERDIALOGCLASS                                                            "DatePickerDialogClass"
extern VS_UUID VSOBJID_DatePickerDialogClass;
#define VSATTRDEPEND_DATEPICKERDIALOGCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}}
#define VSATTRDEPENDNUM_DATEPICKERDIALOGCLASS                                                      3
extern VS_INT32 SRPCALLBACK DatePickerDialogClass_RequestRegisterObject( );

/*----output event: onDateSet[]  Static Event */
extern VS_UUID VSOUTEVENTID_DatePickerDialogClass_onDateSet;

/*------Variable Index Define */
#define VSATTRINDEX_DATEPICKERDIALOGCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_DATEPICKERDIALOGCLASS_OBJECTLIST                                               1
#define VSATTRINDEX_DATEPICKERDIALOGCLASS_DIALOGINTERFACEQUEUE                                     2
#define VSATTRNUMBER_DATEPICKERDIALOGCLASS                                                         3

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_DatePickerDialogClass_onDateChanged;
#define VSFUNCRETURNDEPEND_DATEPICKERDIALOGCLASS_ONDATECHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_DATEPICKERDIALOGCLASS_ONDATECHANGED                                  0
#define VSFUNCPARAMDEPEND_DATEPICKERDIALOGCLASS_ONDATECHANGED(X)  {{X[0].Type=6;}{X[1].Type=6;}{X[2].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_DATEPICKERDIALOGCLASS_ONDATECHANGED                                   3

extern void SRPAPI DatePickerDialogClass_onDateChanged(void *Object,VS_INT32 onDateChanged,VS_INT32 month,VS_INT32 day);
typedef void (SRPAPI *DatePickerDialogClass_onDateChangedProc)(void *Object,VS_INT32 onDateChanged,VS_INT32 month,VS_INT32 day);

struct StructOfAttachDatePickerDialogClass{
};
struct StructOfDatePickerDialogClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[AlertDialogClass] attribute
    void            *DialogInterfaceQueue;        //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LISTOBJECTCLASS                                                                  "ListObjectClass"
extern VS_UUID VSOBJID_ListObjectClass;
#define VSATTRDEPEND_LISTOBJECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LISTOBJECTCLASS                                                            2
extern VS_INT32 SRPCALLBACK ListObjectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LISTOBJECTCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_LISTOBJECTCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_LISTOBJECTCLASS                                                               2

struct StructOfAttachListObjectClass{
};
struct StructOfListObjectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SENSORCLASS                                                                      "SensorClass"
extern VS_UUID VSOBJID_SensorClass;
#define VSATTRDEPEND_SENSORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SENSORCLASS                                                                2
extern VS_INT32 SRPCALLBACK SensorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SENSORCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_SENSORCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_SENSORCLASS                                                                   2

struct StructOfAttachSensorClass{
};
struct StructOfSensorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PORTERDUFFCOLORFILTERCLASS                                                       "PorterDuffColorFilterClass"
extern VS_UUID VSOBJID_PorterDuffColorFilterClass;
#define VSATTRDEPEND_PORTERDUFFCOLORFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PORTERDUFFCOLORFILTERCLASS                                                 2
extern VS_INT32 SRPCALLBACK PorterDuffColorFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_PORTERDUFFCOLORFILTERCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_PORTERDUFFCOLORFILTERCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_PORTERDUFFCOLORFILTERCLASS                                                    2

struct StructOfAttachPorterDuffColorFilterClass{
};
struct StructOfPorterDuffColorFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BASEINPUTCONNECTIONCLASS                                                         "BaseInputConnectionClass"
extern VS_UUID VSOBJID_BaseInputConnectionClass;
#define VSATTRDEPEND_BASEINPUTCONNECTIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BASEINPUTCONNECTIONCLASS                                                   2
extern VS_INT32 SRPCALLBACK BaseInputConnectionClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BASEINPUTCONNECTIONCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_BASEINPUTCONNECTIONCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_BASEINPUTCONNECTIONCLASS                                                      2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_BaseInputConnectionClass_commitText;
#define VSFUNCRETURNDEPEND_BASEINPUTCONNECTIONCLASS_COMMITTEXT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_BASEINPUTCONNECTIONCLASS_COMMITTEXT                                  1
#define VSFUNCPARAMDEPEND_BASEINPUTCONNECTIONCLASS_COMMITTEXT(X)  {{X[0].Type=30;}{X[1].Type=6;}}
#define VSFUNCPARAMDEPENDNUM_BASEINPUTCONNECTIONCLASS_COMMITTEXT                                   2

extern VS_BOOL SRPAPI BaseInputConnectionClass_commitText(void *Object,VS_CHAR * text,VS_INT32 newCursorPosition);
typedef VS_BOOL (SRPAPI *BaseInputConnectionClass_commitTextProc)(void *Object,VS_CHAR * text,VS_INT32 newCursorPosition);

struct StructOfAttachBaseInputConnectionClass{
};
struct StructOfBaseInputConnectionClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANTICIPATEOVERSHOOTINTERPOLATORCLASS                                             "AnticipateOvershootInterpolatorClass"
extern VS_UUID VSOBJID_AnticipateOvershootInterpolatorClass;
#define VSATTRDEPEND_ANTICIPATEOVERSHOOTINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANTICIPATEOVERSHOOTINTERPOLATORCLASS                                       2
extern VS_INT32 SRPCALLBACK AnticipateOvershootInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANTICIPATEOVERSHOOTINTERPOLATORCLASS_ANDROIDREFCOUNT                           0
#define VSATTRINDEX_ANTICIPATEOVERSHOOTINTERPOLATORCLASS_OBJECTLIST                                1
#define VSATTRNUMBER_ANTICIPATEOVERSHOOTINTERPOLATORCLASS                                          2

struct StructOfAttachAnticipateOvershootInterpolatorClass{
};
struct StructOfAnticipateOvershootInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_POINTCLASS                                                                       "PointClass"
extern VS_UUID VSOBJID_PointClass;
#define VSATTRDEPEND_POINTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=6;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_POINTCLASS                                                                 2
extern VS_INT32 SRPCALLBACK PointClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_POINTCLASS_X                                                                   0
#define VSATTRINDEX_POINTCLASS_Y                                                                   1
#define VSATTRNUMBER_POINTCLASS                                                                    2

struct StructOfAttachPointClass{
};
struct StructOfPointClass{
    //----local attribute
    VS_INT32        x;                            //
    VS_INT32        y;                            //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TIMEZONECLASS                                                                    "TimeZoneClass"
extern VS_UUID VSOBJID_TimeZoneClass;
#define VSATTRDEPEND_TIMEZONECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TIMEZONECLASS                                                              2
extern VS_INT32 SRPCALLBACK TimeZoneClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TIMEZONECLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_TIMEZONECLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_TIMEZONECLASS                                                                 2

struct StructOfAttachTimeZoneClass{
};
struct StructOfTimeZoneClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ABSLISTVIEWCLASS                                                                 "AbsListViewClass"
extern VS_UUID VSOBJID_AbsListViewClass;
#define VSATTRDEPEND_ABSLISTVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_ABSLISTVIEWCLASS                                                           5
extern VS_INT32 SRPCALLBACK AbsListViewClass_RequestRegisterObject( );

/*----output event: onScroll[]  Static Event */
extern VS_UUID VSOUTEVENTID_AbsListViewClass_onScroll;
/*----output event: onScrollStateChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_AbsListViewClass_onScrollStateChanged;
/*----output event: onMovedToScrapHeap[]  Static Event */
extern VS_UUID VSOUTEVENTID_AbsListViewClass_onMovedToScrapHeap;

/*------Variable Index Define */
#define VSATTRINDEX_ABSLISTVIEWCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ABSLISTVIEWCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_ABSLISTVIEWCLASS_VIEWGROUPQUEUE                                                2
#define VSATTRINDEX_ABSLISTVIEWCLASS_VIEWQUEUE                                                     3
#define VSATTRINDEX_ABSLISTVIEWCLASS_OBJECTQUEUE                                                   4
#define VSATTRNUMBER_ABSLISTVIEWCLASS                                                              5

struct StructOfAttachAbsListViewClass{
};
struct StructOfAbsListViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ITERABLEOBJECTCLASS                                                              "IterableObjectClass"
extern VS_UUID VSOBJID_IterableObjectClass;
#define VSATTRDEPEND_ITERABLEOBJECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ITERABLEOBJECTCLASS                                                        2
extern VS_INT32 SRPCALLBACK IterableObjectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ITERABLEOBJECTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_ITERABLEOBJECTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_ITERABLEOBJECTCLASS                                                           2

struct StructOfAttachIterableObjectClass{
};
struct StructOfIterableObjectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_PENDINGINTENTCLASS                                                               "PendingIntentClass"
extern VS_UUID VSOBJID_PendingIntentClass;
#define VSATTRDEPEND_PENDINGINTENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_PENDINGINTENTCLASS                                                         2
extern VS_INT32 SRPCALLBACK PendingIntentClass_RequestRegisterObject( );

/*----output event: onSendFinished[]  Static Event */
extern VS_UUID VSOUTEVENTID_PendingIntentClass_onSendFinished;

/*------Variable Index Define */
#define VSATTRINDEX_PENDINGINTENTCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_PENDINGINTENTCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_PENDINGINTENTCLASS                                                            2

struct StructOfAttachPendingIntentClass{
};
struct StructOfPendingIntentClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COLORMATRIXCOLORFILTERCLASS                                                      "ColorMatrixColorFilterClass"
extern VS_UUID VSOBJID_ColorMatrixColorFilterClass;
#define VSATTRDEPEND_COLORMATRIXCOLORFILTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COLORMATRIXCOLORFILTERCLASS                                                2
extern VS_INT32 SRPCALLBACK ColorMatrixColorFilterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COLORMATRIXCOLORFILTERCLASS_ANDROIDREFCOUNT                                    0
#define VSATTRINDEX_COLORMATRIXCOLORFILTERCLASS_OBJECTLIST                                         1
#define VSATTRNUMBER_COLORMATRIXCOLORFILTERCLASS                                                   2

struct StructOfAttachColorMatrixColorFilterClass{
};
struct StructOfColorMatrixColorFilterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LINEARINTERPOLATORCLASS                                                          "LinearInterpolatorClass"
extern VS_UUID VSOBJID_LinearInterpolatorClass;
#define VSATTRDEPEND_LINEARINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LINEARINTERPOLATORCLASS                                                    2
extern VS_INT32 SRPCALLBACK LinearInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LINEARINTERPOLATORCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_LINEARINTERPOLATORCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_LINEARINTERPOLATORCLASS                                                       2

struct StructOfAttachLinearInterpolatorClass{
};
struct StructOfLinearInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMPOUNDBUTTONCLASS                                                              "CompoundButtonClass"
extern VS_UUID VSOBJID_CompoundButtonClass;
#define VSATTRDEPEND_COMPOUNDBUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMPOUNDBUTTONCLASS                                                        2
extern VS_INT32 SRPCALLBACK CompoundButtonClass_RequestRegisterObject( );

/*----output event: onCheckedChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_CompoundButtonClass_onCheckedChanged;

/*------Variable Index Define */
#define VSATTRINDEX_COMPOUNDBUTTONCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_COMPOUNDBUTTONCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_COMPOUNDBUTTONCLASS                                                           2

struct StructOfAttachCompoundButtonClass{
};
struct StructOfCompoundButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GRIDVIEWCLASS                                                                    "GridViewClass"
extern VS_UUID VSOBJID_GridViewClass;
#define VSATTRDEPEND_GRIDVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_GRIDVIEWCLASS                                                              5
extern VS_INT32 SRPCALLBACK GridViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GRIDVIEWCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_GRIDVIEWCLASS_OBJECTLIST                                                       1
#define VSATTRINDEX_GRIDVIEWCLASS_VIEWGROUPQUEUE                                                   2
#define VSATTRINDEX_GRIDVIEWCLASS_VIEWQUEUE                                                        3
#define VSATTRINDEX_GRIDVIEWCLASS_OBJECTQUEUE                                                      4
#define VSATTRNUMBER_GRIDVIEWCLASS                                                                 5

struct StructOfAttachGridViewClass{
};
struct StructOfGridViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTEXTCLASS                                                                     "ContextClass"
extern VS_UUID VSOBJID_ContextClass;
#define VSATTRDEPEND_CONTEXTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTEXTCLASS                                                               2
extern VS_INT32 SRPCALLBACK ContextClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTEXTCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_CONTEXTCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_CONTEXTCLASS                                                                  2

struct StructOfAttachContextClass{
};
struct StructOfContextClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CALENDARCLASS                                                                    "CalendarClass"
extern VS_UUID VSOBJID_CalendarClass;
#define VSATTRDEPEND_CALENDARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CALENDARCLASS                                                              2
extern VS_INT32 SRPCALLBACK CalendarClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CALENDARCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_CALENDARCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_CALENDARCLASS                                                                 2

struct StructOfAttachCalendarClass{
};
struct StructOfCalendarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_SHAREDPREFERENCESCLASS                                                           "SharedPreferencesClass"
extern VS_UUID VSOBJID_SharedPreferencesClass;
#define VSATTRDEPEND_SHAREDPREFERENCESCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_SHAREDPREFERENCESCLASS                                                     2
extern VS_INT32 SRPCALLBACK SharedPreferencesClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_SHAREDPREFERENCESCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_SHAREDPREFERENCESCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_SHAREDPREFERENCESCLASS                                                        2

struct StructOfAttachSharedPreferencesClass{
};
struct StructOfSharedPreferencesClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANIMATIONDRAWABLECLASS                                                           "AnimationDrawableClass"
extern VS_UUID VSOBJID_AnimationDrawableClass;
#define VSATTRDEPEND_ANIMATIONDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANIMATIONDRAWABLECLASS                                                     2
extern VS_INT32 SRPCALLBACK AnimationDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANIMATIONDRAWABLECLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_ANIMATIONDRAWABLECLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_ANIMATIONDRAWABLECLASS                                                        2

struct StructOfAttachAnimationDrawableClass{
};
struct StructOfAnimationDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_HORIZONTALSCROLLVIEWCLASS                                                        "HorizontalScrollViewClass"
extern VS_UUID VSOBJID_HorizontalScrollViewClass;
#define VSATTRDEPEND_HORIZONTALSCROLLVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_HORIZONTALSCROLLVIEWCLASS                                                  5
extern VS_INT32 SRPCALLBACK HorizontalScrollViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_HORIZONTALSCROLLVIEWCLASS_ANDROIDREFCOUNT                                      0
#define VSATTRINDEX_HORIZONTALSCROLLVIEWCLASS_OBJECTLIST                                           1
#define VSATTRINDEX_HORIZONTALSCROLLVIEWCLASS_VIEWGROUPQUEUE                                       2
#define VSATTRINDEX_HORIZONTALSCROLLVIEWCLASS_VIEWQUEUE                                            3
#define VSATTRINDEX_HORIZONTALSCROLLVIEWCLASS_OBJECTQUEUE                                          4
#define VSATTRNUMBER_HORIZONTALSCROLLVIEWCLASS                                                     5

struct StructOfAttachHorizontalScrollViewClass{
};
struct StructOfHorizontalScrollViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ABSSEEKBARCLASS                                                                  "AbsSeekBarClass"
extern VS_UUID VSOBJID_AbsSeekBarClass;
#define VSATTRDEPEND_ABSSEEKBARCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ABSSEEKBARCLASS                                                            2
extern VS_INT32 SRPCALLBACK AbsSeekBarClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ABSSEEKBARCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_ABSSEEKBARCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_ABSSEEKBARCLASS                                                               2

struct StructOfAttachAbsSeekBarClass{
};
struct StructOfAbsSeekBarClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_POPUPWINDOWCLASS                                                                 "PopupWindowClass"
extern VS_UUID VSOBJID_PopupWindowClass;
#define VSATTRDEPEND_POPUPWINDOWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_POPUPWINDOWCLASS                                                           2
extern VS_INT32 SRPCALLBACK PopupWindowClass_RequestRegisterObject( );

/*----output event: onDismiss[]  Static Event */
extern VS_UUID VSOUTEVENTID_PopupWindowClass_onDismiss;

/*------Variable Index Define */
#define VSATTRINDEX_POPUPWINDOWCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_POPUPWINDOWCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_POPUPWINDOWCLASS                                                              2

struct StructOfAttachPopupWindowClass{
};
struct StructOfPopupWindowClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BUTTONCLASS                                                                      "ButtonClass"
extern VS_UUID VSOBJID_ButtonClass;
#define VSATTRDEPEND_BUTTONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BUTTONCLASS                                                                2
extern VS_INT32 SRPCALLBACK ButtonClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BUTTONCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_BUTTONCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_BUTTONCLASS                                                                   2

struct StructOfAttachButtonClass{
};
struct StructOfButtonClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_GRADIENTDRAWABLECLASS                                                            "GradientDrawableClass"
extern VS_UUID VSOBJID_GradientDrawableClass;
#define VSATTRDEPEND_GRADIENTDRAWABLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_GRADIENTDRAWABLECLASS                                                      2
extern VS_INT32 SRPCALLBACK GradientDrawableClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_GRADIENTDRAWABLECLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_GRADIENTDRAWABLECLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_GRADIENTDRAWABLECLASS                                                         2

struct StructOfAttachGradientDrawableClass{
};
struct StructOfGradientDrawableClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ADAPTERVIEWCLASS                                                                 "AdapterViewClass"
extern VS_UUID VSOBJID_AdapterViewClass;
#define VSATTRDEPEND_ADAPTERVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_ADAPTERVIEWCLASS                                                           5
extern VS_INT32 SRPCALLBACK AdapterViewClass_RequestRegisterObject( );

/*----output event: onItemClick[ParaPkg[0] view._ID,position,id;script(event,_ID,position,id)]  Static Event */
extern VS_UUID VSOUTEVENTID_AdapterViewClass_onItemClick;
/*----output event: onItemLongClick[]  Static Event */
extern VS_UUID VSOUTEVENTID_AdapterViewClass_onItemLongClick;
/*----output event: onItemSelected[]  Static Event */
extern VS_UUID VSOUTEVENTID_AdapterViewClass_onItemSelected;
/*----output event: onNothingSelected[]  Static Event */
extern VS_UUID VSOUTEVENTID_AdapterViewClass_onNothingSelected;

/*------Variable Index Define */
#define VSATTRINDEX_ADAPTERVIEWCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_ADAPTERVIEWCLASS_OBJECTLIST                                                    1
#define VSATTRINDEX_ADAPTERVIEWCLASS_VIEWGROUPQUEUE                                                2
#define VSATTRINDEX_ADAPTERVIEWCLASS_VIEWQUEUE                                                     3
#define VSATTRINDEX_ADAPTERVIEWCLASS_OBJECTQUEUE                                                   4
#define VSATTRNUMBER_ADAPTERVIEWCLASS                                                              5

struct StructOfAttachAdapterViewClass{
};
struct StructOfAdapterViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BYTEARRAYOUTPUTSTREAMCLASS                                                       "ByteArrayOutputStreamClass"
extern VS_UUID VSOBJID_ByteArrayOutputStreamClass;
#define VSATTRDEPEND_BYTEARRAYOUTPUTSTREAMCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BYTEARRAYOUTPUTSTREAMCLASS                                                 2
extern VS_INT32 SRPCALLBACK ByteArrayOutputStreamClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BYTEARRAYOUTPUTSTREAMCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_BYTEARRAYOUTPUTSTREAMCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_BYTEARRAYOUTPUTSTREAMCLASS                                                    2

struct StructOfAttachByteArrayOutputStreamClass{
};
struct StructOfByteArrayOutputStreamClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DISPLAYMETRICSCLASS                                                              "DisplayMetricsClass"
extern VS_UUID VSOBJID_DisplayMetricsClass;
#define VSATTRDEPEND_DISPLAYMETRICSCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DISPLAYMETRICSCLASS                                                        2
extern VS_INT32 SRPCALLBACK DisplayMetricsClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DISPLAYMETRICSCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_DISPLAYMETRICSCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_DISPLAYMETRICSCLASS                                                           2

struct StructOfAttachDisplayMetricsClass{
};
struct StructOfDisplayMetricsClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TRANSLATEANIMATIONCLASS                                                          "TranslateAnimationClass"
extern VS_UUID VSOBJID_TranslateAnimationClass;
#define VSATTRDEPEND_TRANSLATEANIMATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TRANSLATEANIMATIONCLASS                                                    2
extern VS_INT32 SRPCALLBACK TranslateAnimationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TRANSLATEANIMATIONCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_TRANSLATEANIMATIONCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_TRANSLATEANIMATIONCLASS                                                       2

struct StructOfAttachTranslateAnimationClass{
};
struct StructOfTranslateAnimationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RINGTONEMANAGERCLASS                                                             "RingtoneManagerClass"
extern VS_UUID VSOBJID_RingtoneManagerClass;
#define VSATTRDEPEND_RINGTONEMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RINGTONEMANAGERCLASS                                                       2
extern VS_INT32 SRPCALLBACK RingtoneManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RINGTONEMANAGERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_RINGTONEMANAGERCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_RINGTONEMANAGERCLASS                                                          2

struct StructOfAttachRingtoneManagerClass{
};
struct StructOfRingtoneManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TELEPHONYMANAGERCLASS                                                            "TelephonyManagerClass"
extern VS_UUID VSOBJID_TelephonyManagerClass;
#define VSATTRDEPEND_TELEPHONYMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TELEPHONYMANAGERCLASS                                                      2
extern VS_INT32 SRPCALLBACK TelephonyManagerClass_RequestRegisterObject( );

/*----output event: onCallForwardingIndicatorChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onCallForwardingIndicatorChanged;
/*----output event: onCallStateChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onCallStateChanged;
/*----output event: onCellLocationChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onCellLocationChanged;
/*----output event: onDataActivity[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onDataActivity;
/*----output event: onDataConnectionStateChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onDataConnectionStateChanged;
/*----output event: onMessageWaitingIndicatorChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onMessageWaitingIndicatorChanged;
/*----output event: onSignalStrengthChanged[]  Static Event */
extern VS_UUID VSOUTEVENTID_TelephonyManagerClass_onSignalStrengthChanged;

/*------Variable Index Define */
#define VSATTRINDEX_TELEPHONYMANAGERCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_TELEPHONYMANAGERCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_TELEPHONYMANAGERCLASS                                                         2

struct StructOfAttachTelephonyManagerClass{
};
struct StructOfTelephonyManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_JSPROMPTRESULTCLASS                                                              "JsPromptResultClass"
extern VS_UUID VSOBJID_JsPromptResultClass;
#define VSATTRDEPEND_JSPROMPTRESULTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_JSPROMPTRESULTCLASS                                                        2
extern VS_INT32 SRPCALLBACK JsPromptResultClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_JSPROMPTRESULTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_JSPROMPTRESULTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_JSPROMPTRESULTCLASS                                                           2

struct StructOfAttachJsPromptResultClass{
};
struct StructOfJsPromptResultClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CDMACELLLOCATIONCLASS                                                            "CdmaCellLocationClass"
extern VS_UUID VSOBJID_CdmaCellLocationClass;
#define VSATTRDEPEND_CDMACELLLOCATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CDMACELLLOCATIONCLASS                                                      2
extern VS_INT32 SRPCALLBACK CdmaCellLocationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CDMACELLLOCATIONCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_CDMACELLLOCATIONCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_CDMACELLLOCATIONCLASS                                                         2

struct StructOfAttachCdmaCellLocationClass{
};
struct StructOfCdmaCellLocationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_EDITORCLASS                                                                      "EditorClass"
extern VS_UUID VSOBJID_EditorClass;
#define VSATTRDEPEND_EDITORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_EDITORCLASS                                                                2
extern VS_INT32 SRPCALLBACK EditorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_EDITORCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_EDITORCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_EDITORCLASS                                                                   2

struct StructOfAttachEditorClass{
};
struct StructOfEditorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWFACTORYCLASS                                                                 "ViewFactoryClass"
extern VS_UUID VSOBJID_ViewFactoryClass;
#define VSATTRDEPEND_VIEWFACTORYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIEWFACTORYCLASS                                                           2
extern VS_INT32 SRPCALLBACK ViewFactoryClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWFACTORYCLASS_ANDROIDREFCOUNT                                               0
#define VSATTRINDEX_VIEWFACTORYCLASS_OBJECTLIST                                                    1
#define VSATTRNUMBER_VIEWFACTORYCLASS                                                              2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_ViewFactoryClass_makeView;
#define VSFUNCRETURNDEPEND_VIEWFACTORYCLASS_MAKEVIEW(X)  {{X[0].Type=57;}}
#define VSFUNCRETURNDEPENDNUM_VIEWFACTORYCLASS_MAKEVIEW                                            1
#define VSFUNCPARAMDEPEND_VIEWFACTORYCLASS_MAKEVIEW(X)  {}
#define VSFUNCPARAMDEPENDNUM_VIEWFACTORYCLASS_MAKEVIEW                                             0

extern VS_OBJPTR SRPAPI ViewFactoryClass_makeView(void *Object);
typedef VS_OBJPTR (SRPAPI *ViewFactoryClass_makeViewProc)(void *Object);

struct StructOfAttachViewFactoryClass{
};
struct StructOfViewFactoryClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_OSBUILDCLASS                                                                     "OsBuildClass"
extern VS_UUID VSOBJID_OsBuildClass;
#define VSATTRDEPEND_OSBUILDCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_OSBUILDCLASS                                                               2
extern VS_INT32 SRPCALLBACK OsBuildClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_OSBUILDCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_OSBUILDCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_OSBUILDCLASS                                                                  2

struct StructOfAttachOsBuildClass{
};
struct StructOfOsBuildClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_INPUTMETHODMANAGERCLASS                                                          "InputMethodManagerClass"
extern VS_UUID VSOBJID_InputMethodManagerClass;
#define VSATTRDEPEND_INPUTMETHODMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_INPUTMETHODMANAGERCLASS                                                    2
extern VS_INT32 SRPCALLBACK InputMethodManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_INPUTMETHODMANAGERCLASS_ANDROIDREFCOUNT                                        0
#define VSATTRINDEX_INPUTMETHODMANAGERCLASS_OBJECTLIST                                             1
#define VSATTRNUMBER_INPUTMETHODMANAGERCLASS                                                       2

struct StructOfAttachInputMethodManagerClass{
};
struct StructOfInputMethodManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RADIALGRADIENTCLASS                                                              "RadialGradientClass"
extern VS_UUID VSOBJID_RadialGradientClass;
#define VSATTRDEPEND_RADIALGRADIENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RADIALGRADIENTCLASS                                                        2
extern VS_INT32 SRPCALLBACK RadialGradientClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RADIALGRADIENTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_RADIALGRADIENTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_RADIALGRADIENTCLASS                                                           2

struct StructOfAttachRadialGradientClass{
};
struct StructOfRadialGradientClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_STARSIMPLEADAPTERCLASS                                                           "StarSimpleAdapterClass"
extern VS_UUID VSOBJID_StarSimpleAdapterClass;
#define VSATTRDEPEND_STARSIMPLEADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_STARSIMPLEADAPTERCLASS                                                     2
extern VS_INT32 SRPCALLBACK StarSimpleAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_STARSIMPLEADAPTERCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_STARSIMPLEADAPTERCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_STARSIMPLEADAPTERCLASS                                                        2

struct StructOfAttachStarSimpleAdapterClass{
};
struct StructOfStarSimpleAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMPOSESHADERCLASS                                                               "ComposeShaderClass"
extern VS_UUID VSOBJID_ComposeShaderClass;
#define VSATTRDEPEND_COMPOSESHADERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMPOSESHADERCLASS                                                         2
extern VS_INT32 SRPCALLBACK ComposeShaderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COMPOSESHADERCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_COMPOSESHADERCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_COMPOSESHADERCLASS                                                            2

struct StructOfAttachComposeShaderClass{
};
struct StructOfComposeShaderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WEBVIEWCLIENTCLASS                                                               "WebViewClientClass"
extern VS_UUID VSOBJID_WebViewClientClass;
#define VSATTRDEPEND_WEBVIEWCLIENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_WEBVIEWCLIENTCLASS                                                         2
extern VS_INT32 SRPCALLBACK WebViewClientClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WEBVIEWCLIENTCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_WEBVIEWCLIENTCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_WEBVIEWCLIENTCLASS                                                            2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_doUpdateVisitedHistory;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_DOUPDATEVISITEDHISTORY(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_DOUPDATEVISITEDHISTORY                            0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_DOUPDATEVISITEDHISTORY(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=1;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_DOUPDATEVISITEDHISTORY                             3

extern void SRPAPI WebViewClientClass_doUpdateVisitedHistory(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_BOOL isReload);
typedef void (SRPAPI *WebViewClientClass_doUpdateVisitedHistoryProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_BOOL isReload);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onLoadResource;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONLOADRESOURCE(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONLOADRESOURCE                                    0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONLOADRESOURCE(X)  {{X[0].Type=57;}{X[1].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONLOADRESOURCE                                     2

extern void SRPAPI WebViewClientClass_onLoadResource(void *Object,VS_OBJPTR view,VS_CHAR * url);
typedef void (SRPAPI *WebViewClientClass_onLoadResourceProc)(void *Object,VS_OBJPTR view,VS_CHAR * url);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onPageFinished;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONPAGEFINISHED(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONPAGEFINISHED                                    0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONPAGEFINISHED(X)  {{X[0].Type=57;}{X[1].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONPAGEFINISHED                                     2

extern void SRPAPI WebViewClientClass_onPageFinished(void *Object,VS_OBJPTR view,VS_CHAR * url);
typedef void (SRPAPI *WebViewClientClass_onPageFinishedProc)(void *Object,VS_OBJPTR view,VS_CHAR * url);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onPageStarted;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONPAGESTARTED(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONPAGESTARTED                                     0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONPAGESTARTED(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONPAGESTARTED                                      3

extern void SRPAPI WebViewClientClass_onPageStarted(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_OBJPTR favicon);
typedef void (SRPAPI *WebViewClientClass_onPageStartedProc)(void *Object,VS_OBJPTR view,VS_CHAR * url,VS_OBJPTR favicon);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onReceivedError;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONRECEIVEDERROR(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONRECEIVEDERROR                                   0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONRECEIVEDERROR(X)  {{X[0].Type=57;}{X[1].Type=6;}{X[2].Type=30;}{X[3].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONRECEIVEDERROR                                    4

extern void SRPAPI WebViewClientClass_onReceivedError(void *Object,VS_OBJPTR view,VS_INT32 errorCode,VS_CHAR * description,VS_CHAR * failingUrl);
typedef void (SRPAPI *WebViewClientClass_onReceivedErrorProc)(void *Object,VS_OBJPTR view,VS_INT32 errorCode,VS_CHAR * description,VS_CHAR * failingUrl);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onReceivedLoginRequest;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONRECEIVEDLOGINREQUEST(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONRECEIVEDLOGINREQUEST                            0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONRECEIVEDLOGINREQUEST(X)  {{X[0].Type=57;}{X[1].Type=30;}{X[2].Type=30;}{X[3].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONRECEIVEDLOGINREQUEST                             4

extern void SRPAPI WebViewClientClass_onReceivedLoginRequest(void *Object,VS_OBJPTR view,VS_CHAR * realm,VS_CHAR * account,VS_CHAR * args);
typedef void (SRPAPI *WebViewClientClass_onReceivedLoginRequestProc)(void *Object,VS_OBJPTR view,VS_CHAR * realm,VS_CHAR * account,VS_CHAR * args);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onScaleChanged;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONSCALECHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONSCALECHANGED                                    0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONSCALECHANGED(X)  {{X[0].Type=57;}{X[1].Type=8;}{X[2].Type=8;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONSCALECHANGED                                     3

extern void SRPAPI WebViewClientClass_onScaleChanged(void *Object,VS_OBJPTR view,VS_FLOAT oldScale,VS_FLOAT newScale);
typedef void (SRPAPI *WebViewClientClass_onScaleChangedProc)(void *Object,VS_OBJPTR view,VS_FLOAT oldScale,VS_FLOAT newScale);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_onUnhandledKeyEvent;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_ONUNHANDLEDKEYEVENT(X)  {}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_ONUNHANDLEDKEYEVENT                               0
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_ONUNHANDLEDKEYEVENT(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_ONUNHANDLEDKEYEVENT                                2

extern void SRPAPI WebViewClientClass_onUnhandledKeyEvent(void *Object,VS_OBJPTR view,VS_OBJPTR event);
typedef void (SRPAPI *WebViewClientClass_onUnhandledKeyEventProc)(void *Object,VS_OBJPTR view,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_shouldOverrideKeyEvent;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEKEYEVENT(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEKEYEVENT                            1
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEKEYEVENT(X)  {{X[0].Type=57;}{X[1].Type=57;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEKEYEVENT                             2

extern VS_BOOL SRPAPI WebViewClientClass_shouldOverrideKeyEvent(void *Object,VS_OBJPTR view,VS_OBJPTR event);
typedef VS_BOOL (SRPAPI *WebViewClientClass_shouldOverrideKeyEventProc)(void *Object,VS_OBJPTR view,VS_OBJPTR event);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_WebViewClientClass_shouldOverrideUrlLoading;
#define VSFUNCRETURNDEPEND_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEURLLOADING(X)  {{X[0].Type=1;}}
#define VSFUNCRETURNDEPENDNUM_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEURLLOADING                          1
#define VSFUNCPARAMDEPEND_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEURLLOADING(X)  {{X[0].Type=57;}{X[1].Type=30;}}
#define VSFUNCPARAMDEPENDNUM_WEBVIEWCLIENTCLASS_SHOULDOVERRIDEURLLOADING                           2

extern VS_BOOL SRPAPI WebViewClientClass_shouldOverrideUrlLoading(void *Object,VS_OBJPTR view,VS_CHAR * url);
typedef VS_BOOL (SRPAPI *WebViewClientClass_shouldOverrideUrlLoadingProc)(void *Object,VS_OBJPTR view,VS_CHAR * url);

struct StructOfAttachWebViewClientClass{
};
struct StructOfWebViewClientClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_TYPEDARRAYCLASS                                                                  "TypedArrayClass"
extern VS_UUID VSOBJID_TypedArrayClass;
#define VSATTRDEPEND_TYPEDARRAYCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_TYPEDARRAYCLASS                                                            2
extern VS_INT32 SRPCALLBACK TypedArrayClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_TYPEDARRAYCLASS_ANDROIDREFCOUNT                                                0
#define VSATTRINDEX_TYPEDARRAYCLASS_OBJECTLIST                                                     1
#define VSATTRNUMBER_TYPEDARRAYCLASS                                                               2

struct StructOfAttachTypedArrayClass{
};
struct StructOfTypedArrayClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RECTSHAPECLASS                                                                   "RectShapeClass"
extern VS_UUID VSOBJID_RectShapeClass;
#define VSATTRDEPEND_RECTSHAPECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RECTSHAPECLASS                                                             2
extern VS_INT32 SRPCALLBACK RectShapeClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RECTSHAPECLASS_ANDROIDREFCOUNT                                                 0
#define VSATTRINDEX_RECTSHAPECLASS_OBJECTLIST                                                      1
#define VSATTRNUMBER_RECTSHAPECLASS                                                                2

struct StructOfAttachRectShapeClass{
};
struct StructOfRectShapeClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ANIMATIONSETCLASS                                                                "AnimationSetClass"
extern VS_UUID VSOBJID_AnimationSetClass;
#define VSATTRDEPEND_ANIMATIONSETCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ANIMATIONSETCLASS                                                          2
extern VS_INT32 SRPCALLBACK AnimationSetClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ANIMATIONSETCLASS_ANDROIDREFCOUNT                                              0
#define VSATTRINDEX_ANIMATIONSETCLASS_OBJECTLIST                                                   1
#define VSATTRNUMBER_ANIMATIONSETCLASS                                                             2

struct StructOfAttachAnimationSetClass{
};
struct StructOfAnimationSetClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_BUNDLECLASS                                                                      "BundleClass"
extern VS_UUID VSOBJID_BundleClass;
#define VSATTRDEPEND_BUNDLECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_BUNDLECLASS                                                                2
extern VS_INT32 SRPCALLBACK BundleClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_BUNDLECLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_BUNDLECLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_BUNDLECLASS                                                                   2

struct StructOfAttachBundleClass{
};
struct StructOfBundleClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_STRINGHASHMAPCLASS                                                               "StringHashMapClass"
extern VS_UUID VSOBJID_StringHashMapClass;
#define VSATTRDEPEND_STRINGHASHMAPCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_STRINGHASHMAPCLASS                                                         2
extern VS_INT32 SRPCALLBACK StringHashMapClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_STRINGHASHMAPCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_STRINGHASHMAPCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_STRINGHASHMAPCLASS                                                            2

struct StructOfAttachStringHashMapClass{
};
struct StructOfStringHashMapClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_ACCELERATEDECELERATEINTERPOLATORCLASS                                            "AccelerateDecelerateInterpolatorClass"
extern VS_UUID VSOBJID_AccelerateDecelerateInterpolatorClass;
#define VSATTRDEPEND_ACCELERATEDECELERATEINTERPOLATORCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_ACCELERATEDECELERATEINTERPOLATORCLASS                                      2
extern VS_INT32 SRPCALLBACK AccelerateDecelerateInterpolatorClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_ACCELERATEDECELERATEINTERPOLATORCLASS_ANDROIDREFCOUNT                          0
#define VSATTRINDEX_ACCELERATEDECELERATEINTERPOLATORCLASS_OBJECTLIST                               1
#define VSATTRNUMBER_ACCELERATEDECELERATEINTERPOLATORCLASS                                         2

struct StructOfAttachAccelerateDecelerateInterpolatorClass{
};
struct StructOfAccelerateDecelerateInterpolatorClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LINEARGRADIENTCLASS                                                              "LinearGradientClass"
extern VS_UUID VSOBJID_LinearGradientClass;
#define VSATTRDEPEND_LINEARGRADIENTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LINEARGRADIENTCLASS                                                        2
extern VS_INT32 SRPCALLBACK LinearGradientClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LINEARGRADIENTCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_LINEARGRADIENTCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_LINEARGRADIENTCLASS                                                           2

struct StructOfAttachLinearGradientClass{
};
struct StructOfLinearGradientClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_WEBVIEWCLASS                                                                     "WebViewClass"
extern VS_UUID VSOBJID_WebViewClass;
#define VSATTRDEPEND_WEBVIEWCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}{X[2].Type=14;X[2].Offset=8;}{X[3].Type=14;X[3].Offset=12;}{X[4].Type=14;X[4].Offset=16;}}
#define VSATTRDEPENDNUM_WEBVIEWCLASS                                                               5
extern VS_INT32 SRPCALLBACK WebViewClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_WEBVIEWCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_WEBVIEWCLASS_OBJECTLIST                                                        1
#define VSATTRINDEX_WEBVIEWCLASS_VIEWGROUPQUEUE                                                    2
#define VSATTRINDEX_WEBVIEWCLASS_VIEWQUEUE                                                         3
#define VSATTRINDEX_WEBVIEWCLASS_OBJECTQUEUE                                                       4
#define VSATTRNUMBER_WEBVIEWCLASS                                                                  5

struct StructOfAttachWebViewClass{
};
struct StructOfWebViewClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
    //----class[ViewGroupClass] attribute
    void            *ViewGroupQueue;              //
    void            *ViewQueue;                   //
    void            *ObjectQueue;                 //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTEXTWRAPPERCLASS                                                              "ContextWrapperClass"
extern VS_UUID VSOBJID_ContextWrapperClass;
#define VSATTRDEPEND_CONTEXTWRAPPERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTEXTWRAPPERCLASS                                                        2
extern VS_INT32 SRPCALLBACK ContextWrapperClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTEXTWRAPPERCLASS_ANDROIDREFCOUNT                                            0
#define VSATTRINDEX_CONTEXTWRAPPERCLASS_OBJECTLIST                                                 1
#define VSATTRNUMBER_CONTEXTWRAPPERCLASS                                                           2

struct StructOfAttachContextWrapperClass{
};
struct StructOfContextWrapperClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMMONDATAKINDS_EMAILCLASS                                                       "CommonDataKinds_EmailClass"
extern VS_UUID VSOBJID_CommonDataKinds_EmailClass;
#define VSATTRDEPEND_COMMONDATAKINDS_EMAILCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMMONDATAKINDS_EMAILCLASS                                                 2
extern VS_INT32 SRPCALLBACK CommonDataKinds_EmailClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COMMONDATAKINDS_EMAILCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_COMMONDATAKINDS_EMAILCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_COMMONDATAKINDS_EMAILCLASS                                                    2

struct StructOfAttachCommonDataKinds_EmailClass{
};
struct StructOfCommonDataKinds_EmailClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CANVASCLASS                                                                      "CanvasClass"
extern VS_UUID VSOBJID_CanvasClass;
#define VSATTRDEPEND_CANVASCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CANVASCLASS                                                                2
extern VS_INT32 SRPCALLBACK CanvasClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CANVASCLASS_ANDROIDREFCOUNT                                                    0
#define VSATTRINDEX_CANVASCLASS_OBJECTLIST                                                         1
#define VSATTRNUMBER_CANVASCLASS                                                                   2

struct StructOfAttachCanvasClass{
};
struct StructOfCanvasClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DATASETOBSERVERCLASS                                                             "DataSetObserverClass"
extern VS_UUID VSOBJID_DataSetObserverClass;
#define VSATTRDEPEND_DATASETOBSERVERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DATASETOBSERVERCLASS                                                       2
extern VS_INT32 SRPCALLBACK DataSetObserverClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DATASETOBSERVERCLASS_ANDROIDREFCOUNT                                           0
#define VSATTRINDEX_DATASETOBSERVERCLASS_OBJECTLIST                                                1
#define VSATTRNUMBER_DATASETOBSERVERCLASS                                                          2

/*------Local Define Function */
/*[Public Function] :     */
extern VS_UUID VSFUNCID_DataSetObserverClass_onChanged;
#define VSFUNCRETURNDEPEND_DATASETOBSERVERCLASS_ONCHANGED(X)  {}
#define VSFUNCRETURNDEPENDNUM_DATASETOBSERVERCLASS_ONCHANGED                                       0
#define VSFUNCPARAMDEPEND_DATASETOBSERVERCLASS_ONCHANGED(X)  {}
#define VSFUNCPARAMDEPENDNUM_DATASETOBSERVERCLASS_ONCHANGED                                        0

extern void SRPAPI DataSetObserverClass_onChanged(void *Object);
typedef void (SRPAPI *DataSetObserverClass_onChangedProc)(void *Object);

/*[Public Function] :     */
extern VS_UUID VSFUNCID_DataSetObserverClass_onInvalidated;
#define VSFUNCRETURNDEPEND_DATASETOBSERVERCLASS_ONINVALIDATED(X)  {}
#define VSFUNCRETURNDEPENDNUM_DATASETOBSERVERCLASS_ONINVALIDATED                                   0
#define VSFUNCPARAMDEPEND_DATASETOBSERVERCLASS_ONINVALIDATED(X)  {}
#define VSFUNCPARAMDEPENDNUM_DATASETOBSERVERCLASS_ONINVALIDATED                                    0

extern void SRPAPI DataSetObserverClass_onInvalidated(void *Object);
typedef void (SRPAPI *DataSetObserverClass_onInvalidatedProc)(void *Object);

struct StructOfAttachDataSetObserverClass{
};
struct StructOfDataSetObserverClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_RESOURCECURSORADAPTERCLASS                                                       "ResourceCursorAdapterClass"
extern VS_UUID VSOBJID_ResourceCursorAdapterClass;
#define VSATTRDEPEND_RESOURCECURSORADAPTERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_RESOURCECURSORADAPTERCLASS                                                 2
extern VS_INT32 SRPCALLBACK ResourceCursorAdapterClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_RESOURCECURSORADAPTERCLASS_ANDROIDREFCOUNT                                     0
#define VSATTRINDEX_RESOURCECURSORADAPTERCLASS_OBJECTLIST                                          1
#define VSATTRNUMBER_RESOURCECURSORADAPTERCLASS                                                    2

struct StructOfAttachResourceCursorAdapterClass{
};
struct StructOfResourceCursorAdapterClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_JSRESULTCLASS                                                                    "JsResultClass"
extern VS_UUID VSOBJID_JsResultClass;
#define VSATTRDEPEND_JSRESULTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_JSRESULTCLASS                                                              2
extern VS_INT32 SRPCALLBACK JsResultClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_JSRESULTCLASS_ANDROIDREFCOUNT                                                  0
#define VSATTRINDEX_JSRESULTCLASS_OBJECTLIST                                                       1
#define VSATTRNUMBER_JSRESULTCLASS                                                                 2

struct StructOfAttachJsResultClass{
};
struct StructOfJsResultClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_LOCATIONPROVIDERCLASS                                                            "LocationProviderClass"
extern VS_UUID VSOBJID_LocationProviderClass;
#define VSATTRDEPEND_LOCATIONPROVIDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_LOCATIONPROVIDERCLASS                                                      2
extern VS_INT32 SRPCALLBACK LocationProviderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_LOCATIONPROVIDERCLASS_ANDROIDREFCOUNT                                          0
#define VSATTRINDEX_LOCATIONPROVIDERCLASS_OBJECTLIST                                               1
#define VSATTRNUMBER_LOCATIONPROVIDERCLASS                                                         2

struct StructOfAttachLocationProviderClass{
};
struct StructOfLocationProviderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_DATECLASS                                                                        "DateClass"
extern VS_UUID VSOBJID_DateClass;
#define VSATTRDEPEND_DATECLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_DATECLASS                                                                  2
extern VS_INT32 SRPCALLBACK DateClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_DATECLASS_ANDROIDREFCOUNT                                                      0
#define VSATTRINDEX_DATECLASS_OBJECTLIST                                                           1
#define VSATTRNUMBER_DATECLASS                                                                     2

struct StructOfAttachDateClass{
};
struct StructOfDateClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_IBINDERCLASS                                                                     "IBinderClass"
extern VS_UUID VSOBJID_IBinderClass;
#define VSATTRDEPEND_IBINDERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_IBINDERCLASS                                                               2
extern VS_INT32 SRPCALLBACK IBinderClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_IBINDERCLASS_ANDROIDREFCOUNT                                                   0
#define VSATTRINDEX_IBINDERCLASS_OBJECTLIST                                                        1
#define VSATTRNUMBER_IBINDERCLASS                                                                  2

struct StructOfAttachIBinderClass{
};
struct StructOfIBinderClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_VIEWCONFIGURATIONCLASS                                                           "ViewConfigurationClass"
extern VS_UUID VSOBJID_ViewConfigurationClass;
#define VSATTRDEPEND_VIEWCONFIGURATIONCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_VIEWCONFIGURATIONCLASS                                                     2
extern VS_INT32 SRPCALLBACK ViewConfigurationClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_VIEWCONFIGURATIONCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_VIEWCONFIGURATIONCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_VIEWCONFIGURATIONCLASS                                                        2

struct StructOfAttachViewConfigurationClass{
};
struct StructOfViewConfigurationClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONNECTIVITYMANAGERCLASS                                                         "ConnectivityManagerClass"
extern VS_UUID VSOBJID_ConnectivityManagerClass;
#define VSATTRDEPEND_CONNECTIVITYMANAGERCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONNECTIVITYMANAGERCLASS                                                   2
extern VS_INT32 SRPCALLBACK ConnectivityManagerClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONNECTIVITYMANAGERCLASS_ANDROIDREFCOUNT                                       0
#define VSATTRINDEX_CONNECTIVITYMANAGERCLASS_OBJECTLIST                                            1
#define VSATTRNUMBER_CONNECTIVITYMANAGERCLASS                                                      2

struct StructOfAttachConnectivityManagerClass{
};
struct StructOfConnectivityManagerClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_COMPOSEPATHEFFECTCLASS                                                           "ComposePathEffectClass"
extern VS_UUID VSOBJID_ComposePathEffectClass;
#define VSATTRDEPEND_COMPOSEPATHEFFECTCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_COMPOSEPATHEFFECTCLASS                                                     2
extern VS_INT32 SRPCALLBACK ComposePathEffectClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_COMPOSEPATHEFFECTCLASS_ANDROIDREFCOUNT                                         0
#define VSATTRINDEX_COMPOSEPATHEFFECTCLASS_OBJECTLIST                                              1
#define VSATTRNUMBER_COMPOSEPATHEFFECTCLASS                                                        2

struct StructOfAttachComposePathEffectClass{
};
struct StructOfComposePathEffectClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define VSOBJNAME_CONTENTVALUESCLASS                                                               "ContentValuesClass"
extern VS_UUID VSOBJID_ContentValuesClass;
#define VSATTRDEPEND_CONTENTVALUESCLASS(X)  {{X[0].Type=6;X[0].Offset=0;}{X[1].Type=14;X[1].Offset=4;}}
#define VSATTRDEPENDNUM_CONTENTVALUESCLASS                                                         2
extern VS_INT32 SRPCALLBACK ContentValuesClass_RequestRegisterObject( );

/*------Variable Index Define */
#define VSATTRINDEX_CONTENTVALUESCLASS_ANDROIDREFCOUNT                                             0
#define VSATTRINDEX_CONTENTVALUESCLASS_OBJECTLIST                                                  1
#define VSATTRNUMBER_CONTENTVALUESCLASS                                                            2

struct StructOfAttachContentValuesClass{
};
struct StructOfContentValuesClass{
    //----class[AndroidBaseClass] attribute
    VS_INT32        AndroidRefCount;              //
    void            *ObjectList;                  //
};

/*++++++++++++++++++++++++++++++++++++++++++++++++++*/
//#define VSOBJNAME_BASICSERVICEITEM                                                                 "BasicServiceItem"
//UUID VSOBJID_BasicServiceItem;

#pragma pack()

#endif

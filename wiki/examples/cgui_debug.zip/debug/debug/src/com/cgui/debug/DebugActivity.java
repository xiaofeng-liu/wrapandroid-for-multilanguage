package com.cgui.debug;

import android.app.Activity;
import android.os.Bundle;
import android.os.Debug;

import com.srplab.wrapandroid.*; 

public class DebugActivity extends WrapAndroidActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	DownloadFromNetFlag = false;
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        StarActivity._Call("DoFile","","/data/data/"+getPackageName()+"/lib/libCode.so");
    }
}
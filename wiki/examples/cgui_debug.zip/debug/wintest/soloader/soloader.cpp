#include "SRPWrapAndroidEngine_VSDHeader.h"

static class ClassOfSRPInterface *SRPInterface;
void *RootActivity;

static void *ActivityClass_getCurrent(void *Object){
    return RootActivity;
}

int main(int argc, char* argv[])
{
	class ClassOfBasicSRPInterface *BasicSRPInterface;
	VS_CORESIMPLECONTEXT Context;
	
	BasicSRPInterface = VSCore_InitSimpleEx(&Context,0,0,NULL,0,NULL);
	if( BasicSRPInterface == NULL ){
		printf("init starcore fail\n");
		return -1;
	} 
	{
		FILE *hFile;
		int FileSize;
		char *xmlBufer;
		hFile = fopen("SRPWrapAndroidEngine.xml","rt");
		fseek(hFile,0,SEEK_END);
		FileSize = ftell(hFile);
		fseek(hFile,0,SEEK_SET);
		xmlBufer = (char *)malloc(FileSize+1);
		FileSize = fread(xmlBufer,1,FileSize,hFile);
		fclose(hFile);
		xmlBufer[FileSize] = 0;
		if( BasicSRPInterface ->ImportServiceFromXmlBuf(xmlBufer,false) == VS_FALSE ){
			printf("parse [SRPWrapAndroidEngine.xml] failed\n");
			return -1;
		}
		free(xmlBufer);
	}
	BasicSRPInterface -> CreateService( "","wrapandroid", NULL, "123",5,0,0,0,0,0 );
	SRPInterface = BasicSRPInterface ->GetSRPInterface("wrapandroid","root","123");
	SRPInterface ->CheckPassword(VS_FALSE);

	//---precreate root activity
	void *ActivityClass = SRPInterface -> GetObjectEx(NULL,"ActivityClass");
    void *AtomicActivityClass = SRPInterface ->ObjectToAtomic(ActivityClass);
	void *AtomicActivityClassFunction_getCurrent = SRPInterface ->CreateAtomicFunctionSimple(AtomicActivityClass,"getCurrent","VS_OBJPTR getCurrent();",NULL,NULL,VS_FALSE,VS_FALSE);
	SRPInterface -> SetAtomicFunction(AtomicActivityClassFunction_getCurrent,(void *)ActivityClass_getCurrent);
    
	//alloc root activity
	RootActivity = SRPInterface ->MallocObjectL(&VSOBJID_ActivityClass,0,NULL);
    
	if( SRPInterface ->DoFile("","../libcode.dll",NULL, NULL, VS_FALSE) == VS_FALSE ){
		printf("load library file\n");
		return -1;
	}

	printf("finish,enter message loop..\n");
	while( 1 ){
		VS_INT32 Ch;
		Ch = vs_kbhit();
		if( Ch == 27 )
			break;
		Context.VSControlInterface -> SRPDispatch(VS_FALSE);
	}

	SRPInterface -> Release();
	VSCore_TermSimple(&Context);
	return 0;
}


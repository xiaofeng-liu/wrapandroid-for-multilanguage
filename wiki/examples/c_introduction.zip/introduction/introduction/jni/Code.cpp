#include "SRPWrapAndroidEngine_VSClass.h"

static class ClassOfSRPInterface *SRPInterface;
static void *StarActivity;


static VS_INT32 MyButton_onClick(VS_ULONG FunctionChoice,void *EventPara)
{
	void *toast = SRPInterface->MallocObjectL(&VSOBJID_ToastClass,0,NULL);
	SRPInterface -> ScriptCall(toast,NULL,"makeText","(si)","Button is click", 0);
	SRPInterface -> ScriptCall(toast,NULL,"show","()");
    return 0;
}

static VS_INT32 MyButton1_onClick(VS_ULONG FunctionChoice,void *EventPara)
{
	void *toast = SRPInterface->MallocObjectL(&VSOBJID_ToastClass,0,NULL);
	SRPInterface -> ScriptCall(toast,NULL,"makeText","(si)","Button is click", 0);
	SRPInterface -> ScriptCall(toast,NULL,"show","()");
    return 0;
}

VS_BOOL StarCoreService_Init(class ClassOfStarCore *starcore)
{
	class ClassOfBasicSRPInterface *BasicSRPInterface;
	
	//--init star core
	BasicSRPInterface = starcore ->GetBasicInterface();	
	SRPInterface = BasicSRPInterface ->GetSRPInterface(BasicSRPInterface->QueryActiveService(NULL),"","");
	
	void *ActivityClass;
	ActivityClass = SRPInterface -> GetObjectEx(NULL,"ActivityClass");
	StarActivity = (void *)SRPInterface -> ScriptCall(ActivityClass,NULL,"getCurrent","()O");
	SRPInterface -> Print("Get Main Activity = %s", SRPInterface -> GetName(StarActivity));	

    int widget45 = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/widget45");
    void *MyText = (void *)SRPInterface -> ScriptCall(StarActivity,NULL,"findViewById","(si)o","TextViewClass",widget45);
    SRPInterface -> ScriptCall(MyText,NULL,"setText","(s)","TextViewClass","from layout");

    int widget74 = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/widget74");
    void *MyButton = (void *)SRPInterface -> ScriptCall(StarActivity,NULL,"findViewById","(si)o","ButtonClass",widget74);
    SRPInterface -> ScriptCall(MyButton,NULL,"setText","(s)","click me");
    SRPInterface -> ScriptCall(MyButton,NULL,"setOnClickListener","()");
    SRPInterface -> RegEventFunction(MyButton,&VSOUTEVENTID_ViewClass_onClick,MyButton,(void *)MyButton_onClick,0);
    
    int widget73 = SRPInterface -> ScriptCall(StarActivity,NULL,"getResource","(s)i","id/widget73");
	void *MyLinearLayout = (void *)SRPInterface -> ScriptCall(StarActivity,NULL,"findViewById","(si)o","LinearLayoutClass",widget73);
	
	void *MyDynaButton = SRPInterface->MallocObject(MyLinearLayout,VSATTRINDEX_VIEWGROUPCLASS_VIEWQUEUE,&VSOBJID_ButtonClass,0,NULL);
    SRPInterface -> ScriptCall(MyDynaButton,NULL,"setText","(s)","created dynamically");
    SRPInterface -> ScriptCall(MyDynaButton,NULL,"setOnClickListener","()");
    SRPInterface -> RegEventFunction(MyDynaButton,&VSOUTEVENTID_ViewClass_onClick,MyDynaButton,(void *)MyButton1_onClick,0);
    SRPInterface -> ScriptCall(MyDynaButton,NULL,"setLinearLayoutParams","(ii)",100,50);

	return VS_TRUE;
}

void StarCoreService_Term(class ClassOfStarCore *starcore)
{
	SRPInterface -> Release();
	return;
}
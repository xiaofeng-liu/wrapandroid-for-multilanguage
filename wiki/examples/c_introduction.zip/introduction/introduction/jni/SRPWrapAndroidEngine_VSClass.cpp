/*--------------------------------------------------*/
/*VirtualSociety System ServiceModuleTemplate Class Body File*/
/*CreateBy SRPLab                */
/*CreateDate: 2012-5-29  */
/*--------------------------------------------------*/
#include "SRPWrapAndroidEngine_VSClass.h"
ClassOfRectClass::ClassOfRectClass()
{
}

ClassOfRectClass::ClassOfRectClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RectClass,0,NULL));
}

ClassOfRectClass::ClassOfRectClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRectClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RectClass" );
    return Buf;
}

class ClassOfRectClass *ClassOfRectClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRectClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRectClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RectClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRectClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VS_INT32 ClassOfRectClass::Get_left()
{
    return ((struct StructOfRectClass *)ThisSRPObject) -> left;
}
void ClassOfRectClass::Put_left(VS_INT32 In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTCLASS_LEFT,(VS_INT8 *)&In_Value);
}

VS_INT32 ClassOfRectClass::Get_top()
{
    return ((struct StructOfRectClass *)ThisSRPObject) -> top;
}
void ClassOfRectClass::Put_top(VS_INT32 In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTCLASS_TOP,(VS_INT8 *)&In_Value);
}

VS_INT32 ClassOfRectClass::Get_right()
{
    return ((struct StructOfRectClass *)ThisSRPObject) -> right;
}
void ClassOfRectClass::Put_right(VS_INT32 In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTCLASS_RIGHT,(VS_INT8 *)&In_Value);
}

VS_INT32 ClassOfRectClass::Get_bottom()
{
    return ((struct StructOfRectClass *)ThisSRPObject) -> bottom;
}
void ClassOfRectClass::Put_bottom(VS_INT32 In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTCLASS_BOTTOM,(VS_INT8 *)&In_Value);
}



ClassOfAndroidConstantClass::ClassOfAndroidConstantClass()
{
}

ClassOfAndroidConstantClass::ClassOfAndroidConstantClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AndroidConstantClass,0,NULL));
}

ClassOfAndroidConstantClass::ClassOfAndroidConstantClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAndroidConstantClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AndroidConstantClass" );
    return Buf;
}

class ClassOfAndroidConstantClass *ClassOfAndroidConstantClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAndroidConstantClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAndroidConstantClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AndroidConstantClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAndroidConstantClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAndroidBaseClass::ClassOfAndroidBaseClass()
{
}

ClassOfAndroidBaseClass::ClassOfAndroidBaseClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AndroidBaseClass,0,NULL));
}

ClassOfAndroidBaseClass::ClassOfAndroidBaseClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAndroidBaseClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AndroidBaseClass" );
    return Buf;
}

class ClassOfAndroidBaseClass *ClassOfAndroidBaseClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAndroidBaseClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAndroidBaseClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AndroidBaseClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAndroidBaseClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VS_INT32 ClassOfAndroidBaseClass::Get_AndroidRefCount()
{
    return ((struct StructOfAndroidBaseClass *)ThisSRPObject) -> AndroidRefCount;
}
void ClassOfAndroidBaseClass::Put_AndroidRefCount(VS_INT32 In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_ANDROIDBASECLASS_ANDROIDREFCOUNT,(VS_INT8 *)&In_Value);
}

VSSystemEvent_EventProc ClassOfAndroidBaseClass::Get_E_onSetEventListener()
{
    return NULL;
}
void ClassOfAndroidBaseClass::Put_E_onSetEventListener(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AndroidBaseClass_onSetEventListener,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

void ClassOfAndroidBaseClass::Put_F_onDownPreExecute(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AndroidBaseClass_onDownPreExecute,In_Value,NULL);
}
void * ClassOfAndroidBaseClass::Get_F_onDownPreExecute()
{
    return NULL;
}

void ClassOfAndroidBaseClass::Put_F_onDownProgressUpdate(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AndroidBaseClass_onDownProgressUpdate,In_Value,NULL);
}
void * ClassOfAndroidBaseClass::Get_F_onDownProgressUpdate()
{
    return NULL;
}

void ClassOfAndroidBaseClass::Put_F_onDownPostExecute(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AndroidBaseClass_onDownPostExecute,In_Value,NULL);
}
void * ClassOfAndroidBaseClass::Get_F_onDownPostExecute()
{
    return NULL;
}


void SRPAPI ClassOfAndroidBaseClass::onDownPreExecute(VS_INT32 downloadId,VS_CHAR * url,VS_CHAR * fileName)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDownPreExecute",downloadId,url,fileName);
}
void SRPAPI ClassOfAndroidBaseClass::onDownProgressUpdate(VS_INT32 downloadId,VS_INT32 downloadSize,VS_INT32 maxSize)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDownProgressUpdate",downloadId,downloadSize,maxSize);
}
void SRPAPI ClassOfAndroidBaseClass::onDownPostExecute(VS_INT32 downloadId,VS_INT32 result,VS_INT32 maxDownloadSize,VS_CHAR * fileName,VS_BINBUFPTR binbuf)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDownPostExecute",downloadId,result,maxDownloadSize,fileName,binbuf);
}

ClassOfViewClass::ClassOfViewClass()
{
}

ClassOfViewClass::ClassOfViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewClass,0,NULL));
}

ClassOfViewClass::ClassOfViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewClass" );
    return Buf;
}

class ClassOfViewClass *ClassOfViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfViewClass::Get_E_onClick()
{
    return NULL;
}
void ClassOfViewClass::Put_E_onClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_ViewClass_onClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

void ClassOfViewClass::Put_F_onDraw(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onDraw,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onDraw()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onTouchEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onTouchEvent,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onTouchEvent()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onLayout(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onLayout,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onLayout()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onMeasure(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onMeasure,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onMeasure()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onSizeChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onSizeChanged,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onSizeChanged()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onKeyDown(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onKeyDown,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onKeyDown()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onKeyLongPress(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onKeyLongPress,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onKeyLongPress()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onKeyMultiple(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onKeyMultiple,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onKeyMultiple()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onKeyUp(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onKeyUp,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onKeyUp()
{
    return NULL;
}

void ClassOfViewClass::Put_F_onKey(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewClass_onKey,In_Value,NULL);
}
void * ClassOfViewClass::Get_F_onKey()
{
    return NULL;
}


void SRPAPI ClassOfViewClass::onDraw(VS_OBJPTR canvas)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDraw",canvas);
}
VS_BOOL SRPAPI ClassOfViewClass::onTouchEvent(VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onTouchEvent",event);
}
void SRPAPI ClassOfViewClass::onLayout(VS_BOOL changed,VS_INT32 left,VS_INT32 top,VS_INT32 right,VS_INT32 bottom)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onLayout",changed,left,top,right,bottom);
}
void SRPAPI ClassOfViewClass::onMeasure(VS_INT32 widthMeasureSpec,VS_INT32 heightMeasureSpec)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onMeasure",widthMeasureSpec,heightMeasureSpec);
}
void SRPAPI ClassOfViewClass::onSizeChanged(VS_INT32 w,VS_INT32 h,VS_INT32 oldw,VS_INT32 oldh)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onSizeChanged",w,h,oldw,oldh);
}
VS_BOOL SRPAPI ClassOfViewClass::onKeyDown(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyDown",keyCode,event);
}
VS_BOOL SRPAPI ClassOfViewClass::onKeyLongPress(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyLongPress",keyCode,event);
}
VS_BOOL SRPAPI ClassOfViewClass::onKeyMultiple(VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyMultiple",keyCode,repeatCount,event);
}
VS_BOOL SRPAPI ClassOfViewClass::onKeyUp(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyUp",keyCode,event);
}
void SRPAPI ClassOfViewClass::onKey(VS_INT32 keyCode,VS_OBJPTR event)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onKey",keyCode,event);
}

ClassOfProgressBarClass::ClassOfProgressBarClass()
{
}

ClassOfProgressBarClass::ClassOfProgressBarClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ProgressBarClass,0,NULL));
}

ClassOfProgressBarClass::ClassOfProgressBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfProgressBarClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ProgressBarClass" );
    return Buf;
}

class ClassOfProgressBarClass *ClassOfProgressBarClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfProgressBarClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfProgressBarClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ProgressBarClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfProgressBarClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSurfaceViewClass::ClassOfSurfaceViewClass()
{
}

ClassOfSurfaceViewClass::ClassOfSurfaceViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SurfaceViewClass,0,NULL));
}

ClassOfSurfaceViewClass::ClassOfSurfaceViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSurfaceViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SurfaceViewClass" );
    return Buf;
}

class ClassOfSurfaceViewClass *ClassOfSurfaceViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSurfaceViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSurfaceViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SurfaceViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSurfaceViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfSurfaceViewClass::Put_F_surfaceChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_SurfaceViewClass_surfaceChanged,In_Value,NULL);
}
void * ClassOfSurfaceViewClass::Get_F_surfaceChanged()
{
    return NULL;
}

void ClassOfSurfaceViewClass::Put_F_surfaceCreated(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_SurfaceViewClass_surfaceCreated,In_Value,NULL);
}
void * ClassOfSurfaceViewClass::Get_F_surfaceCreated()
{
    return NULL;
}

void ClassOfSurfaceViewClass::Put_F_surfaceDestroyed(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_SurfaceViewClass_surfaceDestroyed,In_Value,NULL);
}
void * ClassOfSurfaceViewClass::Get_F_surfaceDestroyed()
{
    return NULL;
}


void SRPAPI ClassOfSurfaceViewClass::surfaceChanged(VS_INT32 format,VS_INT32 width,VS_INT32 height)
{
    ThisSRPInterface -> Call(ThisSRPObject,"surfaceChanged",format,width,height);
}
void SRPAPI ClassOfSurfaceViewClass::surfaceCreated()
{
    ThisSRPInterface -> Call(ThisSRPObject,"surfaceCreated");
}
void SRPAPI ClassOfSurfaceViewClass::surfaceDestroyed()
{
    ThisSRPInterface -> Call(ThisSRPObject,"surfaceDestroyed");
}

ClassOfAnalogClockClass::ClassOfAnalogClockClass()
{
}

ClassOfAnalogClockClass::ClassOfAnalogClockClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AnalogClockClass,0,NULL));
}

ClassOfAnalogClockClass::ClassOfAnalogClockClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAnalogClockClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AnalogClockClass" );
    return Buf;
}

class ClassOfAnalogClockClass *ClassOfAnalogClockClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAnalogClockClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAnalogClockClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AnalogClockClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAnalogClockClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfObjectBaseClass::ClassOfObjectBaseClass()
{
}

ClassOfObjectBaseClass::ClassOfObjectBaseClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ObjectBaseClass,0,NULL));
}

ClassOfObjectBaseClass::ClassOfObjectBaseClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfObjectBaseClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ObjectBaseClass" );
    return Buf;
}

class ClassOfObjectBaseClass *ClassOfObjectBaseClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfObjectBaseClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfObjectBaseClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ObjectBaseClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfObjectBaseClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfViewGroup_LayoutParamsClass::ClassOfViewGroup_LayoutParamsClass()
{
}

ClassOfViewGroup_LayoutParamsClass::ClassOfViewGroup_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewGroup_LayoutParamsClass,0,NULL));
}

ClassOfViewGroup_LayoutParamsClass::ClassOfViewGroup_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewGroup_LayoutParamsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewGroup_LayoutParamsClass" );
    return Buf;
}

class ClassOfViewGroup_LayoutParamsClass *ClassOfViewGroup_LayoutParamsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewGroup_LayoutParamsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewGroup_LayoutParamsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewGroup_LayoutParamsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewGroup_LayoutParamsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMenuClass::ClassOfMenuClass()
{
}

ClassOfMenuClass::ClassOfMenuClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MenuClass,0,NULL));
}

ClassOfMenuClass::ClassOfMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMenuClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MenuClass" );
    return Buf;
}

class ClassOfMenuClass *ClassOfMenuClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMenuClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMenuClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MenuClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMenuClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAnimationClass::ClassOfAnimationClass()
{
}

ClassOfAnimationClass::ClassOfAnimationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AnimationClass,0,NULL));
}

ClassOfAnimationClass::ClassOfAnimationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAnimationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AnimationClass" );
    return Buf;
}

class ClassOfAnimationClass *ClassOfAnimationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAnimationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAnimationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AnimationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAnimationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfContactsContract_ContactsClass::ClassOfContactsContract_ContactsClass()
{
}

ClassOfContactsContract_ContactsClass::ClassOfContactsContract_ContactsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContactsContract_ContactsClass,0,NULL));
}

ClassOfContactsContract_ContactsClass::ClassOfContactsContract_ContactsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContactsContract_ContactsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContactsContract_ContactsClass" );
    return Buf;
}

class ClassOfContactsContract_ContactsClass *ClassOfContactsContract_ContactsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContactsContract_ContactsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContactsContract_ContactsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContactsContract_ContactsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContactsContract_ContactsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfPaintClass::ClassOfPaintClass()
{
}

ClassOfPaintClass::ClassOfPaintClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_PaintClass,0,NULL));
}

ClassOfPaintClass::ClassOfPaintClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfPaintClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "PaintClass" );
    return Buf;
}

class ClassOfPaintClass *ClassOfPaintClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfPaintClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfPaintClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "PaintClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfPaintClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfToastClass::ClassOfToastClass()
{
}

ClassOfToastClass::ClassOfToastClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ToastClass,0,NULL));
}

ClassOfToastClass::ClassOfToastClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfToastClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ToastClass" );
    return Buf;
}

class ClassOfToastClass *ClassOfToastClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfToastClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfToastClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ToastClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfToastClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfWindowManager_LayoutParamsClass::ClassOfWindowManager_LayoutParamsClass()
{
}

ClassOfWindowManager_LayoutParamsClass::ClassOfWindowManager_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_WindowManager_LayoutParamsClass,0,NULL));
}

ClassOfWindowManager_LayoutParamsClass::ClassOfWindowManager_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfWindowManager_LayoutParamsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "WindowManager_LayoutParamsClass" );
    return Buf;
}

class ClassOfWindowManager_LayoutParamsClass *ClassOfWindowManager_LayoutParamsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfWindowManager_LayoutParamsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfWindowManager_LayoutParamsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "WindowManager_LayoutParamsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfWindowManager_LayoutParamsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMatrixClass::ClassOfMatrixClass()
{
}

ClassOfMatrixClass::ClassOfMatrixClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MatrixClass,0,NULL));
}

ClassOfMatrixClass::ClassOfMatrixClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMatrixClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MatrixClass" );
    return Buf;
}

class ClassOfMatrixClass *ClassOfMatrixClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMatrixClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMatrixClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MatrixClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMatrixClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfContextMenuClass::ClassOfContextMenuClass()
{
}

ClassOfContextMenuClass::ClassOfContextMenuClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContextMenuClass,0,NULL));
}

ClassOfContextMenuClass::ClassOfContextMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContextMenuClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContextMenuClass" );
    return Buf;
}

class ClassOfContextMenuClass *ClassOfContextMenuClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContextMenuClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContextMenuClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContextMenuClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContextMenuClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfContactsContract_PhoneLookupClass::ClassOfContactsContract_PhoneLookupClass()
{
}

ClassOfContactsContract_PhoneLookupClass::ClassOfContactsContract_PhoneLookupClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContactsContract_PhoneLookupClass,0,NULL));
}

ClassOfContactsContract_PhoneLookupClass::ClassOfContactsContract_PhoneLookupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContactsContract_PhoneLookupClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContactsContract_PhoneLookupClass" );
    return Buf;
}

class ClassOfContactsContract_PhoneLookupClass *ClassOfContactsContract_PhoneLookupClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContactsContract_PhoneLookupClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContactsContract_PhoneLookupClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContactsContract_PhoneLookupClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContactsContract_PhoneLookupClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMenuItemClass::ClassOfMenuItemClass()
{
}

ClassOfMenuItemClass::ClassOfMenuItemClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MenuItemClass,0,NULL));
}

ClassOfMenuItemClass::ClassOfMenuItemClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMenuItemClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MenuItemClass" );
    return Buf;
}

class ClassOfMenuItemClass *ClassOfMenuItemClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMenuItemClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMenuItemClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MenuItemClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMenuItemClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfIntentFilterClass::ClassOfIntentFilterClass()
{
}

ClassOfIntentFilterClass::ClassOfIntentFilterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_IntentFilterClass,0,NULL));
}

ClassOfIntentFilterClass::ClassOfIntentFilterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfIntentFilterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "IntentFilterClass" );
    return Buf;
}

class ClassOfIntentFilterClass *ClassOfIntentFilterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfIntentFilterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfIntentFilterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "IntentFilterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfIntentFilterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfShapeClass::ClassOfShapeClass()
{
}

ClassOfShapeClass::ClassOfShapeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ShapeClass,0,NULL));
}

ClassOfShapeClass::ClassOfShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfShapeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ShapeClass" );
    return Buf;
}

class ClassOfShapeClass *ClassOfShapeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfShapeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfShapeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ShapeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfShapeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfGestureDetectorClass::ClassOfGestureDetectorClass()
{
}

ClassOfGestureDetectorClass::ClassOfGestureDetectorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_GestureDetectorClass,0,NULL));
}

ClassOfGestureDetectorClass::ClassOfGestureDetectorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfGestureDetectorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "GestureDetectorClass" );
    return Buf;
}

class ClassOfGestureDetectorClass *ClassOfGestureDetectorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfGestureDetectorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfGestureDetectorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "GestureDetectorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfGestureDetectorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onDown()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onDown(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onDown,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onFling()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onFling(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onFling,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onLongPress()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onLongPress(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onLongPress,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onScroll()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onScroll(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onScroll,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onShowPress()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onShowPress(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onShowPress,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onSingleTapUp()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onSingleTapUp(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onSingleTapUp,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onDoubleTap()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onDoubleTap(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onDoubleTap,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onDoubleTapEvent()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onDoubleTapEvent(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onDoubleTapEvent,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfGestureDetectorClass::Get_E_onSingleTapConfirmed()
{
    return NULL;
}
void ClassOfGestureDetectorClass::Put_E_onSingleTapConfirmed(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_GestureDetectorClass_onSingleTapConfirmed,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfInputStreamClass::ClassOfInputStreamClass()
{
}

ClassOfInputStreamClass::ClassOfInputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_InputStreamClass,0,NULL));
}

ClassOfInputStreamClass::ClassOfInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfInputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "InputStreamClass" );
    return Buf;
}

class ClassOfInputStreamClass *ClassOfInputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfInputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfInputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "InputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfInputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCommonDataKinds_PhoneClass::ClassOfCommonDataKinds_PhoneClass()
{
}

ClassOfCommonDataKinds_PhoneClass::ClassOfCommonDataKinds_PhoneClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CommonDataKinds_PhoneClass,0,NULL));
}

ClassOfCommonDataKinds_PhoneClass::ClassOfCommonDataKinds_PhoneClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCommonDataKinds_PhoneClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CommonDataKinds_PhoneClass" );
    return Buf;
}

class ClassOfCommonDataKinds_PhoneClass *ClassOfCommonDataKinds_PhoneClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCommonDataKinds_PhoneClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCommonDataKinds_PhoneClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CommonDataKinds_PhoneClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCommonDataKinds_PhoneClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTypefaceClass::ClassOfTypefaceClass()
{
}

ClassOfTypefaceClass::ClassOfTypefaceClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TypefaceClass,0,NULL));
}

ClassOfTypefaceClass::ClassOfTypefaceClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTypefaceClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TypefaceClass" );
    return Buf;
}

class ClassOfTypefaceClass *ClassOfTypefaceClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTypefaceClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTypefaceClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TypefaceClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTypefaceClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfNotificationManagerClass::ClassOfNotificationManagerClass()
{
}

ClassOfNotificationManagerClass::ClassOfNotificationManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_NotificationManagerClass,0,NULL));
}

ClassOfNotificationManagerClass::ClassOfNotificationManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfNotificationManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "NotificationManagerClass" );
    return Buf;
}

class ClassOfNotificationManagerClass *ClassOfNotificationManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfNotificationManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfNotificationManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "NotificationManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfNotificationManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAssetManagerClass::ClassOfAssetManagerClass()
{
}

ClassOfAssetManagerClass::ClassOfAssetManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AssetManagerClass,0,NULL));
}

ClassOfAssetManagerClass::ClassOfAssetManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAssetManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AssetManagerClass" );
    return Buf;
}

class ClassOfAssetManagerClass *ClassOfAssetManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAssetManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAssetManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AssetManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAssetManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfConfigurationClass::ClassOfConfigurationClass()
{
}

ClassOfConfigurationClass::ClassOfConfigurationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ConfigurationClass,0,NULL));
}

ClassOfConfigurationClass::ClassOfConfigurationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfConfigurationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ConfigurationClass" );
    return Buf;
}

class ClassOfConfigurationClass *ClassOfConfigurationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfConfigurationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfConfigurationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ConfigurationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfConfigurationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAlertDialog_BuilderClass::ClassOfAlertDialog_BuilderClass()
{
}

ClassOfAlertDialog_BuilderClass::ClassOfAlertDialog_BuilderClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AlertDialog_BuilderClass,0,NULL));
}

ClassOfAlertDialog_BuilderClass::ClassOfAlertDialog_BuilderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAlertDialog_BuilderClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AlertDialog_BuilderClass" );
    return Buf;
}

class ClassOfAlertDialog_BuilderClass *ClassOfAlertDialog_BuilderClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAlertDialog_BuilderClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAlertDialog_BuilderClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AlertDialog_BuilderClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAlertDialog_BuilderClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onKey()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onKey(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onKey,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onCancel()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onCancel(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onCancel,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onMultiChoiceClick()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onMultiChoiceClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onMultiChoiceClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onDismiss()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onDismiss(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onDismiss,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onShow()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onShow(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onShow,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialog_BuilderClass::Get_E_onClick()
{
    return NULL;
}
void ClassOfAlertDialog_BuilderClass::Put_E_onClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialog_BuilderClass_onClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfShaderClass::ClassOfShaderClass()
{
}

ClassOfShaderClass::ClassOfShaderClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ShaderClass,0,NULL));
}

ClassOfShaderClass::ClassOfShaderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfShaderClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ShaderClass" );
    return Buf;
}

class ClassOfShaderClass *ClassOfShaderClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfShaderClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfShaderClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ShaderClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfShaderClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfActivityClass::ClassOfActivityClass()
{
}

ClassOfActivityClass::ClassOfActivityClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ActivityClass,0,NULL));
}

ClassOfActivityClass::ClassOfActivityClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfActivityClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ActivityClass" );
    return Buf;
}

class ClassOfActivityClass *ClassOfActivityClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfActivityClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfActivityClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ActivityClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfActivityClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfActivityClass::Put_F_onStart(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onStart,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onStart()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onRestart(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onRestart,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onRestart()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onStop(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onStop,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onStop()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onSaveInstanceState(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onSaveInstanceState,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onSaveInstanceState()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onRestoreInstanceState(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onRestoreInstanceState,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onRestoreInstanceState()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onPause(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onPause,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onPause()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onResume(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onResume,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onResume()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onDestroy(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onDestroy,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onDestroy()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onCreateDialog(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onCreateDialog,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onCreateDialog()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onCreateDialog1(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onCreateDialog1,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onCreateDialog1()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onPrepareDialog(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onPrepareDialog,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onPrepareDialog()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onPrepareDialog1(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onPrepareDialog1,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onPrepareDialog1()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onActivityResult(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onActivityResult,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onActivityResult()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onTouchEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onTouchEvent,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onTouchEvent()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onCreateOptionsMenu(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onCreateOptionsMenu,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onCreateOptionsMenu()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onPrepareOptionsMenu(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onPrepareOptionsMenu,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onPrepareOptionsMenu()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onOptionsItemSelected(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onOptionsItemSelected,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onOptionsItemSelected()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onCreateContextMenu(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onCreateContextMenu,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onCreateContextMenu()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onContextItemSelected(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onContextItemSelected,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onContextItemSelected()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onKeyDown(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onKeyDown,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onKeyDown()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onKeyLongPress(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onKeyLongPress,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onKeyLongPress()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onKeyMultiple(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onKeyMultiple,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onKeyMultiple()
{
    return NULL;
}

void ClassOfActivityClass::Put_F_onKeyUp(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ActivityClass_onKeyUp,In_Value,NULL);
}
void * ClassOfActivityClass::Get_F_onKeyUp()
{
    return NULL;
}


void SRPAPI ClassOfActivityClass::onStart()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onStart");
}
void SRPAPI ClassOfActivityClass::onRestart()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onRestart");
}
void SRPAPI ClassOfActivityClass::onStop()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onStop");
}
void SRPAPI ClassOfActivityClass::onSaveInstanceState(VS_OBJPTR savedInstanceState)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onSaveInstanceState",savedInstanceState);
}
void SRPAPI ClassOfActivityClass::onRestoreInstanceState(VS_OBJPTR savedInstanceState)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onRestoreInstanceState",savedInstanceState);
}
void SRPAPI ClassOfActivityClass::onPause()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onPause");
}
void SRPAPI ClassOfActivityClass::onResume()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onResume");
}
void SRPAPI ClassOfActivityClass::onDestroy()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDestroy");
}
VS_OBJPTR SRPAPI ClassOfActivityClass::onCreateDialog(VS_INT32 id)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"onCreateDialog",id);
}
VS_OBJPTR SRPAPI ClassOfActivityClass::onCreateDialog1(VS_INT32 id,VS_OBJPTR args)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"onCreateDialog1",id,args);
}
VS_BOOL SRPAPI ClassOfActivityClass::onPrepareDialog(VS_INT32 id,VS_OBJPTR dialog)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onPrepareDialog",id,dialog);
}
VS_BOOL SRPAPI ClassOfActivityClass::onPrepareDialog1(VS_INT32 id,VS_OBJPTR dialog,VS_OBJPTR args)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onPrepareDialog1",id,dialog,args);
}
void SRPAPI ClassOfActivityClass::onActivityResult(VS_INT32 requestCode,VS_INT32 resultCode,VS_OBJPTR data)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onActivityResult",requestCode,resultCode,data);
}
VS_BOOL SRPAPI ClassOfActivityClass::onTouchEvent(VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onTouchEvent",event);
}
VS_BOOL SRPAPI ClassOfActivityClass::onCreateOptionsMenu(VS_OBJPTR menu)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onCreateOptionsMenu",menu);
}
VS_BOOL SRPAPI ClassOfActivityClass::onPrepareOptionsMenu(VS_OBJPTR menu)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onPrepareOptionsMenu",menu);
}
VS_BOOL SRPAPI ClassOfActivityClass::onOptionsItemSelected(VS_OBJPTR item)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onOptionsItemSelected",item);
}
void SRPAPI ClassOfActivityClass::onCreateContextMenu(VS_OBJPTR menu,VS_OBJPTR v)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onCreateContextMenu",menu,v);
}
void SRPAPI ClassOfActivityClass::onContextItemSelected(VS_OBJPTR item)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onContextItemSelected",item);
}
VS_BOOL SRPAPI ClassOfActivityClass::onKeyDown(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyDown",keyCode,event);
}
VS_BOOL SRPAPI ClassOfActivityClass::onKeyLongPress(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyLongPress",keyCode,event);
}
VS_BOOL SRPAPI ClassOfActivityClass::onKeyMultiple(VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyMultiple",keyCode,repeatCount,event);
}
VS_BOOL SRPAPI ClassOfActivityClass::onKeyUp(VS_INT32 keyCode,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onKeyUp",keyCode,event);
}

ClassOfListActivityClass::ClassOfListActivityClass()
{
}

ClassOfListActivityClass::ClassOfListActivityClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ListActivityClass,0,NULL));
}

ClassOfListActivityClass::ClassOfListActivityClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfListActivityClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ListActivityClass" );
    return Buf;
}

class ClassOfListActivityClass *ClassOfListActivityClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfListActivityClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfListActivityClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ListActivityClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfListActivityClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfListActivityClass::Put_F_onListItemClick(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ListActivityClass_onListItemClick,In_Value,NULL);
}
void * ClassOfListActivityClass::Get_F_onListItemClick()
{
    return NULL;
}


VS_BOOL SRPAPI ClassOfListActivityClass::onListItemClick(VS_OBJPTR l,VS_OBJPTR v,VS_INT32 position,VS_LONG id)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onListItemClick",l,v,position,id);
}

ClassOfXmlPullParserClass::ClassOfXmlPullParserClass()
{
}

ClassOfXmlPullParserClass::ClassOfXmlPullParserClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_XmlPullParserClass,0,NULL));
}

ClassOfXmlPullParserClass::ClassOfXmlPullParserClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfXmlPullParserClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "XmlPullParserClass" );
    return Buf;
}

class ClassOfXmlPullParserClass *ClassOfXmlPullParserClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfXmlPullParserClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfXmlPullParserClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "XmlPullParserClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfXmlPullParserClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfXmlResourceParserClass::ClassOfXmlResourceParserClass()
{
}

ClassOfXmlResourceParserClass::ClassOfXmlResourceParserClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_XmlResourceParserClass,0,NULL));
}

ClassOfXmlResourceParserClass::ClassOfXmlResourceParserClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfXmlResourceParserClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "XmlResourceParserClass" );
    return Buf;
}

class ClassOfXmlResourceParserClass *ClassOfXmlResourceParserClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfXmlResourceParserClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfXmlResourceParserClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "XmlResourceParserClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfXmlResourceParserClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfIntentClass::ClassOfIntentClass()
{
}

ClassOfIntentClass::ClassOfIntentClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_IntentClass,0,NULL));
}

ClassOfIntentClass::ClassOfIntentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfIntentClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "IntentClass" );
    return Buf;
}

class ClassOfIntentClass *ClassOfIntentClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfIntentClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfIntentClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "IntentClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfIntentClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfNetworkInfoClass::ClassOfNetworkInfoClass()
{
}

ClassOfNetworkInfoClass::ClassOfNetworkInfoClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_NetworkInfoClass,0,NULL));
}

ClassOfNetworkInfoClass::ClassOfNetworkInfoClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfNetworkInfoClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "NetworkInfoClass" );
    return Buf;
}

class ClassOfNetworkInfoClass *ClassOfNetworkInfoClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfNetworkInfoClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfNetworkInfoClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "NetworkInfoClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfNetworkInfoClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfInputEventClass::ClassOfInputEventClass()
{
}

ClassOfInputEventClass::ClassOfInputEventClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_InputEventClass,0,NULL));
}

ClassOfInputEventClass::ClassOfInputEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfInputEventClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "InputEventClass" );
    return Buf;
}

class ClassOfInputEventClass *ClassOfInputEventClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfInputEventClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfInputEventClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "InputEventClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfInputEventClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAdapterClass::ClassOfAdapterClass()
{
}

ClassOfAdapterClass::ClassOfAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AdapterClass,0,NULL));
}

ClassOfAdapterClass::ClassOfAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AdapterClass" );
    return Buf;
}

class ClassOfAdapterClass *ClassOfAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfAdapterClass::Put_F_getCount(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getCount,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getCount()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_getItem(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getItem,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getItem()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_getItemId(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getItemId,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getItemId()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_getViewTypeCount(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getViewTypeCount,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getViewTypeCount()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_getItemViewType(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getItemViewType,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getItemViewType()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_getView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_getView,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_getView()
{
    return NULL;
}

void ClassOfAdapterClass::Put_F_isEmpty(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_AdapterClass_isEmpty,In_Value,NULL);
}
void * ClassOfAdapterClass::Get_F_isEmpty()
{
    return NULL;
}


VS_INT32 SRPAPI ClassOfAdapterClass::getCount()
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getCount");
}
VS_INT32 SRPAPI ClassOfAdapterClass::getItem(VS_INT32 position)
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getItem",position);
}
VS_LONG SRPAPI ClassOfAdapterClass::getItemId(VS_INT32 position)
{
    return (VS_LONG )ThisSRPInterface -> Call(ThisSRPObject,"getItemId",position);
}
VS_INT32 SRPAPI ClassOfAdapterClass::getViewTypeCount()
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getViewTypeCount");
}
VS_INT32 SRPAPI ClassOfAdapterClass::getItemViewType(VS_INT32 position)
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getItemViewType",position);
}
VS_OBJPTR SRPAPI ClassOfAdapterClass::getView(VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"getView",position,convertView,parent);
}
VS_BOOL SRPAPI ClassOfAdapterClass::isEmpty()
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"isEmpty");
}

ClassOfTabSpecClass::ClassOfTabSpecClass()
{
}

ClassOfTabSpecClass::ClassOfTabSpecClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TabSpecClass,0,NULL));
}

ClassOfTabSpecClass::ClassOfTabSpecClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTabSpecClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TabSpecClass" );
    return Buf;
}

class ClassOfTabSpecClass *ClassOfTabSpecClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTabSpecClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTabSpecClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TabSpecClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTabSpecClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfBitmapShaderClass::ClassOfBitmapShaderClass()
{
}

ClassOfBitmapShaderClass::ClassOfBitmapShaderClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BitmapShaderClass,0,NULL));
}

ClassOfBitmapShaderClass::ClassOfBitmapShaderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBitmapShaderClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BitmapShaderClass" );
    return Buf;
}

class ClassOfBitmapShaderClass *ClassOfBitmapShaderClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBitmapShaderClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBitmapShaderClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BitmapShaderClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBitmapShaderClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfBroadcastReceiverClass::ClassOfBroadcastReceiverClass()
{
}

ClassOfBroadcastReceiverClass::ClassOfBroadcastReceiverClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BroadcastReceiverClass,0,NULL));
}

ClassOfBroadcastReceiverClass::ClassOfBroadcastReceiverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBroadcastReceiverClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BroadcastReceiverClass" );
    return Buf;
}

class ClassOfBroadcastReceiverClass *ClassOfBroadcastReceiverClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBroadcastReceiverClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBroadcastReceiverClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BroadcastReceiverClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBroadcastReceiverClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfBroadcastReceiverClass::Put_F_onReceive(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BroadcastReceiverClass_onReceive,In_Value,NULL);
}
void * ClassOfBroadcastReceiverClass::Get_F_onReceive()
{
    return NULL;
}


void SRPAPI ClassOfBroadcastReceiverClass::onReceive(VS_OBJPTR intent)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onReceive",intent);
}

ClassOfFileDescriptorClass::ClassOfFileDescriptorClass()
{
}

ClassOfFileDescriptorClass::ClassOfFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_FileDescriptorClass,0,NULL));
}

ClassOfFileDescriptorClass::ClassOfFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfFileDescriptorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "FileDescriptorClass" );
    return Buf;
}

class ClassOfFileDescriptorClass *ClassOfFileDescriptorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfFileDescriptorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfFileDescriptorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "FileDescriptorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfFileDescriptorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRemoteViewsClass::ClassOfRemoteViewsClass()
{
}

ClassOfRemoteViewsClass::ClassOfRemoteViewsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RemoteViewsClass,0,NULL));
}

ClassOfRemoteViewsClass::ClassOfRemoteViewsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRemoteViewsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RemoteViewsClass" );
    return Buf;
}

class ClassOfRemoteViewsClass *ClassOfRemoteViewsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRemoteViewsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRemoteViewsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RemoteViewsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRemoteViewsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTabContentFactoryClass::ClassOfTabContentFactoryClass()
{
}

ClassOfTabContentFactoryClass::ClassOfTabContentFactoryClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TabContentFactoryClass,0,NULL));
}

ClassOfTabContentFactoryClass::ClassOfTabContentFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTabContentFactoryClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TabContentFactoryClass" );
    return Buf;
}

class ClassOfTabContentFactoryClass *ClassOfTabContentFactoryClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTabContentFactoryClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTabContentFactoryClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TabContentFactoryClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTabContentFactoryClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfTabContentFactoryClass::Put_F_createTabContent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_TabContentFactoryClass_createTabContent,In_Value,NULL);
}
void * ClassOfTabContentFactoryClass::Get_F_createTabContent()
{
    return NULL;
}


VS_OBJPTR SRPAPI ClassOfTabContentFactoryClass::createTabContent(VS_CHAR * tag)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"createTabContent",tag);
}

ClassOfBitmapClass::ClassOfBitmapClass()
{
}

ClassOfBitmapClass::ClassOfBitmapClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BitmapClass,0,NULL));
}

ClassOfBitmapClass::ClassOfBitmapClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBitmapClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BitmapClass" );
    return Buf;
}

class ClassOfBitmapClass *ClassOfBitmapClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBitmapClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBitmapClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BitmapClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBitmapClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSensorEventClass::ClassOfSensorEventClass()
{
}

ClassOfSensorEventClass::ClassOfSensorEventClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SensorEventClass,0,NULL));
}

ClassOfSensorEventClass::ClassOfSensorEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSensorEventClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SensorEventClass" );
    return Buf;
}

class ClassOfSensorEventClass *ClassOfSensorEventClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSensorEventClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSensorEventClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SensorEventClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSensorEventClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCellLocationClass::ClassOfCellLocationClass()
{
}

ClassOfCellLocationClass::ClassOfCellLocationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CellLocationClass,0,NULL));
}

ClassOfCellLocationClass::ClassOfCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCellLocationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CellLocationClass" );
    return Buf;
}

class ClassOfCellLocationClass *ClassOfCellLocationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCellLocationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCellLocationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CellLocationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCellLocationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfGsmCellLocationClass::ClassOfGsmCellLocationClass()
{
}

ClassOfGsmCellLocationClass::ClassOfGsmCellLocationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_GsmCellLocationClass,0,NULL));
}

ClassOfGsmCellLocationClass::ClassOfGsmCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfGsmCellLocationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "GsmCellLocationClass" );
    return Buf;
}

class ClassOfGsmCellLocationClass *ClassOfGsmCellLocationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfGsmCellLocationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfGsmCellLocationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "GsmCellLocationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfGsmCellLocationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfFileClass::ClassOfFileClass()
{
}

ClassOfFileClass::ClassOfFileClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_FileClass,0,NULL));
}

ClassOfFileClass::ClassOfFileClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfFileClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "FileClass" );
    return Buf;
}

class ClassOfFileClass *ClassOfFileClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfFileClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfFileClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "FileClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfFileClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMediaRecorderClass::ClassOfMediaRecorderClass()
{
}

ClassOfMediaRecorderClass::ClassOfMediaRecorderClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MediaRecorderClass,0,NULL));
}

ClassOfMediaRecorderClass::ClassOfMediaRecorderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMediaRecorderClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MediaRecorderClass" );
    return Buf;
}

class ClassOfMediaRecorderClass *ClassOfMediaRecorderClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMediaRecorderClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMediaRecorderClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MediaRecorderClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMediaRecorderClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfMediaRecorderClass::Get_E_onError()
{
    return NULL;
}
void ClassOfMediaRecorderClass::Put_E_onError(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaRecorderClass_onError,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaRecorderClass::Get_E_onInfo()
{
    return NULL;
}
void ClassOfMediaRecorderClass::Put_E_onInfo(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaRecorderClass_onInfo,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfDialogClass::ClassOfDialogClass()
{
}

ClassOfDialogClass::ClassOfDialogClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DialogClass,0,NULL));
}

ClassOfDialogClass::ClassOfDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDialogClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DialogClass" );
    return Buf;
}

class ClassOfDialogClass *ClassOfDialogClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDialogClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDialogClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DialogClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDialogClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfDialogClass::Get_E_onKey()
{
    return NULL;
}
void ClassOfDialogClass::Put_E_onKey(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DialogClass_onKey,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfDialogClass::Get_E_onCancel()
{
    return NULL;
}
void ClassOfDialogClass::Put_E_onCancel(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DialogClass_onCancel,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfDialogClass::Get_E_onDismiss()
{
    return NULL;
}
void ClassOfDialogClass::Put_E_onDismiss(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DialogClass_onDismiss,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfDialogClass::Get_E_onShow()
{
    return NULL;
}
void ClassOfDialogClass::Put_E_onShow(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DialogClass_onShow,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfAlertDialogClass::ClassOfAlertDialogClass()
{
}

ClassOfAlertDialogClass::ClassOfAlertDialogClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AlertDialogClass,0,NULL));
}

ClassOfAlertDialogClass::ClassOfAlertDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAlertDialogClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AlertDialogClass" );
    return Buf;
}

class ClassOfAlertDialogClass *ClassOfAlertDialogClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAlertDialogClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAlertDialogClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AlertDialogClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAlertDialogClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfAlertDialogClass::Get_E_onMultiChoiceClick()
{
    return NULL;
}
void ClassOfAlertDialogClass::Put_E_onMultiChoiceClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialogClass_onMultiChoiceClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAlertDialogClass::Get_E_onClick()
{
    return NULL;
}
void ClassOfAlertDialogClass::Put_E_onClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AlertDialogClass_onClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfProgressDialogClass::ClassOfProgressDialogClass()
{
}

ClassOfProgressDialogClass::ClassOfProgressDialogClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ProgressDialogClass,0,NULL));
}

ClassOfProgressDialogClass::ClassOfProgressDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfProgressDialogClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ProgressDialogClass" );
    return Buf;
}

class ClassOfProgressDialogClass *ClassOfProgressDialogClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfProgressDialogClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfProgressDialogClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ProgressDialogClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfProgressDialogClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRectFClass::ClassOfRectFClass()
{
}

ClassOfRectFClass::ClassOfRectFClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RectFClass,0,NULL));
}

ClassOfRectFClass::ClassOfRectFClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRectFClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RectFClass" );
    return Buf;
}

class ClassOfRectFClass *ClassOfRectFClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRectFClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRectFClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RectFClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRectFClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VS_FLOAT ClassOfRectFClass::Get_left()
{
    return ((struct StructOfRectFClass *)ThisSRPObject) -> left;
}
void ClassOfRectFClass::Put_left(VS_FLOAT In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTFCLASS_LEFT,(VS_INT8 *)&In_Value);
}

VS_FLOAT ClassOfRectFClass::Get_top()
{
    return ((struct StructOfRectFClass *)ThisSRPObject) -> top;
}
void ClassOfRectFClass::Put_top(VS_FLOAT In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTFCLASS_TOP,(VS_INT8 *)&In_Value);
}

VS_FLOAT ClassOfRectFClass::Get_right()
{
    return ((struct StructOfRectFClass *)ThisSRPObject) -> right;
}
void ClassOfRectFClass::Put_right(VS_FLOAT In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTFCLASS_RIGHT,(VS_INT8 *)&In_Value);
}

VS_FLOAT ClassOfRectFClass::Get_bottom()
{
    return ((struct StructOfRectFClass *)ThisSRPObject) -> bottom;
}
void ClassOfRectFClass::Put_bottom(VS_FLOAT In_Value)
{
    ThisSRPInterface -> ChangeObject(ThisSRPObject,VSATTRINDEX_RECTFCLASS_BOTTOM,(VS_INT8 *)&In_Value);
}



ClassOfSubMenuClass::ClassOfSubMenuClass()
{
}

ClassOfSubMenuClass::ClassOfSubMenuClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SubMenuClass,0,NULL));
}

ClassOfSubMenuClass::ClassOfSubMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSubMenuClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SubMenuClass" );
    return Buf;
}

class ClassOfSubMenuClass *ClassOfSubMenuClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSubMenuClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSubMenuClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SubMenuClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSubMenuClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfVibratorClass::ClassOfVibratorClass()
{
}

ClassOfVibratorClass::ClassOfVibratorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_VibratorClass,0,NULL));
}

ClassOfVibratorClass::ClassOfVibratorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfVibratorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "VibratorClass" );
    return Buf;
}

class ClassOfVibratorClass *ClassOfVibratorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfVibratorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfVibratorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "VibratorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfVibratorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfPathClass::ClassOfPathClass()
{
}

ClassOfPathClass::ClassOfPathClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_PathClass,0,NULL));
}

ClassOfPathClass::ClassOfPathClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfPathClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "PathClass" );
    return Buf;
}

class ClassOfPathClass *ClassOfPathClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfPathClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfPathClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "PathClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfPathClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfContentObserverClass::ClassOfContentObserverClass()
{
}

ClassOfContentObserverClass::ClassOfContentObserverClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContentObserverClass,0,NULL));
}

ClassOfContentObserverClass::ClassOfContentObserverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContentObserverClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContentObserverClass" );
    return Buf;
}

class ClassOfContentObserverClass *ClassOfContentObserverClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContentObserverClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContentObserverClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContentObserverClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContentObserverClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfContentObserverClass::Put_F_deliverSelfNotifications(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ContentObserverClass_deliverSelfNotifications,In_Value,NULL);
}
void * ClassOfContentObserverClass::Get_F_deliverSelfNotifications()
{
    return NULL;
}

void ClassOfContentObserverClass::Put_F_onChange(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ContentObserverClass_onChange,In_Value,NULL);
}
void * ClassOfContentObserverClass::Get_F_onChange()
{
    return NULL;
}


VS_BOOL SRPAPI ClassOfContentObserverClass::deliverSelfNotifications()
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"deliverSelfNotifications");
}
void SRPAPI ClassOfContentObserverClass::onChange(VS_BOOL selfChange)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onChange",selfChange);
}

ClassOfBitmapFactoryClass::ClassOfBitmapFactoryClass()
{
}

ClassOfBitmapFactoryClass::ClassOfBitmapFactoryClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BitmapFactoryClass,0,NULL));
}

ClassOfBitmapFactoryClass::ClassOfBitmapFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBitmapFactoryClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BitmapFactoryClass" );
    return Buf;
}

class ClassOfBitmapFactoryClass *ClassOfBitmapFactoryClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBitmapFactoryClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBitmapFactoryClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BitmapFactoryClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBitmapFactoryClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTextViewClass::ClassOfTextViewClass()
{
}

ClassOfTextViewClass::ClassOfTextViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TextViewClass,0,NULL));
}

ClassOfTextViewClass::ClassOfTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTextViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TextViewClass" );
    return Buf;
}

class ClassOfTextViewClass *ClassOfTextViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTextViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTextViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TextViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTextViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfTextViewClass::Get_E_onTextChanged()
{
    return NULL;
}
void ClassOfTextViewClass::Put_E_onTextChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TextViewClass_onTextChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTextViewClass::Get_E_beforeTextChanged()
{
    return NULL;
}
void ClassOfTextViewClass::Put_E_beforeTextChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TextViewClass_beforeTextChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTextViewClass::Get_E_afterTextChanged()
{
    return NULL;
}
void ClassOfTextViewClass::Put_E_afterTextChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TextViewClass_afterTextChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfDigitalClockClass::ClassOfDigitalClockClass()
{
}

ClassOfDigitalClockClass::ClassOfDigitalClockClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DigitalClockClass,0,NULL));
}

ClassOfDigitalClockClass::ClassOfDigitalClockClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDigitalClockClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DigitalClockClass" );
    return Buf;
}

class ClassOfDigitalClockClass *ClassOfDigitalClockClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDigitalClockClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDigitalClockClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DigitalClockClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDigitalClockClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfEditTextClass::ClassOfEditTextClass()
{
}

ClassOfEditTextClass::ClassOfEditTextClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_EditTextClass,0,NULL));
}

ClassOfEditTextClass::ClassOfEditTextClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfEditTextClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "EditTextClass" );
    return Buf;
}

class ClassOfEditTextClass *ClassOfEditTextClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfEditTextClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfEditTextClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "EditTextClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfEditTextClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAutoCompleteTextViewClass::ClassOfAutoCompleteTextViewClass()
{
}

ClassOfAutoCompleteTextViewClass::ClassOfAutoCompleteTextViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AutoCompleteTextViewClass,0,NULL));
}

ClassOfAutoCompleteTextViewClass::ClassOfAutoCompleteTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAutoCompleteTextViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AutoCompleteTextViewClass" );
    return Buf;
}

class ClassOfAutoCompleteTextViewClass *ClassOfAutoCompleteTextViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAutoCompleteTextViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAutoCompleteTextViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AutoCompleteTextViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAutoCompleteTextViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfUriClass::ClassOfUriClass()
{
}

ClassOfUriClass::ClassOfUriClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_UriClass,0,NULL));
}

ClassOfUriClass::ClassOfUriClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfUriClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "UriClass" );
    return Buf;
}

class ClassOfUriClass *ClassOfUriClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfUriClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfUriClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "UriClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfUriClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfOutputStreamClass::ClassOfOutputStreamClass()
{
}

ClassOfOutputStreamClass::ClassOfOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_OutputStreamClass,0,NULL));
}

ClassOfOutputStreamClass::ClassOfOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfOutputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "OutputStreamClass" );
    return Buf;
}

class ClassOfOutputStreamClass *ClassOfOutputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfOutputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfOutputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "OutputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfOutputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfFileOutputStreamClass::ClassOfFileOutputStreamClass()
{
}

ClassOfFileOutputStreamClass::ClassOfFileOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_FileOutputStreamClass,0,NULL));
}

ClassOfFileOutputStreamClass::ClassOfFileOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfFileOutputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "FileOutputStreamClass" );
    return Buf;
}

class ClassOfFileOutputStreamClass *ClassOfFileOutputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfFileOutputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfFileOutputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "FileOutputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfFileOutputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfKeyEventClass::ClassOfKeyEventClass()
{
}

ClassOfKeyEventClass::ClassOfKeyEventClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_KeyEventClass,0,NULL));
}

ClassOfKeyEventClass::ClassOfKeyEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfKeyEventClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "KeyEventClass" );
    return Buf;
}

class ClassOfKeyEventClass *ClassOfKeyEventClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfKeyEventClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfKeyEventClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "KeyEventClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfKeyEventClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTimePickerDialogClass::ClassOfTimePickerDialogClass()
{
}

ClassOfTimePickerDialogClass::ClassOfTimePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TimePickerDialogClass,0,NULL));
}

ClassOfTimePickerDialogClass::ClassOfTimePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTimePickerDialogClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TimePickerDialogClass" );
    return Buf;
}

class ClassOfTimePickerDialogClass *ClassOfTimePickerDialogClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTimePickerDialogClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTimePickerDialogClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TimePickerDialogClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTimePickerDialogClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfTimePickerDialogClass::Get_E_onTimeSet()
{
    return NULL;
}
void ClassOfTimePickerDialogClass::Put_E_onTimeSet(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TimePickerDialogClass_onTimeSet,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

void ClassOfTimePickerDialogClass::Put_F_onTimeChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_TimePickerDialogClass_onTimeChanged,In_Value,NULL);
}
void * ClassOfTimePickerDialogClass::Get_F_onTimeChanged()
{
    return NULL;
}


void SRPAPI ClassOfTimePickerDialogClass::onTimeChanged(VS_INT32 hourOfDay,VS_INT32 minute)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onTimeChanged",hourOfDay,minute);
}

ClassOfSmsManagerClass::ClassOfSmsManagerClass()
{
}

ClassOfSmsManagerClass::ClassOfSmsManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SmsManagerClass,0,NULL));
}

ClassOfSmsManagerClass::ClassOfSmsManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSmsManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SmsManagerClass" );
    return Buf;
}

class ClassOfSmsManagerClass *ClassOfSmsManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSmsManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSmsManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SmsManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSmsManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCursorClass::ClassOfCursorClass()
{
}

ClassOfCursorClass::ClassOfCursorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CursorClass,0,NULL));
}

ClassOfCursorClass::ClassOfCursorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCursorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CursorClass" );
    return Buf;
}

class ClassOfCursorClass *ClassOfCursorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCursorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCursorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CursorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCursorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfWindowClass::ClassOfWindowClass()
{
}

ClassOfWindowClass::ClassOfWindowClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_WindowClass,0,NULL));
}

ClassOfWindowClass::ClassOfWindowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfWindowClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "WindowClass" );
    return Buf;
}

class ClassOfWindowClass *ClassOfWindowClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfWindowClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfWindowClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "WindowClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfWindowClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMediaPlayerClass::ClassOfMediaPlayerClass()
{
}

ClassOfMediaPlayerClass::ClassOfMediaPlayerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MediaPlayerClass,0,NULL));
}

ClassOfMediaPlayerClass::ClassOfMediaPlayerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMediaPlayerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MediaPlayerClass" );
    return Buf;
}

class ClassOfMediaPlayerClass *ClassOfMediaPlayerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMediaPlayerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMediaPlayerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MediaPlayerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMediaPlayerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onBufferingUpdate()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onBufferingUpdate(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onBufferingUpdate,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onCompletion()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onCompletion(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onCompletion,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onError()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onError(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onError,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onInfo()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onInfo(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onInfo,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onPrepared()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onPrepared(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onPrepared,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onSeekComplete()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onSeekComplete(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onSeekComplete,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfMediaPlayerClass::Get_E_onVideoSizeChanged()
{
    return NULL;
}
void ClassOfMediaPlayerClass::Put_E_onVideoSizeChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_MediaPlayerClass_onVideoSizeChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfContentResolverClass::ClassOfContentResolverClass()
{
}

ClassOfContentResolverClass::ClassOfContentResolverClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContentResolverClass,0,NULL));
}

ClassOfContentResolverClass::ClassOfContentResolverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContentResolverClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContentResolverClass" );
    return Buf;
}

class ClassOfContentResolverClass *ClassOfContentResolverClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContentResolverClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContentResolverClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContentResolverClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContentResolverClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfResourcesClass::ClassOfResourcesClass()
{
}

ClassOfResourcesClass::ClassOfResourcesClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ResourcesClass,0,NULL));
}

ClassOfResourcesClass::ClassOfResourcesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfResourcesClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ResourcesClass" );
    return Buf;
}

class ClassOfResourcesClass *ClassOfResourcesClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfResourcesClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfResourcesClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ResourcesClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfResourcesClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfFileInputStreamClass::ClassOfFileInputStreamClass()
{
}

ClassOfFileInputStreamClass::ClassOfFileInputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_FileInputStreamClass,0,NULL));
}

ClassOfFileInputStreamClass::ClassOfFileInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfFileInputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "FileInputStreamClass" );
    return Buf;
}

class ClassOfFileInputStreamClass *ClassOfFileInputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfFileInputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfFileInputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "FileInputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfFileInputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfEnvironmentClass::ClassOfEnvironmentClass()
{
}

ClassOfEnvironmentClass::ClassOfEnvironmentClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_EnvironmentClass,0,NULL));
}

ClassOfEnvironmentClass::ClassOfEnvironmentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfEnvironmentClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "EnvironmentClass" );
    return Buf;
}

class ClassOfEnvironmentClass *ClassOfEnvironmentClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfEnvironmentClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfEnvironmentClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "EnvironmentClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfEnvironmentClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAndroidInitClass::ClassOfAndroidInitClass()
{
}

ClassOfAndroidInitClass::ClassOfAndroidInitClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AndroidInitClass,0,NULL));
}

ClassOfAndroidInitClass::ClassOfAndroidInitClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAndroidInitClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AndroidInitClass" );
    return Buf;
}

class ClassOfAndroidInitClass *ClassOfAndroidInitClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAndroidInitClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAndroidInitClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AndroidInitClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAndroidInitClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfAndroidInitClass::Get_E_onInitClass()
{
    return NULL;
}
void ClassOfAndroidInitClass::Put_E_onInitClass(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AndroidInitClass_onInitClass,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfImageViewClass::ClassOfImageViewClass()
{
}

ClassOfImageViewClass::ClassOfImageViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ImageViewClass,0,NULL));
}

ClassOfImageViewClass::ClassOfImageViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfImageViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ImageViewClass" );
    return Buf;
}

class ClassOfImageViewClass *ClassOfImageViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfImageViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfImageViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ImageViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfImageViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfQuickContactBadgeClass::ClassOfQuickContactBadgeClass()
{
}

ClassOfQuickContactBadgeClass::ClassOfQuickContactBadgeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_QuickContactBadgeClass,0,NULL));
}

ClassOfQuickContactBadgeClass::ClassOfQuickContactBadgeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfQuickContactBadgeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "QuickContactBadgeClass" );
    return Buf;
}

class ClassOfQuickContactBadgeClass *ClassOfQuickContactBadgeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfQuickContactBadgeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfQuickContactBadgeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "QuickContactBadgeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfQuickContactBadgeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfImageButtonClass::ClassOfImageButtonClass()
{
}

ClassOfImageButtonClass::ClassOfImageButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ImageButtonClass,0,NULL));
}

ClassOfImageButtonClass::ClassOfImageButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfImageButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ImageButtonClass" );
    return Buf;
}

class ClassOfImageButtonClass *ClassOfImageButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfImageButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfImageButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ImageButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfImageButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfZoomButtonClass::ClassOfZoomButtonClass()
{
}

ClassOfZoomButtonClass::ClassOfZoomButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ZoomButtonClass,0,NULL));
}

ClassOfZoomButtonClass::ClassOfZoomButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfZoomButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ZoomButtonClass" );
    return Buf;
}

class ClassOfZoomButtonClass *ClassOfZoomButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfZoomButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfZoomButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ZoomButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfZoomButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfByteArrayInputStreamClass::ClassOfByteArrayInputStreamClass()
{
}

ClassOfByteArrayInputStreamClass::ClassOfByteArrayInputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ByteArrayInputStreamClass,0,NULL));
}

ClassOfByteArrayInputStreamClass::ClassOfByteArrayInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfByteArrayInputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ByteArrayInputStreamClass" );
    return Buf;
}

class ClassOfByteArrayInputStreamClass *ClassOfByteArrayInputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfByteArrayInputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfByteArrayInputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ByteArrayInputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfByteArrayInputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSimplePackageManagerClass::ClassOfSimplePackageManagerClass()
{
}

ClassOfSimplePackageManagerClass::ClassOfSimplePackageManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SimplePackageManagerClass,0,NULL));
}

ClassOfSimplePackageManagerClass::ClassOfSimplePackageManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSimplePackageManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SimplePackageManagerClass" );
    return Buf;
}

class ClassOfSimplePackageManagerClass *ClassOfSimplePackageManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSimplePackageManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSimplePackageManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SimplePackageManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSimplePackageManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfNotificationClass::ClassOfNotificationClass()
{
}

ClassOfNotificationClass::ClassOfNotificationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_NotificationClass,0,NULL));
}

ClassOfNotificationClass::ClassOfNotificationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfNotificationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "NotificationClass" );
    return Buf;
}

class ClassOfNotificationClass *ClassOfNotificationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfNotificationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfNotificationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "NotificationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfNotificationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCheckedTextViewClass::ClassOfCheckedTextViewClass()
{
}

ClassOfCheckedTextViewClass::ClassOfCheckedTextViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CheckedTextViewClass,0,NULL));
}

ClassOfCheckedTextViewClass::ClassOfCheckedTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCheckedTextViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CheckedTextViewClass" );
    return Buf;
}

class ClassOfCheckedTextViewClass *ClassOfCheckedTextViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCheckedTextViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCheckedTextViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CheckedTextViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCheckedTextViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfLayoutInflaterClass::ClassOfLayoutInflaterClass()
{
}

ClassOfLayoutInflaterClass::ClassOfLayoutInflaterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_LayoutInflaterClass,0,NULL));
}

ClassOfLayoutInflaterClass::ClassOfLayoutInflaterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfLayoutInflaterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "LayoutInflaterClass" );
    return Buf;
}

class ClassOfLayoutInflaterClass *ClassOfLayoutInflaterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfLayoutInflaterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfLayoutInflaterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "LayoutInflaterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfLayoutInflaterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSweepGradientClass::ClassOfSweepGradientClass()
{
}

ClassOfSweepGradientClass::ClassOfSweepGradientClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SweepGradientClass,0,NULL));
}

ClassOfSweepGradientClass::ClassOfSweepGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSweepGradientClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SweepGradientClass" );
    return Buf;
}

class ClassOfSweepGradientClass *ClassOfSweepGradientClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSweepGradientClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSweepGradientClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SweepGradientClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSweepGradientClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfMotionEventClass::ClassOfMotionEventClass()
{
}

ClassOfMotionEventClass::ClassOfMotionEventClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_MotionEventClass,0,NULL));
}

ClassOfMotionEventClass::ClassOfMotionEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfMotionEventClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "MotionEventClass" );
    return Buf;
}

class ClassOfMotionEventClass *ClassOfMotionEventClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfMotionEventClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfMotionEventClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "MotionEventClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfMotionEventClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAssetFileDescriptorClass::ClassOfAssetFileDescriptorClass()
{
}

ClassOfAssetFileDescriptorClass::ClassOfAssetFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AssetFileDescriptorClass,0,NULL));
}

ClassOfAssetFileDescriptorClass::ClassOfAssetFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAssetFileDescriptorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AssetFileDescriptorClass" );
    return Buf;
}

class ClassOfAssetFileDescriptorClass *ClassOfAssetFileDescriptorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAssetFileDescriptorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAssetFileDescriptorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AssetFileDescriptorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAssetFileDescriptorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfWebSettingsClass::ClassOfWebSettingsClass()
{
}

ClassOfWebSettingsClass::ClassOfWebSettingsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_WebSettingsClass,0,NULL));
}

ClassOfWebSettingsClass::ClassOfWebSettingsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfWebSettingsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "WebSettingsClass" );
    return Buf;
}

class ClassOfWebSettingsClass *ClassOfWebSettingsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfWebSettingsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfWebSettingsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "WebSettingsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfWebSettingsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfColorStateListClass::ClassOfColorStateListClass()
{
}

ClassOfColorStateListClass::ClassOfColorStateListClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ColorStateListClass,0,NULL));
}

ClassOfColorStateListClass::ClassOfColorStateListClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfColorStateListClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ColorStateListClass" );
    return Buf;
}

class ClassOfColorStateListClass *ClassOfColorStateListClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfColorStateListClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfColorStateListClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ColorStateListClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfColorStateListClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfBaseAdapterClass::ClassOfBaseAdapterClass()
{
}

ClassOfBaseAdapterClass::ClassOfBaseAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BaseAdapterClass,0,NULL));
}

ClassOfBaseAdapterClass::ClassOfBaseAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBaseAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BaseAdapterClass" );
    return Buf;
}

class ClassOfBaseAdapterClass *ClassOfBaseAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBaseAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBaseAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BaseAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBaseAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfBaseAdapterClass::Put_F_onCreateAndroid(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_onCreateAndroid,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_onCreateAndroid()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getCount(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getCount,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getCount()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getItem(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getItem,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getItem()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getItemId(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getItemId,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getItemId()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getViewTypeCount(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getViewTypeCount,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getViewTypeCount()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getItemViewType(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getItemViewType,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getItemViewType()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_getView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_getView,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_getView()
{
    return NULL;
}

void ClassOfBaseAdapterClass::Put_F_isEmpty(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_BaseAdapterClass_isEmpty,In_Value,NULL);
}
void * ClassOfBaseAdapterClass::Get_F_isEmpty()
{
    return NULL;
}


void SRPAPI ClassOfBaseAdapterClass::onCreateAndroid()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onCreateAndroid");
}
VS_INT32 SRPAPI ClassOfBaseAdapterClass::getCount()
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getCount");
}
VS_INT32 SRPAPI ClassOfBaseAdapterClass::getItem(VS_INT32 position)
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getItem",position);
}
VS_LONG SRPAPI ClassOfBaseAdapterClass::getItemId(VS_INT32 position)
{
    return (VS_LONG )ThisSRPInterface -> Call(ThisSRPObject,"getItemId",position);
}
VS_INT32 SRPAPI ClassOfBaseAdapterClass::getViewTypeCount()
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getViewTypeCount");
}
VS_INT32 SRPAPI ClassOfBaseAdapterClass::getItemViewType(VS_INT32 position)
{
    return (VS_INT32 )ThisSRPInterface -> Call(ThisSRPObject,"getItemViewType",position);
}
VS_OBJPTR SRPAPI ClassOfBaseAdapterClass::getView(VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"getView",position,convertView,parent);
}
VS_BOOL SRPAPI ClassOfBaseAdapterClass::isEmpty()
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"isEmpty");
}

ClassOfSimpleAdapterClass::ClassOfSimpleAdapterClass()
{
}

ClassOfSimpleAdapterClass::ClassOfSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SimpleAdapterClass,0,NULL));
}

ClassOfSimpleAdapterClass::ClassOfSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSimpleAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SimpleAdapterClass" );
    return Buf;
}

class ClassOfSimpleAdapterClass *ClassOfSimpleAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSimpleAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSimpleAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SimpleAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSimpleAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCursorAdapterClass::ClassOfCursorAdapterClass()
{
}

ClassOfCursorAdapterClass::ClassOfCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CursorAdapterClass,0,NULL));
}

ClassOfCursorAdapterClass::ClassOfCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCursorAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CursorAdapterClass" );
    return Buf;
}

class ClassOfCursorAdapterClass *ClassOfCursorAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCursorAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCursorAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CursorAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCursorAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfCursorAdapterClass::Put_F_bindView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_CursorAdapterClass_bindView,In_Value,NULL);
}
void * ClassOfCursorAdapterClass::Get_F_bindView()
{
    return NULL;
}

void ClassOfCursorAdapterClass::Put_F_newView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_CursorAdapterClass_newView,In_Value,NULL);
}
void * ClassOfCursorAdapterClass::Get_F_newView()
{
    return NULL;
}


void SRPAPI ClassOfCursorAdapterClass::bindView(VS_OBJPTR view,VS_OBJPTR cursor)
{
    ThisSRPInterface -> Call(ThisSRPObject,"bindView",view,cursor);
}
VS_OBJPTR SRPAPI ClassOfCursorAdapterClass::newView(VS_OBJPTR cursor,VS_OBJPTR parent)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"newView",cursor,parent);
}

ClassOfStringArrayAdapterClass::ClassOfStringArrayAdapterClass()
{
}

ClassOfStringArrayAdapterClass::ClassOfStringArrayAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_StringArrayAdapterClass,0,NULL));
}

ClassOfStringArrayAdapterClass::ClassOfStringArrayAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfStringArrayAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "StringArrayAdapterClass" );
    return Buf;
}

class ClassOfStringArrayAdapterClass *ClassOfStringArrayAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfStringArrayAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfStringArrayAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "StringArrayAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfStringArrayAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfStringArrayAdapterClass::Put_F_getView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_StringArrayAdapterClass_getView,In_Value,NULL);
}
void * ClassOfStringArrayAdapterClass::Get_F_getView()
{
    return NULL;
}


VS_OBJPTR SRPAPI ClassOfStringArrayAdapterClass::getView(VS_INT32 Position,VS_OBJPTR convertView,VS_OBJPTR parent)
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"getView",Position,convertView,parent);
}

ClassOfSensorManagerClass::ClassOfSensorManagerClass()
{
}

ClassOfSensorManagerClass::ClassOfSensorManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SensorManagerClass,0,NULL));
}

ClassOfSensorManagerClass::ClassOfSensorManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSensorManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SensorManagerClass" );
    return Buf;
}

class ClassOfSensorManagerClass *ClassOfSensorManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSensorManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSensorManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SensorManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSensorManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfSensorManagerClass::Get_E_onAccuracyChanged()
{
    return NULL;
}
void ClassOfSensorManagerClass::Put_E_onAccuracyChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SensorManagerClass_onAccuracyChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSensorManagerClass::Get_E_onSensorChanged()
{
    return NULL;
}
void ClassOfSensorManagerClass::Put_E_onSensorChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SensorManagerClass_onSensorChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfDrawableClass::ClassOfDrawableClass()
{
}

ClassOfDrawableClass::ClassOfDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DrawableClass,0,NULL));
}

ClassOfDrawableClass::ClassOfDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DrawableClass" );
    return Buf;
}

class ClassOfDrawableClass *ClassOfDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfDrawableContainerClass::ClassOfDrawableContainerClass()
{
}

ClassOfDrawableContainerClass::ClassOfDrawableContainerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DrawableContainerClass,0,NULL));
}

ClassOfDrawableContainerClass::ClassOfDrawableContainerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDrawableContainerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DrawableContainerClass" );
    return Buf;
}

class ClassOfDrawableContainerClass *ClassOfDrawableContainerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDrawableContainerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDrawableContainerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DrawableContainerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDrawableContainerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfStateListDrawableClass::ClassOfStateListDrawableClass()
{
}

ClassOfStateListDrawableClass::ClassOfStateListDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_StateListDrawableClass,0,NULL));
}

ClassOfStateListDrawableClass::ClassOfStateListDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfStateListDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "StateListDrawableClass" );
    return Buf;
}

class ClassOfStateListDrawableClass *ClassOfStateListDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfStateListDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfStateListDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "StateListDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfStateListDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfColorDrawableClass::ClassOfColorDrawableClass()
{
}

ClassOfColorDrawableClass::ClassOfColorDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ColorDrawableClass,0,NULL));
}

ClassOfColorDrawableClass::ClassOfColorDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfColorDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ColorDrawableClass" );
    return Buf;
}

class ClassOfColorDrawableClass *ClassOfColorDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfColorDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfColorDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ColorDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfColorDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfBitmapDrawableClass::ClassOfBitmapDrawableClass()
{
}

ClassOfBitmapDrawableClass::ClassOfBitmapDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BitmapDrawableClass,0,NULL));
}

ClassOfBitmapDrawableClass::ClassOfBitmapDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBitmapDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BitmapDrawableClass" );
    return Buf;
}

class ClassOfBitmapDrawableClass *ClassOfBitmapDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBitmapDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBitmapDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BitmapDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBitmapDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfShapeDrawableClass::ClassOfShapeDrawableClass()
{
}

ClassOfShapeDrawableClass::ClassOfShapeDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ShapeDrawableClass,0,NULL));
}

ClassOfShapeDrawableClass::ClassOfShapeDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfShapeDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ShapeDrawableClass" );
    return Buf;
}

class ClassOfShapeDrawableClass *ClassOfShapeDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfShapeDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfShapeDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ShapeDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfShapeDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfLayerDrawableClass::ClassOfLayerDrawableClass()
{
}

ClassOfLayerDrawableClass::ClassOfLayerDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_LayerDrawableClass,0,NULL));
}

ClassOfLayerDrawableClass::ClassOfLayerDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfLayerDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "LayerDrawableClass" );
    return Buf;
}

class ClassOfLayerDrawableClass *ClassOfLayerDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfLayerDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfLayerDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "LayerDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfLayerDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTransitionDrawableClass::ClassOfTransitionDrawableClass()
{
}

ClassOfTransitionDrawableClass::ClassOfTransitionDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TransitionDrawableClass,0,NULL));
}

ClassOfTransitionDrawableClass::ClassOfTransitionDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTransitionDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TransitionDrawableClass" );
    return Buf;
}

class ClassOfTransitionDrawableClass *ClassOfTransitionDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTransitionDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTransitionDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TransitionDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTransitionDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfViewGroupClass::ClassOfViewGroupClass()
{
}

ClassOfViewGroupClass::ClassOfViewGroupClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewGroupClass,0,NULL));
}

ClassOfViewGroupClass::ClassOfViewGroupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewGroupClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewGroupClass" );
    return Buf;
}

class ClassOfViewGroupClass *ClassOfViewGroupClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewGroupClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewGroupClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewGroupClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewGroupClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfViewGroupClass::Put_F_onInterceptTouchEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewGroupClass_onInterceptTouchEvent,In_Value,NULL);
}
void * ClassOfViewGroupClass::Get_F_onInterceptTouchEvent()
{
    return NULL;
}


VS_BOOL SRPAPI ClassOfViewGroupClass::onInterceptTouchEvent(VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onInterceptTouchEvent",event);
}

ClassOfRelativeLayoutClass::ClassOfRelativeLayoutClass()
{
}

ClassOfRelativeLayoutClass::ClassOfRelativeLayoutClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RelativeLayoutClass,0,NULL));
}

ClassOfRelativeLayoutClass::ClassOfRelativeLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRelativeLayoutClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RelativeLayoutClass" );
    return Buf;
}

class ClassOfRelativeLayoutClass *ClassOfRelativeLayoutClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRelativeLayoutClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRelativeLayoutClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RelativeLayoutClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRelativeLayoutClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAbsoluteLayoutClass::ClassOfAbsoluteLayoutClass()
{
}

ClassOfAbsoluteLayoutClass::ClassOfAbsoluteLayoutClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AbsoluteLayoutClass,0,NULL));
}

ClassOfAbsoluteLayoutClass::ClassOfAbsoluteLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAbsoluteLayoutClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AbsoluteLayoutClass" );
    return Buf;
}

class ClassOfAbsoluteLayoutClass *ClassOfAbsoluteLayoutClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAbsoluteLayoutClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAbsoluteLayoutClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AbsoluteLayoutClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAbsoluteLayoutClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfLinearLayoutClass::ClassOfLinearLayoutClass()
{
}

ClassOfLinearLayoutClass::ClassOfLinearLayoutClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_LinearLayoutClass,0,NULL));
}

ClassOfLinearLayoutClass::ClassOfLinearLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfLinearLayoutClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "LinearLayoutClass" );
    return Buf;
}

class ClassOfLinearLayoutClass *ClassOfLinearLayoutClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfLinearLayoutClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfLinearLayoutClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "LinearLayoutClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfLinearLayoutClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTableRowClass::ClassOfTableRowClass()
{
}

ClassOfTableRowClass::ClassOfTableRowClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TableRowClass,0,NULL));
}

ClassOfTableRowClass::ClassOfTableRowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTableRowClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TableRowClass" );
    return Buf;
}

class ClassOfTableRowClass *ClassOfTableRowClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTableRowClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTableRowClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TableRowClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTableRowClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTableLayoutClass::ClassOfTableLayoutClass()
{
}

ClassOfTableLayoutClass::ClassOfTableLayoutClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TableLayoutClass,0,NULL));
}

ClassOfTableLayoutClass::ClassOfTableLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTableLayoutClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TableLayoutClass" );
    return Buf;
}

class ClassOfTableLayoutClass *ClassOfTableLayoutClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTableLayoutClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTableLayoutClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TableLayoutClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTableLayoutClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRadioGroupClass::ClassOfRadioGroupClass()
{
}

ClassOfRadioGroupClass::ClassOfRadioGroupClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RadioGroupClass,0,NULL));
}

ClassOfRadioGroupClass::ClassOfRadioGroupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRadioGroupClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RadioGroupClass" );
    return Buf;
}

class ClassOfRadioGroupClass *ClassOfRadioGroupClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRadioGroupClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRadioGroupClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RadioGroupClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRadioGroupClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfRadioGroupClass::Get_E_onCheckedChanged()
{
    return NULL;
}
void ClassOfRadioGroupClass::Put_E_onCheckedChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_RadioGroupClass_onCheckedChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfRadioGroupClass::Get_E_onChildViewAdded()
{
    return NULL;
}
void ClassOfRadioGroupClass::Put_E_onChildViewAdded(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_RadioGroupClass_onChildViewAdded,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfRadioGroupClass::Get_E_onChildViewRemoved()
{
    return NULL;
}
void ClassOfRadioGroupClass::Put_E_onChildViewRemoved(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_RadioGroupClass_onChildViewRemoved,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfSlidingDrawerClass::ClassOfSlidingDrawerClass()
{
}

ClassOfSlidingDrawerClass::ClassOfSlidingDrawerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SlidingDrawerClass,0,NULL));
}

ClassOfSlidingDrawerClass::ClassOfSlidingDrawerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSlidingDrawerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SlidingDrawerClass" );
    return Buf;
}

class ClassOfSlidingDrawerClass *ClassOfSlidingDrawerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSlidingDrawerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSlidingDrawerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SlidingDrawerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSlidingDrawerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfSlidingDrawerClass::Get_E_onDrawerClosed()
{
    return NULL;
}
void ClassOfSlidingDrawerClass::Put_E_onDrawerClosed(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SlidingDrawerClass_onDrawerClosed,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSlidingDrawerClass::Get_E_onDrawerOpened()
{
    return NULL;
}
void ClassOfSlidingDrawerClass::Put_E_onDrawerOpened(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SlidingDrawerClass_onDrawerOpened,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSlidingDrawerClass::Get_E_onScrollEnded()
{
    return NULL;
}
void ClassOfSlidingDrawerClass::Put_E_onScrollEnded(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SlidingDrawerClass_onScrollEnded,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSlidingDrawerClass::Get_E_onScrollStarted()
{
    return NULL;
}
void ClassOfSlidingDrawerClass::Put_E_onScrollStarted(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SlidingDrawerClass_onScrollStarted,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfFrameLayoutClass::ClassOfFrameLayoutClass()
{
}

ClassOfFrameLayoutClass::ClassOfFrameLayoutClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_FrameLayoutClass,0,NULL));
}

ClassOfFrameLayoutClass::ClassOfFrameLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfFrameLayoutClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "FrameLayoutClass" );
    return Buf;
}

class ClassOfFrameLayoutClass *ClassOfFrameLayoutClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfFrameLayoutClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfFrameLayoutClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "FrameLayoutClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfFrameLayoutClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfScrollViewClass::ClassOfScrollViewClass()
{
}

ClassOfScrollViewClass::ClassOfScrollViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ScrollViewClass,0,NULL));
}

ClassOfScrollViewClass::ClassOfScrollViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfScrollViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ScrollViewClass" );
    return Buf;
}

class ClassOfScrollViewClass *ClassOfScrollViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfScrollViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfScrollViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ScrollViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfScrollViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTimePickerClass::ClassOfTimePickerClass()
{
}

ClassOfTimePickerClass::ClassOfTimePickerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TimePickerClass,0,NULL));
}

ClassOfTimePickerClass::ClassOfTimePickerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTimePickerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TimePickerClass" );
    return Buf;
}

class ClassOfTimePickerClass *ClassOfTimePickerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTimePickerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTimePickerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TimePickerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTimePickerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfTimePickerClass::Get_E_onTimeChanged()
{
    return NULL;
}
void ClassOfTimePickerClass::Put_E_onTimeChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TimePickerClass_onTimeChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfDatePickerClass::ClassOfDatePickerClass()
{
}

ClassOfDatePickerClass::ClassOfDatePickerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DatePickerClass,0,NULL));
}

ClassOfDatePickerClass::ClassOfDatePickerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDatePickerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DatePickerClass" );
    return Buf;
}

class ClassOfDatePickerClass *ClassOfDatePickerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDatePickerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDatePickerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DatePickerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDatePickerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfDatePickerClass::Get_E_onDateChanged()
{
    return NULL;
}
void ClassOfDatePickerClass::Put_E_onDateChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DatePickerClass_onDateChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfViewAnimatorClass::ClassOfViewAnimatorClass()
{
}

ClassOfViewAnimatorClass::ClassOfViewAnimatorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewAnimatorClass,0,NULL));
}

ClassOfViewAnimatorClass::ClassOfViewAnimatorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewAnimatorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewAnimatorClass" );
    return Buf;
}

class ClassOfViewAnimatorClass *ClassOfViewAnimatorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewAnimatorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewAnimatorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewAnimatorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewAnimatorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfViewSwitcherClass::ClassOfViewSwitcherClass()
{
}

ClassOfViewSwitcherClass::ClassOfViewSwitcherClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewSwitcherClass,0,NULL));
}

ClassOfViewSwitcherClass::ClassOfViewSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewSwitcherClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewSwitcherClass" );
    return Buf;
}

class ClassOfViewSwitcherClass *ClassOfViewSwitcherClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewSwitcherClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewSwitcherClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewSwitcherClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewSwitcherClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTextSwitcherClass::ClassOfTextSwitcherClass()
{
}

ClassOfTextSwitcherClass::ClassOfTextSwitcherClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TextSwitcherClass,0,NULL));
}

ClassOfTextSwitcherClass::ClassOfTextSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTextSwitcherClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TextSwitcherClass" );
    return Buf;
}

class ClassOfTextSwitcherClass *ClassOfTextSwitcherClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTextSwitcherClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTextSwitcherClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TextSwitcherClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTextSwitcherClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfViewFlipperClass::ClassOfViewFlipperClass()
{
}

ClassOfViewFlipperClass::ClassOfViewFlipperClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewFlipperClass,0,NULL));
}

ClassOfViewFlipperClass::ClassOfViewFlipperClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewFlipperClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewFlipperClass" );
    return Buf;
}

class ClassOfViewFlipperClass *ClassOfViewFlipperClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewFlipperClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewFlipperClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewFlipperClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewFlipperClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTabHostClass::ClassOfTabHostClass()
{
}

ClassOfTabHostClass::ClassOfTabHostClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TabHostClass,0,NULL));
}

ClassOfTabHostClass::ClassOfTabHostClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTabHostClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TabHostClass" );
    return Buf;
}

class ClassOfTabHostClass *ClassOfTabHostClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTabHostClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTabHostClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TabHostClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTabHostClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfTabHostClass::Get_E_onTabChanged()
{
    return NULL;
}
void ClassOfTabHostClass::Put_E_onTabChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TabHostClass_onTabChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfImageSwitcherClass::ClassOfImageSwitcherClass()
{
}

ClassOfImageSwitcherClass::ClassOfImageSwitcherClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ImageSwitcherClass,0,NULL));
}

ClassOfImageSwitcherClass::ClassOfImageSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfImageSwitcherClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ImageSwitcherClass" );
    return Buf;
}

class ClassOfImageSwitcherClass *ClassOfImageSwitcherClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfImageSwitcherClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfImageSwitcherClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ImageSwitcherClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfImageSwitcherClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAnimationUtilsClass::ClassOfAnimationUtilsClass()
{
}

ClassOfAnimationUtilsClass::ClassOfAnimationUtilsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AnimationUtilsClass,0,NULL));
}

ClassOfAnimationUtilsClass::ClassOfAnimationUtilsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAnimationUtilsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AnimationUtilsClass" );
    return Buf;
}

class ClassOfAnimationUtilsClass *ClassOfAnimationUtilsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAnimationUtilsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAnimationUtilsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AnimationUtilsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAnimationUtilsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSoundPoolClass::ClassOfSoundPoolClass()
{
}

ClassOfSoundPoolClass::ClassOfSoundPoolClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SoundPoolClass,0,NULL));
}

ClassOfSoundPoolClass::ClassOfSoundPoolClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSoundPoolClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SoundPoolClass" );
    return Buf;
}

class ClassOfSoundPoolClass *ClassOfSoundPoolClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSoundPoolClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSoundPoolClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SoundPoolClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSoundPoolClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTwoLineListItemClass::ClassOfTwoLineListItemClass()
{
}

ClassOfTwoLineListItemClass::ClassOfTwoLineListItemClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TwoLineListItemClass,0,NULL));
}

ClassOfTwoLineListItemClass::ClassOfTwoLineListItemClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTwoLineListItemClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TwoLineListItemClass" );
    return Buf;
}

class ClassOfTwoLineListItemClass *ClassOfTwoLineListItemClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTwoLineListItemClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTwoLineListItemClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TwoLineListItemClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTwoLineListItemClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfDatePickerDialogClass::ClassOfDatePickerDialogClass()
{
}

ClassOfDatePickerDialogClass::ClassOfDatePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DatePickerDialogClass,0,NULL));
}

ClassOfDatePickerDialogClass::ClassOfDatePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDatePickerDialogClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DatePickerDialogClass" );
    return Buf;
}

class ClassOfDatePickerDialogClass *ClassOfDatePickerDialogClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDatePickerDialogClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDatePickerDialogClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DatePickerDialogClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDatePickerDialogClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfDatePickerDialogClass::Get_E_onDateSet()
{
    return NULL;
}
void ClassOfDatePickerDialogClass::Put_E_onDateSet(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_DatePickerDialogClass_onDateSet,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

void ClassOfDatePickerDialogClass::Put_F_onDateChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_DatePickerDialogClass_onDateChanged,In_Value,NULL);
}
void * ClassOfDatePickerDialogClass::Get_F_onDateChanged()
{
    return NULL;
}


void SRPAPI ClassOfDatePickerDialogClass::onDateChanged(VS_INT32 onDateChanged,VS_INT32 month,VS_INT32 day)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onDateChanged",onDateChanged,month,day);
}

ClassOfSensorClass::ClassOfSensorClass()
{
}

ClassOfSensorClass::ClassOfSensorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SensorClass,0,NULL));
}

ClassOfSensorClass::ClassOfSensorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSensorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SensorClass" );
    return Buf;
}

class ClassOfSensorClass *ClassOfSensorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSensorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSensorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SensorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSensorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfPendingIntentClass::ClassOfPendingIntentClass()
{
}

ClassOfPendingIntentClass::ClassOfPendingIntentClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_PendingIntentClass,0,NULL));
}

ClassOfPendingIntentClass::ClassOfPendingIntentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfPendingIntentClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "PendingIntentClass" );
    return Buf;
}

class ClassOfPendingIntentClass *ClassOfPendingIntentClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfPendingIntentClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfPendingIntentClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "PendingIntentClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfPendingIntentClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfPendingIntentClass::Get_E_onSendFinished()
{
    return NULL;
}
void ClassOfPendingIntentClass::Put_E_onSendFinished(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_PendingIntentClass_onSendFinished,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfSharedPreferencesClass::ClassOfSharedPreferencesClass()
{
}

ClassOfSharedPreferencesClass::ClassOfSharedPreferencesClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SharedPreferencesClass,0,NULL));
}

ClassOfSharedPreferencesClass::ClassOfSharedPreferencesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSharedPreferencesClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SharedPreferencesClass" );
    return Buf;
}

class ClassOfSharedPreferencesClass *ClassOfSharedPreferencesClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSharedPreferencesClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSharedPreferencesClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SharedPreferencesClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSharedPreferencesClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAnimationDrawableClass::ClassOfAnimationDrawableClass()
{
}

ClassOfAnimationDrawableClass::ClassOfAnimationDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AnimationDrawableClass,0,NULL));
}

ClassOfAnimationDrawableClass::ClassOfAnimationDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAnimationDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AnimationDrawableClass" );
    return Buf;
}

class ClassOfAnimationDrawableClass *ClassOfAnimationDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAnimationDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAnimationDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AnimationDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAnimationDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfHorizontalScrollViewClass::ClassOfHorizontalScrollViewClass()
{
}

ClassOfHorizontalScrollViewClass::ClassOfHorizontalScrollViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_HorizontalScrollViewClass,0,NULL));
}

ClassOfHorizontalScrollViewClass::ClassOfHorizontalScrollViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfHorizontalScrollViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "HorizontalScrollViewClass" );
    return Buf;
}

class ClassOfHorizontalScrollViewClass *ClassOfHorizontalScrollViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfHorizontalScrollViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfHorizontalScrollViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "HorizontalScrollViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfHorizontalScrollViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAbsSeekBarClass::ClassOfAbsSeekBarClass()
{
}

ClassOfAbsSeekBarClass::ClassOfAbsSeekBarClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AbsSeekBarClass,0,NULL));
}

ClassOfAbsSeekBarClass::ClassOfAbsSeekBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAbsSeekBarClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AbsSeekBarClass" );
    return Buf;
}

class ClassOfAbsSeekBarClass *ClassOfAbsSeekBarClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAbsSeekBarClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAbsSeekBarClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AbsSeekBarClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAbsSeekBarClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSeekBarClass::ClassOfSeekBarClass()
{
}

ClassOfSeekBarClass::ClassOfSeekBarClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SeekBarClass,0,NULL));
}

ClassOfSeekBarClass::ClassOfSeekBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSeekBarClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SeekBarClass" );
    return Buf;
}

class ClassOfSeekBarClass *ClassOfSeekBarClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSeekBarClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSeekBarClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SeekBarClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSeekBarClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfSeekBarClass::Get_E_onProgressChanged()
{
    return NULL;
}
void ClassOfSeekBarClass::Put_E_onProgressChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SeekBarClass_onProgressChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSeekBarClass::Get_E_onStartTrackingTouch()
{
    return NULL;
}
void ClassOfSeekBarClass::Put_E_onStartTrackingTouch(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SeekBarClass_onStartTrackingTouch,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfSeekBarClass::Get_E_onStopTrackingTouch()
{
    return NULL;
}
void ClassOfSeekBarClass::Put_E_onStopTrackingTouch(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_SeekBarClass_onStopTrackingTouch,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfRatingBarClass::ClassOfRatingBarClass()
{
}

ClassOfRatingBarClass::ClassOfRatingBarClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RatingBarClass,0,NULL));
}

ClassOfRatingBarClass::ClassOfRatingBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRatingBarClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RatingBarClass" );
    return Buf;
}

class ClassOfRatingBarClass *ClassOfRatingBarClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRatingBarClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRatingBarClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RatingBarClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRatingBarClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfRatingBarClass::Get_E_onRatingChanged()
{
    return NULL;
}
void ClassOfRatingBarClass::Put_E_onRatingChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_RatingBarClass_onRatingChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfPopupWindowClass::ClassOfPopupWindowClass()
{
}

ClassOfPopupWindowClass::ClassOfPopupWindowClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_PopupWindowClass,0,NULL));
}

ClassOfPopupWindowClass::ClassOfPopupWindowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfPopupWindowClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "PopupWindowClass" );
    return Buf;
}

class ClassOfPopupWindowClass *ClassOfPopupWindowClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfPopupWindowClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfPopupWindowClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "PopupWindowClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfPopupWindowClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfPopupWindowClass::Get_E_onDismiss()
{
    return NULL;
}
void ClassOfPopupWindowClass::Put_E_onDismiss(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_PopupWindowClass_onDismiss,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfButtonClass::ClassOfButtonClass()
{
}

ClassOfButtonClass::ClassOfButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ButtonClass,0,NULL));
}

ClassOfButtonClass::ClassOfButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ButtonClass" );
    return Buf;
}

class ClassOfButtonClass *ClassOfButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCompoundButtonClass::ClassOfCompoundButtonClass()
{
}

ClassOfCompoundButtonClass::ClassOfCompoundButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CompoundButtonClass,0,NULL));
}

ClassOfCompoundButtonClass::ClassOfCompoundButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCompoundButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CompoundButtonClass" );
    return Buf;
}

class ClassOfCompoundButtonClass *ClassOfCompoundButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCompoundButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCompoundButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CompoundButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCompoundButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfCompoundButtonClass::Get_E_onCheckedChanged()
{
    return NULL;
}
void ClassOfCompoundButtonClass::Put_E_onCheckedChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_CompoundButtonClass_onCheckedChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfToggleButtonClass::ClassOfToggleButtonClass()
{
}

ClassOfToggleButtonClass::ClassOfToggleButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ToggleButtonClass,0,NULL));
}

ClassOfToggleButtonClass::ClassOfToggleButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfToggleButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ToggleButtonClass" );
    return Buf;
}

class ClassOfToggleButtonClass *ClassOfToggleButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfToggleButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfToggleButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ToggleButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfToggleButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRadioButtonClass::ClassOfRadioButtonClass()
{
}

ClassOfRadioButtonClass::ClassOfRadioButtonClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RadioButtonClass,0,NULL));
}

ClassOfRadioButtonClass::ClassOfRadioButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRadioButtonClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RadioButtonClass" );
    return Buf;
}

class ClassOfRadioButtonClass *ClassOfRadioButtonClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRadioButtonClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRadioButtonClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RadioButtonClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRadioButtonClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCheckBoxClass::ClassOfCheckBoxClass()
{
}

ClassOfCheckBoxClass::ClassOfCheckBoxClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CheckBoxClass,0,NULL));
}

ClassOfCheckBoxClass::ClassOfCheckBoxClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCheckBoxClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CheckBoxClass" );
    return Buf;
}

class ClassOfCheckBoxClass *ClassOfCheckBoxClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCheckBoxClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCheckBoxClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CheckBoxClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCheckBoxClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfGradientDrawableClass::ClassOfGradientDrawableClass()
{
}

ClassOfGradientDrawableClass::ClassOfGradientDrawableClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_GradientDrawableClass,0,NULL));
}

ClassOfGradientDrawableClass::ClassOfGradientDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfGradientDrawableClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "GradientDrawableClass" );
    return Buf;
}

class ClassOfGradientDrawableClass *ClassOfGradientDrawableClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfGradientDrawableClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfGradientDrawableClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "GradientDrawableClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfGradientDrawableClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfAdapterViewClass::ClassOfAdapterViewClass()
{
}

ClassOfAdapterViewClass::ClassOfAdapterViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AdapterViewClass,0,NULL));
}

ClassOfAdapterViewClass::ClassOfAdapterViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAdapterViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AdapterViewClass" );
    return Buf;
}

class ClassOfAdapterViewClass *ClassOfAdapterViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAdapterViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAdapterViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AdapterViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAdapterViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfAdapterViewClass::Get_E_onItemClick()
{
    return NULL;
}
void ClassOfAdapterViewClass::Put_E_onItemClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AdapterViewClass_onItemClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAdapterViewClass::Get_E_onItemLongClick()
{
    return NULL;
}
void ClassOfAdapterViewClass::Put_E_onItemLongClick(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AdapterViewClass_onItemLongClick,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAdapterViewClass::Get_E_onItemSelected()
{
    return NULL;
}
void ClassOfAdapterViewClass::Put_E_onItemSelected(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AdapterViewClass_onItemSelected,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAdapterViewClass::Get_E_onNothingSelected()
{
    return NULL;
}
void ClassOfAdapterViewClass::Put_E_onNothingSelected(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AdapterViewClass_onNothingSelected,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfAbsSpinnerClass::ClassOfAbsSpinnerClass()
{
}

ClassOfAbsSpinnerClass::ClassOfAbsSpinnerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AbsSpinnerClass,0,NULL));
}

ClassOfAbsSpinnerClass::ClassOfAbsSpinnerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAbsSpinnerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AbsSpinnerClass" );
    return Buf;
}

class ClassOfAbsSpinnerClass *ClassOfAbsSpinnerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAbsSpinnerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAbsSpinnerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AbsSpinnerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAbsSpinnerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSpinnerClass::ClassOfSpinnerClass()
{
}

ClassOfSpinnerClass::ClassOfSpinnerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SpinnerClass,0,NULL));
}

ClassOfSpinnerClass::ClassOfSpinnerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSpinnerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SpinnerClass" );
    return Buf;
}

class ClassOfSpinnerClass *ClassOfSpinnerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSpinnerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSpinnerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SpinnerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSpinnerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfGalleryClass::ClassOfGalleryClass()
{
}

ClassOfGalleryClass::ClassOfGalleryClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_GalleryClass,0,NULL));
}

ClassOfGalleryClass::ClassOfGalleryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfGalleryClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "GalleryClass" );
    return Buf;
}

class ClassOfGalleryClass *ClassOfGalleryClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfGalleryClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfGalleryClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "GalleryClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfGalleryClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfGalleryClass::Put_F_onDown(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onDown,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onDown()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onFling(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onFling,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onFling()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onLongPress(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onLongPress,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onLongPress()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onScroll(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onScroll,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onScroll()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onShowPress(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onShowPress,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onShowPress()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onSingleTapUp(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onSingleTapUp,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onSingleTapUp()
{
    return NULL;
}

void ClassOfGalleryClass::Put_F_onTouchEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_GalleryClass_onTouchEvent,In_Value,NULL);
}
void * ClassOfGalleryClass::Get_F_onTouchEvent()
{
    return NULL;
}


VS_BOOL SRPAPI ClassOfGalleryClass::onDown(VS_OBJPTR e)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onDown",e);
}
VS_BOOL SRPAPI ClassOfGalleryClass::onFling(VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT velocityX,VS_FLOAT velocityY)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onFling",e1,e2,velocityX,velocityY);
}
VS_BOOL SRPAPI ClassOfGalleryClass::onLongPress(VS_OBJPTR e)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onLongPress",e);
}
VS_BOOL SRPAPI ClassOfGalleryClass::onScroll(VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT distanceX,VS_FLOAT distanceY)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onScroll",e1,e2,distanceX,distanceY);
}
void SRPAPI ClassOfGalleryClass::onShowPress(VS_OBJPTR e)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onShowPress",e);
}
VS_BOOL SRPAPI ClassOfGalleryClass::onSingleTapUp(VS_OBJPTR e)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onSingleTapUp",e);
}
VS_BOOL SRPAPI ClassOfGalleryClass::onTouchEvent(VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"onTouchEvent",event);
}

ClassOfAbsListViewClass::ClassOfAbsListViewClass()
{
}

ClassOfAbsListViewClass::ClassOfAbsListViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_AbsListViewClass,0,NULL));
}

ClassOfAbsListViewClass::ClassOfAbsListViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfAbsListViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "AbsListViewClass" );
    return Buf;
}

class ClassOfAbsListViewClass *ClassOfAbsListViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfAbsListViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfAbsListViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "AbsListViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfAbsListViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfAbsListViewClass::Get_E_onScroll()
{
    return NULL;
}
void ClassOfAbsListViewClass::Put_E_onScroll(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AbsListViewClass_onScroll,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAbsListViewClass::Get_E_onScrollStateChanged()
{
    return NULL;
}
void ClassOfAbsListViewClass::Put_E_onScrollStateChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AbsListViewClass_onScrollStateChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfAbsListViewClass::Get_E_onMovedToScrapHeap()
{
    return NULL;
}
void ClassOfAbsListViewClass::Put_E_onMovedToScrapHeap(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_AbsListViewClass_onMovedToScrapHeap,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfListViewClass::ClassOfListViewClass()
{
}

ClassOfListViewClass::ClassOfListViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ListViewClass,0,NULL));
}

ClassOfListViewClass::ClassOfListViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfListViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ListViewClass" );
    return Buf;
}

class ClassOfListViewClass *ClassOfListViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfListViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfListViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ListViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfListViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfGridViewClass::ClassOfGridViewClass()
{
}

ClassOfGridViewClass::ClassOfGridViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_GridViewClass,0,NULL));
}

ClassOfGridViewClass::ClassOfGridViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfGridViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "GridViewClass" );
    return Buf;
}

class ClassOfGridViewClass *ClassOfGridViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfGridViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfGridViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "GridViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfGridViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfByteArrayOutputStreamClass::ClassOfByteArrayOutputStreamClass()
{
}

ClassOfByteArrayOutputStreamClass::ClassOfByteArrayOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ByteArrayOutputStreamClass,0,NULL));
}

ClassOfByteArrayOutputStreamClass::ClassOfByteArrayOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfByteArrayOutputStreamClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ByteArrayOutputStreamClass" );
    return Buf;
}

class ClassOfByteArrayOutputStreamClass *ClassOfByteArrayOutputStreamClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfByteArrayOutputStreamClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfByteArrayOutputStreamClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ByteArrayOutputStreamClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfByteArrayOutputStreamClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfDisplayMetricsClass::ClassOfDisplayMetricsClass()
{
}

ClassOfDisplayMetricsClass::ClassOfDisplayMetricsClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DisplayMetricsClass,0,NULL));
}

ClassOfDisplayMetricsClass::ClassOfDisplayMetricsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDisplayMetricsClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DisplayMetricsClass" );
    return Buf;
}

class ClassOfDisplayMetricsClass *ClassOfDisplayMetricsClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDisplayMetricsClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDisplayMetricsClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DisplayMetricsClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDisplayMetricsClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfTelephonyManagerClass::ClassOfTelephonyManagerClass()
{
}

ClassOfTelephonyManagerClass::ClassOfTelephonyManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_TelephonyManagerClass,0,NULL));
}

ClassOfTelephonyManagerClass::ClassOfTelephonyManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfTelephonyManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "TelephonyManagerClass" );
    return Buf;
}

class ClassOfTelephonyManagerClass *ClassOfTelephonyManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfTelephonyManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfTelephonyManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "TelephonyManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfTelephonyManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onCallForwardingIndicatorChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onCallForwardingIndicatorChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onCallForwardingIndicatorChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onCallStateChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onCallStateChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onCallStateChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onCellLocationChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onCellLocationChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onCellLocationChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onDataActivity()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onDataActivity(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onDataActivity,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onDataConnectionStateChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onDataConnectionStateChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onDataConnectionStateChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onMessageWaitingIndicatorChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onMessageWaitingIndicatorChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onMessageWaitingIndicatorChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}

VSSystemEvent_EventProc ClassOfTelephonyManagerClass::Get_E_onSignalStrengthChanged()
{
    return NULL;
}
void ClassOfTelephonyManagerClass::Put_E_onSignalStrengthChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_TelephonyManagerClass_onSignalStrengthChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfCdmaCellLocationClass::ClassOfCdmaCellLocationClass()
{
}

ClassOfCdmaCellLocationClass::ClassOfCdmaCellLocationClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CdmaCellLocationClass,0,NULL));
}

ClassOfCdmaCellLocationClass::ClassOfCdmaCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCdmaCellLocationClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CdmaCellLocationClass" );
    return Buf;
}

class ClassOfCdmaCellLocationClass *ClassOfCdmaCellLocationClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCdmaCellLocationClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCdmaCellLocationClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CdmaCellLocationClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCdmaCellLocationClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfEditorClass::ClassOfEditorClass()
{
}

ClassOfEditorClass::ClassOfEditorClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_EditorClass,0,NULL));
}

ClassOfEditorClass::ClassOfEditorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfEditorClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "EditorClass" );
    return Buf;
}

class ClassOfEditorClass *ClassOfEditorClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfEditorClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfEditorClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "EditorClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfEditorClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfViewFactoryClass::ClassOfViewFactoryClass()
{
}

ClassOfViewFactoryClass::ClassOfViewFactoryClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ViewFactoryClass,0,NULL));
}

ClassOfViewFactoryClass::ClassOfViewFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfViewFactoryClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ViewFactoryClass" );
    return Buf;
}

class ClassOfViewFactoryClass *ClassOfViewFactoryClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfViewFactoryClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfViewFactoryClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ViewFactoryClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfViewFactoryClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfViewFactoryClass::Put_F_makeView(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_ViewFactoryClass_makeView,In_Value,NULL);
}
void * ClassOfViewFactoryClass::Get_F_makeView()
{
    return NULL;
}


VS_OBJPTR SRPAPI ClassOfViewFactoryClass::makeView()
{
    return (VS_OBJPTR )ThisSRPInterface -> Call(ThisSRPObject,"makeView");
}

ClassOfInputMethodManagerClass::ClassOfInputMethodManagerClass()
{
}

ClassOfInputMethodManagerClass::ClassOfInputMethodManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_InputMethodManagerClass,0,NULL));
}

ClassOfInputMethodManagerClass::ClassOfInputMethodManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfInputMethodManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "InputMethodManagerClass" );
    return Buf;
}

class ClassOfInputMethodManagerClass *ClassOfInputMethodManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfInputMethodManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfInputMethodManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "InputMethodManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfInputMethodManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRadialGradientClass::ClassOfRadialGradientClass()
{
}

ClassOfRadialGradientClass::ClassOfRadialGradientClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RadialGradientClass,0,NULL));
}

ClassOfRadialGradientClass::ClassOfRadialGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRadialGradientClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RadialGradientClass" );
    return Buf;
}

class ClassOfRadialGradientClass *ClassOfRadialGradientClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRadialGradientClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRadialGradientClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RadialGradientClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRadialGradientClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfStarSimpleAdapterClass::ClassOfStarSimpleAdapterClass()
{
}

ClassOfStarSimpleAdapterClass::ClassOfStarSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_StarSimpleAdapterClass,0,NULL));
}

ClassOfStarSimpleAdapterClass::ClassOfStarSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfStarSimpleAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "StarSimpleAdapterClass" );
    return Buf;
}

class ClassOfStarSimpleAdapterClass *ClassOfStarSimpleAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfStarSimpleAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfStarSimpleAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "StarSimpleAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfStarSimpleAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfWebViewClientClass::ClassOfWebViewClientClass()
{
}

ClassOfWebViewClientClass::ClassOfWebViewClientClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_WebViewClientClass,0,NULL));
}

ClassOfWebViewClientClass::ClassOfWebViewClientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfWebViewClientClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "WebViewClientClass" );
    return Buf;
}

class ClassOfWebViewClientClass *ClassOfWebViewClientClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfWebViewClientClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfWebViewClientClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "WebViewClientClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfWebViewClientClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfWebViewClientClass::Put_F_doUpdateVisitedHistory(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_doUpdateVisitedHistory,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_doUpdateVisitedHistory()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onLoadResource(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onLoadResource,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onLoadResource()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onPageFinished(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onPageFinished,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onPageFinished()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onPageStarted(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onPageStarted,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onPageStarted()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onReceivedError(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onReceivedError,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onReceivedError()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onReceivedLoginRequest(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onReceivedLoginRequest,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onReceivedLoginRequest()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onScaleChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onScaleChanged,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onScaleChanged()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_onUnhandledKeyEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_onUnhandledKeyEvent,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_onUnhandledKeyEvent()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_shouldOverrideKeyEvent(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_shouldOverrideKeyEvent,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_shouldOverrideKeyEvent()
{
    return NULL;
}

void ClassOfWebViewClientClass::Put_F_shouldOverrideUrlLoading(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_WebViewClientClass_shouldOverrideUrlLoading,In_Value,NULL);
}
void * ClassOfWebViewClientClass::Get_F_shouldOverrideUrlLoading()
{
    return NULL;
}


void SRPAPI ClassOfWebViewClientClass::doUpdateVisitedHistory(VS_OBJPTR view,VS_CHAR * url,VS_BOOL isReload)
{
    ThisSRPInterface -> Call(ThisSRPObject,"doUpdateVisitedHistory",view,url,isReload);
}
void SRPAPI ClassOfWebViewClientClass::onLoadResource(VS_OBJPTR view,VS_CHAR * url)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onLoadResource",view,url);
}
void SRPAPI ClassOfWebViewClientClass::onPageFinished(VS_OBJPTR view,VS_CHAR * url)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onPageFinished",view,url);
}
void SRPAPI ClassOfWebViewClientClass::onPageStarted(VS_OBJPTR view,VS_CHAR * url,VS_OBJPTR favicon)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onPageStarted",view,url,favicon);
}
void SRPAPI ClassOfWebViewClientClass::onReceivedError(VS_OBJPTR view,VS_INT32 errorCode,VS_CHAR * description,VS_CHAR * failingUrl)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onReceivedError",view,errorCode,description,failingUrl);
}
void SRPAPI ClassOfWebViewClientClass::onReceivedLoginRequest(VS_OBJPTR view,VS_CHAR * realm,VS_CHAR * account,VS_CHAR * args)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onReceivedLoginRequest",view,realm,account,args);
}
void SRPAPI ClassOfWebViewClientClass::onScaleChanged(VS_OBJPTR view,VS_FLOAT oldScale,VS_FLOAT newScale)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onScaleChanged",view,oldScale,newScale);
}
void SRPAPI ClassOfWebViewClientClass::onUnhandledKeyEvent(VS_OBJPTR view,VS_OBJPTR event)
{
    ThisSRPInterface -> Call(ThisSRPObject,"onUnhandledKeyEvent",view,event);
}
VS_BOOL SRPAPI ClassOfWebViewClientClass::shouldOverrideKeyEvent(VS_OBJPTR view,VS_OBJPTR event)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"shouldOverrideKeyEvent",view,event);
}
VS_BOOL SRPAPI ClassOfWebViewClientClass::shouldOverrideUrlLoading(VS_OBJPTR view,VS_CHAR * url)
{
    return (VS_BOOL )ThisSRPInterface -> Call(ThisSRPObject,"shouldOverrideUrlLoading",view,url);
}

ClassOfRectShapeClass::ClassOfRectShapeClass()
{
}

ClassOfRectShapeClass::ClassOfRectShapeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RectShapeClass,0,NULL));
}

ClassOfRectShapeClass::ClassOfRectShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRectShapeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RectShapeClass" );
    return Buf;
}

class ClassOfRectShapeClass *ClassOfRectShapeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRectShapeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRectShapeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RectShapeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRectShapeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfOvalShapeClass::ClassOfOvalShapeClass()
{
}

ClassOfOvalShapeClass::ClassOfOvalShapeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_OvalShapeClass,0,NULL));
}

ClassOfOvalShapeClass::ClassOfOvalShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfOvalShapeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "OvalShapeClass" );
    return Buf;
}

class ClassOfOvalShapeClass *ClassOfOvalShapeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfOvalShapeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfOvalShapeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "OvalShapeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfOvalShapeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfRoundRectShapeClass::ClassOfRoundRectShapeClass()
{
}

ClassOfRoundRectShapeClass::ClassOfRoundRectShapeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_RoundRectShapeClass,0,NULL));
}

ClassOfRoundRectShapeClass::ClassOfRoundRectShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfRoundRectShapeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "RoundRectShapeClass" );
    return Buf;
}

class ClassOfRoundRectShapeClass *ClassOfRoundRectShapeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfRoundRectShapeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfRoundRectShapeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "RoundRectShapeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfRoundRectShapeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfArcShapeClass::ClassOfArcShapeClass()
{
}

ClassOfArcShapeClass::ClassOfArcShapeClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ArcShapeClass,0,NULL));
}

ClassOfArcShapeClass::ClassOfArcShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfArcShapeClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ArcShapeClass" );
    return Buf;
}

class ClassOfArcShapeClass *ClassOfArcShapeClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfArcShapeClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfArcShapeClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ArcShapeClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfArcShapeClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfBundleClass::ClassOfBundleClass()
{
}

ClassOfBundleClass::ClassOfBundleClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_BundleClass,0,NULL));
}

ClassOfBundleClass::ClassOfBundleClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfBundleClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "BundleClass" );
    return Buf;
}

class ClassOfBundleClass *ClassOfBundleClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfBundleClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfBundleClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "BundleClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfBundleClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfStringHashMapClass::ClassOfStringHashMapClass()
{
}

ClassOfStringHashMapClass::ClassOfStringHashMapClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_StringHashMapClass,0,NULL));
}

ClassOfStringHashMapClass::ClassOfStringHashMapClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfStringHashMapClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "StringHashMapClass" );
    return Buf;
}

class ClassOfStringHashMapClass *ClassOfStringHashMapClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfStringHashMapClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfStringHashMapClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "StringHashMapClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfStringHashMapClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfLinearGradientClass::ClassOfLinearGradientClass()
{
}

ClassOfLinearGradientClass::ClassOfLinearGradientClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_LinearGradientClass,0,NULL));
}

ClassOfLinearGradientClass::ClassOfLinearGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfLinearGradientClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "LinearGradientClass" );
    return Buf;
}

class ClassOfLinearGradientClass *ClassOfLinearGradientClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfLinearGradientClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfLinearGradientClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "LinearGradientClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfLinearGradientClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfWebViewClass::ClassOfWebViewClass()
{
}

ClassOfWebViewClass::ClassOfWebViewClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_WebViewClass,0,NULL));
}

ClassOfWebViewClass::ClassOfWebViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfWebViewClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "WebViewClass" );
    return Buf;
}

class ClassOfWebViewClass *ClassOfWebViewClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfWebViewClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfWebViewClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "WebViewClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfWebViewClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

VSSystemEvent_EventProc ClassOfWebViewClass::Get_E_onProgressChanged()
{
    return NULL;
}
void ClassOfWebViewClass::Put_E_onProgressChanged(VSSystemEvent_EventProc In_Value)
{
    ThisSRPInterface -> RegEventFunction(ThisSRPObject,&VSOUTEVENTID_WebViewClass_onProgressChanged,ThisSRPObject,(void *)In_Value,(VS_ULONG)this);
}



ClassOfCommonDataKinds_EmailClass::ClassOfCommonDataKinds_EmailClass()
{
}

ClassOfCommonDataKinds_EmailClass::ClassOfCommonDataKinds_EmailClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CommonDataKinds_EmailClass,0,NULL));
}

ClassOfCommonDataKinds_EmailClass::ClassOfCommonDataKinds_EmailClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCommonDataKinds_EmailClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CommonDataKinds_EmailClass" );
    return Buf;
}

class ClassOfCommonDataKinds_EmailClass *ClassOfCommonDataKinds_EmailClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCommonDataKinds_EmailClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCommonDataKinds_EmailClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CommonDataKinds_EmailClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCommonDataKinds_EmailClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfCanvasClass::ClassOfCanvasClass()
{
}

ClassOfCanvasClass::ClassOfCanvasClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_CanvasClass,0,NULL));
}

ClassOfCanvasClass::ClassOfCanvasClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfCanvasClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "CanvasClass" );
    return Buf;
}

class ClassOfCanvasClass *ClassOfCanvasClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfCanvasClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfCanvasClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "CanvasClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfCanvasClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfDataSetObserverClass::ClassOfDataSetObserverClass()
{
}

ClassOfDataSetObserverClass::ClassOfDataSetObserverClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_DataSetObserverClass,0,NULL));
}

ClassOfDataSetObserverClass::ClassOfDataSetObserverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfDataSetObserverClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "DataSetObserverClass" );
    return Buf;
}

class ClassOfDataSetObserverClass *ClassOfDataSetObserverClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfDataSetObserverClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfDataSetObserverClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "DataSetObserverClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfDataSetObserverClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}

void ClassOfDataSetObserverClass::Put_F_onChanged(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_DataSetObserverClass_onChanged,In_Value,NULL);
}
void * ClassOfDataSetObserverClass::Get_F_onChanged()
{
    return NULL;
}

void ClassOfDataSetObserverClass::Put_F_onInvalidated(void * In_Value)
{
    ThisSRPInterface -> CreateOVLFunction(ThisSRPObject,&VSFUNCID_DataSetObserverClass_onInvalidated,In_Value,NULL);
}
void * ClassOfDataSetObserverClass::Get_F_onInvalidated()
{
    return NULL;
}


void SRPAPI ClassOfDataSetObserverClass::onChanged()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onChanged");
}
void SRPAPI ClassOfDataSetObserverClass::onInvalidated()
{
    ThisSRPInterface -> Call(ThisSRPObject,"onInvalidated");
}

ClassOfResourceCursorAdapterClass::ClassOfResourceCursorAdapterClass()
{
}

ClassOfResourceCursorAdapterClass::ClassOfResourceCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ResourceCursorAdapterClass,0,NULL));
}

ClassOfResourceCursorAdapterClass::ClassOfResourceCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfResourceCursorAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ResourceCursorAdapterClass" );
    return Buf;
}

class ClassOfResourceCursorAdapterClass *ClassOfResourceCursorAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfResourceCursorAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfResourceCursorAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ResourceCursorAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfResourceCursorAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfSimpleCursorAdapterClass::ClassOfSimpleCursorAdapterClass()
{
}

ClassOfSimpleCursorAdapterClass::ClassOfSimpleCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_SimpleCursorAdapterClass,0,NULL));
}

ClassOfSimpleCursorAdapterClass::ClassOfSimpleCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfSimpleCursorAdapterClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "SimpleCursorAdapterClass" );
    return Buf;
}

class ClassOfSimpleCursorAdapterClass *ClassOfSimpleCursorAdapterClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfSimpleCursorAdapterClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfSimpleCursorAdapterClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "SimpleCursorAdapterClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfSimpleCursorAdapterClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfIBinderClass::ClassOfIBinderClass()
{
}

ClassOfIBinderClass::ClassOfIBinderClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_IBinderClass,0,NULL));
}

ClassOfIBinderClass::ClassOfIBinderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfIBinderClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "IBinderClass" );
    return Buf;
}

class ClassOfIBinderClass *ClassOfIBinderClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfIBinderClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfIBinderClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "IBinderClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfIBinderClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfConnectivityManagerClass::ClassOfConnectivityManagerClass()
{
}

ClassOfConnectivityManagerClass::ClassOfConnectivityManagerClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ConnectivityManagerClass,0,NULL));
}

ClassOfConnectivityManagerClass::ClassOfConnectivityManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfConnectivityManagerClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ConnectivityManagerClass" );
    return Buf;
}

class ClassOfConnectivityManagerClass *ClassOfConnectivityManagerClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfConnectivityManagerClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfConnectivityManagerClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ConnectivityManagerClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfConnectivityManagerClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


ClassOfContentValuesClass::ClassOfContentValuesClass()
{
}

ClassOfContentValuesClass::ClassOfContentValuesClass(class ClassOfSRPInterface *In_SRPInterface)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_TRUE,VS_FALSE,In_SRPInterface -> MallocObjectL(&VSOBJID_ContentValuesClass,0,NULL));
}

ClassOfContentValuesClass::ClassOfContentValuesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject)
{
    if( In_SRPInterface == NULL )
        return;
    WrapObject(In_SRPInterface,VS_FALSE,VS_FALSE,SRPObject);
}

VS_CHAR *ClassOfContentValuesClass::GetSelfName()
{
    static VS_CHAR Buf[64];
    strcpy( Buf, "ContentValuesClass" );
    return Buf;
}

class ClassOfContentValuesClass *ClassOfContentValuesClass::GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer)
{
    class ClassOfContentValuesClass *ClassObject;

    if( SRPObject == NULL || In_SRPInterface == NULL )
        return NULL;
    if( In_ClassLayer == 0xFFFFFFFF )
        In_ClassLayer = In_SRPInterface -> GetLayer( SRPObject );
    ClassObject = (class ClassOfContentValuesClass *)In_SRPInterface -> GetAppClass( SRPObject, In_ClassLayer );
    if( ClassObject != NULL && strcmp( ((class ClassOfSRPObject *)ClassObject) -> GetSelfName(), "ContentValuesClass" ) == 0 )
        return ClassObject;
    ClassObject = new class ClassOfContentValuesClass();
    ClassObject -> WrapObject(In_SRPInterface,VS_FALSE,VS_TRUE,SRPObject, In_ClassLayer);
    return ClassObject;
}


/*--------------------------------------------------*/

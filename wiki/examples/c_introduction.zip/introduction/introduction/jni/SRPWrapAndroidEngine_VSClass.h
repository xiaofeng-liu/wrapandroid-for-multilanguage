/*--------------------------------------------------*/
/*VirtualSociety System ServiceModuleTemplate Class Header File*/
/*CreateBy SRPLab                */
/*CreateDate: 2012-5-29  */
/*--------------------------------------------------*/
#ifndef SRPWRAPANDROIDENGINE_CLASSHEADERFILE
#define SRPWRAPANDROIDENGINE_CLASSHEADERFILE

#define _INCLUDE_STARLIB
#include "SRPWrapAndroidEngine_VSDHeader.h"

#if( VS_OS_TYPE == VS_OS_WINDOWS )
#pragma warning (disable:4819)
#pragma warning (disable:4244)
#pragma warning (disable:4996)
#pragma warning (disable:4800)
#endif

#pragma pack(4)

class ClassOfRectClass:public ClassOfSRPObject{
public:
    ClassOfRectClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRectClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRectClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRectClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--Attribute Get/Put Function Define
    VS_INT32 Get_left();
    void Put_left(VS_INT32 In_Value);

    VS_INT32 Get_top();
    void Put_top(VS_INT32 In_Value);

    VS_INT32 Get_right();
    void Put_right(VS_INT32 In_Value);

    VS_INT32 Get_bottom();
    void Put_bottom(VS_INT32 In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--Attribute Property Define
    __declspec(property(get=Get_left, put=Put_left)) VS_INT32 left;
    __declspec(property(get=Get_top, put=Put_top)) VS_INT32 top;
    __declspec(property(get=Get_right, put=Put_right)) VS_INT32 right;
    __declspec(property(get=Get_bottom, put=Put_bottom)) VS_INT32 bottom;
#endif

};

class ClassOfAndroidConstantClass:public ClassOfSRPObject{
public:
    ClassOfAndroidConstantClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAndroidConstantClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAndroidConstantClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAndroidConstantClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAndroidBaseClass:public ClassOfSRPObject{
public:
    ClassOfAndroidBaseClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAndroidBaseClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAndroidBaseClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAndroidBaseClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--Attribute Get/Put Function Define
    VS_INT32 Get_AndroidRefCount();
    void Put_AndroidRefCount(VS_INT32 In_Value);


public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onSetEventListener();
    void Put_E_onSetEventListener(VSSystemEvent_EventProc In_Value);


public:
    //--PubFunction Get/Put Function Define
    void Put_F_onDownPreExecute(void * In_Value);
    void * Get_F_onDownPreExecute();

    void Put_F_onDownProgressUpdate(void * In_Value);
    void * Get_F_onDownProgressUpdate();

    void Put_F_onDownPostExecute(void * In_Value);
    void * Get_F_onDownPostExecute();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--Attribute Property Define
    __declspec(property(get=Get_AndroidRefCount, put=Put_AndroidRefCount)) VS_INT32 AndroidRefCount;
#endif

#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onSetEventListener, put=Put_E_onSetEventListener)) VSSystemEvent_EventProc E_onSetEventListener;
#endif

#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onDownPreExecute, put=Put_F_onDownPreExecute)) void * F_onDownPreExecute;
    __declspec(property(get=Get_F_onDownProgressUpdate, put=Put_F_onDownProgressUpdate)) void * F_onDownProgressUpdate;
    __declspec(property(get=Get_F_onDownPostExecute, put=Put_F_onDownPostExecute)) void * F_onDownPostExecute;
#endif

public:
    //--Function Define
    void SRPAPI onDownPreExecute(VS_INT32 downloadId,VS_CHAR * url,VS_CHAR * fileName);
    void SRPAPI onDownProgressUpdate(VS_INT32 downloadId,VS_INT32 downloadSize,VS_INT32 maxSize);
    void SRPAPI onDownPostExecute(VS_INT32 downloadId,VS_INT32 result,VS_INT32 maxDownloadSize,VS_CHAR * fileName,VS_BINBUFPTR binbuf);
};

class ClassOfViewClass:public ClassOfAndroidBaseClass{
public:
    ClassOfViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onClick();
    void Put_E_onClick(VSSystemEvent_EventProc In_Value);


public:
    //--PubFunction Get/Put Function Define
    void Put_F_onDraw(void * In_Value);
    void * Get_F_onDraw();

    void Put_F_onTouchEvent(void * In_Value);
    void * Get_F_onTouchEvent();

    void Put_F_onLayout(void * In_Value);
    void * Get_F_onLayout();

    void Put_F_onMeasure(void * In_Value);
    void * Get_F_onMeasure();

    void Put_F_onSizeChanged(void * In_Value);
    void * Get_F_onSizeChanged();

    void Put_F_onKeyDown(void * In_Value);
    void * Get_F_onKeyDown();

    void Put_F_onKeyLongPress(void * In_Value);
    void * Get_F_onKeyLongPress();

    void Put_F_onKeyMultiple(void * In_Value);
    void * Get_F_onKeyMultiple();

    void Put_F_onKeyUp(void * In_Value);
    void * Get_F_onKeyUp();

    void Put_F_onKey(void * In_Value);
    void * Get_F_onKey();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onClick, put=Put_E_onClick)) VSSystemEvent_EventProc E_onClick;
#endif

#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onDraw, put=Put_F_onDraw)) void * F_onDraw;
    __declspec(property(get=Get_F_onTouchEvent, put=Put_F_onTouchEvent)) void * F_onTouchEvent;
    __declspec(property(get=Get_F_onLayout, put=Put_F_onLayout)) void * F_onLayout;
    __declspec(property(get=Get_F_onMeasure, put=Put_F_onMeasure)) void * F_onMeasure;
    __declspec(property(get=Get_F_onSizeChanged, put=Put_F_onSizeChanged)) void * F_onSizeChanged;
    __declspec(property(get=Get_F_onKeyDown, put=Put_F_onKeyDown)) void * F_onKeyDown;
    __declspec(property(get=Get_F_onKeyLongPress, put=Put_F_onKeyLongPress)) void * F_onKeyLongPress;
    __declspec(property(get=Get_F_onKeyMultiple, put=Put_F_onKeyMultiple)) void * F_onKeyMultiple;
    __declspec(property(get=Get_F_onKeyUp, put=Put_F_onKeyUp)) void * F_onKeyUp;
    __declspec(property(get=Get_F_onKey, put=Put_F_onKey)) void * F_onKey;
#endif

public:
    //--Function Define
    void SRPAPI onDraw(VS_OBJPTR canvas);
    VS_BOOL SRPAPI onTouchEvent(VS_OBJPTR event);
    void SRPAPI onLayout(VS_BOOL changed,VS_INT32 left,VS_INT32 top,VS_INT32 right,VS_INT32 bottom);
    void SRPAPI onMeasure(VS_INT32 widthMeasureSpec,VS_INT32 heightMeasureSpec);
    void SRPAPI onSizeChanged(VS_INT32 w,VS_INT32 h,VS_INT32 oldw,VS_INT32 oldh);
    VS_BOOL SRPAPI onKeyDown(VS_INT32 keyCode,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyLongPress(VS_INT32 keyCode,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyMultiple(VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyUp(VS_INT32 keyCode,VS_OBJPTR event);
    void SRPAPI onKey(VS_INT32 keyCode,VS_OBJPTR event);
};

class ClassOfProgressBarClass:public ClassOfViewClass{
public:
    ClassOfProgressBarClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfProgressBarClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfProgressBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfProgressBarClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSurfaceViewClass:public ClassOfViewClass{
public:
    ClassOfSurfaceViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSurfaceViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSurfaceViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSurfaceViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_surfaceChanged(void * In_Value);
    void * Get_F_surfaceChanged();

    void Put_F_surfaceCreated(void * In_Value);
    void * Get_F_surfaceCreated();

    void Put_F_surfaceDestroyed(void * In_Value);
    void * Get_F_surfaceDestroyed();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_surfaceChanged, put=Put_F_surfaceChanged)) void * F_surfaceChanged;
    __declspec(property(get=Get_F_surfaceCreated, put=Put_F_surfaceCreated)) void * F_surfaceCreated;
    __declspec(property(get=Get_F_surfaceDestroyed, put=Put_F_surfaceDestroyed)) void * F_surfaceDestroyed;
#endif

public:
    //--Function Define
    void SRPAPI surfaceChanged(VS_INT32 format,VS_INT32 width,VS_INT32 height);
    void SRPAPI surfaceCreated();
    void SRPAPI surfaceDestroyed();
};

class ClassOfAnalogClockClass:public ClassOfViewClass{
public:
    ClassOfAnalogClockClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAnalogClockClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAnalogClockClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAnalogClockClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfObjectBaseClass:public ClassOfAndroidBaseClass{
public:
    ClassOfObjectBaseClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfObjectBaseClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfObjectBaseClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfObjectBaseClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfViewGroup_LayoutParamsClass:public ClassOfObjectBaseClass{
public:
    ClassOfViewGroup_LayoutParamsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewGroup_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewGroup_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewGroup_LayoutParamsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMenuClass:public ClassOfObjectBaseClass{
public:
    ClassOfMenuClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMenuClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMenuClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAnimationClass:public ClassOfObjectBaseClass{
public:
    ClassOfAnimationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAnimationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAnimationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAnimationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfContactsContract_ContactsClass:public ClassOfObjectBaseClass{
public:
    ClassOfContactsContract_ContactsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContactsContract_ContactsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContactsContract_ContactsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContactsContract_ContactsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfPaintClass:public ClassOfObjectBaseClass{
public:
    ClassOfPaintClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfPaintClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfPaintClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfPaintClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfToastClass:public ClassOfObjectBaseClass{
public:
    ClassOfToastClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfToastClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfToastClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfToastClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfWindowManager_LayoutParamsClass:public ClassOfViewGroup_LayoutParamsClass{
public:
    ClassOfWindowManager_LayoutParamsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfWindowManager_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfWindowManager_LayoutParamsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfWindowManager_LayoutParamsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMatrixClass:public ClassOfObjectBaseClass{
public:
    ClassOfMatrixClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMatrixClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMatrixClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMatrixClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfContextMenuClass:public ClassOfMenuClass{
public:
    ClassOfContextMenuClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContextMenuClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContextMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContextMenuClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfContactsContract_PhoneLookupClass:public ClassOfObjectBaseClass{
public:
    ClassOfContactsContract_PhoneLookupClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContactsContract_PhoneLookupClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContactsContract_PhoneLookupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContactsContract_PhoneLookupClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMenuItemClass:public ClassOfObjectBaseClass{
public:
    ClassOfMenuItemClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMenuItemClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMenuItemClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMenuItemClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfIntentFilterClass:public ClassOfObjectBaseClass{
public:
    ClassOfIntentFilterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfIntentFilterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfIntentFilterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfIntentFilterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfShapeClass:public ClassOfObjectBaseClass{
public:
    ClassOfShapeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfShapeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfShapeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfGestureDetectorClass:public ClassOfObjectBaseClass{
public:
    ClassOfGestureDetectorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfGestureDetectorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfGestureDetectorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfGestureDetectorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onDown();
    void Put_E_onDown(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onFling();
    void Put_E_onFling(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onLongPress();
    void Put_E_onLongPress(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onScroll();
    void Put_E_onScroll(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onShowPress();
    void Put_E_onShowPress(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onSingleTapUp();
    void Put_E_onSingleTapUp(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDoubleTap();
    void Put_E_onDoubleTap(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDoubleTapEvent();
    void Put_E_onDoubleTapEvent(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onSingleTapConfirmed();
    void Put_E_onSingleTapConfirmed(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onDown, put=Put_E_onDown)) VSSystemEvent_EventProc E_onDown;
    __declspec(property(get=Get_E_onFling, put=Put_E_onFling)) VSSystemEvent_EventProc E_onFling;
    __declspec(property(get=Get_E_onLongPress, put=Put_E_onLongPress)) VSSystemEvent_EventProc E_onLongPress;
    __declspec(property(get=Get_E_onScroll, put=Put_E_onScroll)) VSSystemEvent_EventProc E_onScroll;
    __declspec(property(get=Get_E_onShowPress, put=Put_E_onShowPress)) VSSystemEvent_EventProc E_onShowPress;
    __declspec(property(get=Get_E_onSingleTapUp, put=Put_E_onSingleTapUp)) VSSystemEvent_EventProc E_onSingleTapUp;
    __declspec(property(get=Get_E_onDoubleTap, put=Put_E_onDoubleTap)) VSSystemEvent_EventProc E_onDoubleTap;
    __declspec(property(get=Get_E_onDoubleTapEvent, put=Put_E_onDoubleTapEvent)) VSSystemEvent_EventProc E_onDoubleTapEvent;
    __declspec(property(get=Get_E_onSingleTapConfirmed, put=Put_E_onSingleTapConfirmed)) VSSystemEvent_EventProc E_onSingleTapConfirmed;
#endif

};

class ClassOfInputStreamClass:public ClassOfObjectBaseClass{
public:
    ClassOfInputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfInputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfInputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCommonDataKinds_PhoneClass:public ClassOfObjectBaseClass{
public:
    ClassOfCommonDataKinds_PhoneClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCommonDataKinds_PhoneClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCommonDataKinds_PhoneClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCommonDataKinds_PhoneClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTypefaceClass:public ClassOfObjectBaseClass{
public:
    ClassOfTypefaceClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTypefaceClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTypefaceClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTypefaceClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfNotificationManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfNotificationManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfNotificationManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfNotificationManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfNotificationManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAssetManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfAssetManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAssetManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAssetManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAssetManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfConfigurationClass:public ClassOfObjectBaseClass{
public:
    ClassOfConfigurationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfConfigurationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfConfigurationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfConfigurationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAlertDialog_BuilderClass:public ClassOfObjectBaseClass{
public:
    ClassOfAlertDialog_BuilderClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAlertDialog_BuilderClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAlertDialog_BuilderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAlertDialog_BuilderClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onKey();
    void Put_E_onKey(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onCancel();
    void Put_E_onCancel(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onMultiChoiceClick();
    void Put_E_onMultiChoiceClick(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDismiss();
    void Put_E_onDismiss(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onShow();
    void Put_E_onShow(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onClick();
    void Put_E_onClick(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onKey, put=Put_E_onKey)) VSSystemEvent_EventProc E_onKey;
    __declspec(property(get=Get_E_onCancel, put=Put_E_onCancel)) VSSystemEvent_EventProc E_onCancel;
    __declspec(property(get=Get_E_onMultiChoiceClick, put=Put_E_onMultiChoiceClick)) VSSystemEvent_EventProc E_onMultiChoiceClick;
    __declspec(property(get=Get_E_onDismiss, put=Put_E_onDismiss)) VSSystemEvent_EventProc E_onDismiss;
    __declspec(property(get=Get_E_onShow, put=Put_E_onShow)) VSSystemEvent_EventProc E_onShow;
    __declspec(property(get=Get_E_onClick, put=Put_E_onClick)) VSSystemEvent_EventProc E_onClick;
#endif

};

class ClassOfShaderClass:public ClassOfObjectBaseClass{
public:
    ClassOfShaderClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfShaderClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfShaderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfShaderClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfActivityClass:public ClassOfAndroidBaseClass{
public:
    ClassOfActivityClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfActivityClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfActivityClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfActivityClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onStart(void * In_Value);
    void * Get_F_onStart();

    void Put_F_onRestart(void * In_Value);
    void * Get_F_onRestart();

    void Put_F_onStop(void * In_Value);
    void * Get_F_onStop();

    void Put_F_onSaveInstanceState(void * In_Value);
    void * Get_F_onSaveInstanceState();

    void Put_F_onRestoreInstanceState(void * In_Value);
    void * Get_F_onRestoreInstanceState();

    void Put_F_onPause(void * In_Value);
    void * Get_F_onPause();

    void Put_F_onResume(void * In_Value);
    void * Get_F_onResume();

    void Put_F_onDestroy(void * In_Value);
    void * Get_F_onDestroy();

    void Put_F_onCreateDialog(void * In_Value);
    void * Get_F_onCreateDialog();

    void Put_F_onCreateDialog1(void * In_Value);
    void * Get_F_onCreateDialog1();

    void Put_F_onPrepareDialog(void * In_Value);
    void * Get_F_onPrepareDialog();

    void Put_F_onPrepareDialog1(void * In_Value);
    void * Get_F_onPrepareDialog1();

    void Put_F_onActivityResult(void * In_Value);
    void * Get_F_onActivityResult();

    void Put_F_onTouchEvent(void * In_Value);
    void * Get_F_onTouchEvent();

    void Put_F_onCreateOptionsMenu(void * In_Value);
    void * Get_F_onCreateOptionsMenu();

    void Put_F_onPrepareOptionsMenu(void * In_Value);
    void * Get_F_onPrepareOptionsMenu();

    void Put_F_onOptionsItemSelected(void * In_Value);
    void * Get_F_onOptionsItemSelected();

    void Put_F_onCreateContextMenu(void * In_Value);
    void * Get_F_onCreateContextMenu();

    void Put_F_onContextItemSelected(void * In_Value);
    void * Get_F_onContextItemSelected();

    void Put_F_onKeyDown(void * In_Value);
    void * Get_F_onKeyDown();

    void Put_F_onKeyLongPress(void * In_Value);
    void * Get_F_onKeyLongPress();

    void Put_F_onKeyMultiple(void * In_Value);
    void * Get_F_onKeyMultiple();

    void Put_F_onKeyUp(void * In_Value);
    void * Get_F_onKeyUp();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onStart, put=Put_F_onStart)) void * F_onStart;
    __declspec(property(get=Get_F_onRestart, put=Put_F_onRestart)) void * F_onRestart;
    __declspec(property(get=Get_F_onStop, put=Put_F_onStop)) void * F_onStop;
    __declspec(property(get=Get_F_onSaveInstanceState, put=Put_F_onSaveInstanceState)) void * F_onSaveInstanceState;
    __declspec(property(get=Get_F_onRestoreInstanceState, put=Put_F_onRestoreInstanceState)) void * F_onRestoreInstanceState;
    __declspec(property(get=Get_F_onPause, put=Put_F_onPause)) void * F_onPause;
    __declspec(property(get=Get_F_onResume, put=Put_F_onResume)) void * F_onResume;
    __declspec(property(get=Get_F_onDestroy, put=Put_F_onDestroy)) void * F_onDestroy;
    __declspec(property(get=Get_F_onCreateDialog, put=Put_F_onCreateDialog)) void * F_onCreateDialog;
    __declspec(property(get=Get_F_onCreateDialog1, put=Put_F_onCreateDialog1)) void * F_onCreateDialog1;
    __declspec(property(get=Get_F_onPrepareDialog, put=Put_F_onPrepareDialog)) void * F_onPrepareDialog;
    __declspec(property(get=Get_F_onPrepareDialog1, put=Put_F_onPrepareDialog1)) void * F_onPrepareDialog1;
    __declspec(property(get=Get_F_onActivityResult, put=Put_F_onActivityResult)) void * F_onActivityResult;
    __declspec(property(get=Get_F_onTouchEvent, put=Put_F_onTouchEvent)) void * F_onTouchEvent;
    __declspec(property(get=Get_F_onCreateOptionsMenu, put=Put_F_onCreateOptionsMenu)) void * F_onCreateOptionsMenu;
    __declspec(property(get=Get_F_onPrepareOptionsMenu, put=Put_F_onPrepareOptionsMenu)) void * F_onPrepareOptionsMenu;
    __declspec(property(get=Get_F_onOptionsItemSelected, put=Put_F_onOptionsItemSelected)) void * F_onOptionsItemSelected;
    __declspec(property(get=Get_F_onCreateContextMenu, put=Put_F_onCreateContextMenu)) void * F_onCreateContextMenu;
    __declspec(property(get=Get_F_onContextItemSelected, put=Put_F_onContextItemSelected)) void * F_onContextItemSelected;
    __declspec(property(get=Get_F_onKeyDown, put=Put_F_onKeyDown)) void * F_onKeyDown;
    __declspec(property(get=Get_F_onKeyLongPress, put=Put_F_onKeyLongPress)) void * F_onKeyLongPress;
    __declspec(property(get=Get_F_onKeyMultiple, put=Put_F_onKeyMultiple)) void * F_onKeyMultiple;
    __declspec(property(get=Get_F_onKeyUp, put=Put_F_onKeyUp)) void * F_onKeyUp;
#endif

public:
    //--Function Define
    void SRPAPI onStart();
    void SRPAPI onRestart();
    void SRPAPI onStop();
    void SRPAPI onSaveInstanceState(VS_OBJPTR savedInstanceState);
    void SRPAPI onRestoreInstanceState(VS_OBJPTR savedInstanceState);
    void SRPAPI onPause();
    void SRPAPI onResume();
    void SRPAPI onDestroy();
    VS_OBJPTR SRPAPI onCreateDialog(VS_INT32 id);
    VS_OBJPTR SRPAPI onCreateDialog1(VS_INT32 id,VS_OBJPTR args);
    VS_BOOL SRPAPI onPrepareDialog(VS_INT32 id,VS_OBJPTR dialog);
    VS_BOOL SRPAPI onPrepareDialog1(VS_INT32 id,VS_OBJPTR dialog,VS_OBJPTR args);
    void SRPAPI onActivityResult(VS_INT32 requestCode,VS_INT32 resultCode,VS_OBJPTR data);
    VS_BOOL SRPAPI onTouchEvent(VS_OBJPTR event);
    VS_BOOL SRPAPI onCreateOptionsMenu(VS_OBJPTR menu);
    VS_BOOL SRPAPI onPrepareOptionsMenu(VS_OBJPTR menu);
    VS_BOOL SRPAPI onOptionsItemSelected(VS_OBJPTR item);
    void SRPAPI onCreateContextMenu(VS_OBJPTR menu,VS_OBJPTR v);
    void SRPAPI onContextItemSelected(VS_OBJPTR item);
    VS_BOOL SRPAPI onKeyDown(VS_INT32 keyCode,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyLongPress(VS_INT32 keyCode,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyMultiple(VS_INT32 keyCode,VS_INT32 repeatCount,VS_OBJPTR event);
    VS_BOOL SRPAPI onKeyUp(VS_INT32 keyCode,VS_OBJPTR event);
};

class ClassOfListActivityClass:public ClassOfActivityClass{
public:
    ClassOfListActivityClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfListActivityClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfListActivityClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfListActivityClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onListItemClick(void * In_Value);
    void * Get_F_onListItemClick();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onListItemClick, put=Put_F_onListItemClick)) void * F_onListItemClick;
#endif

public:
    //--Function Define
    VS_BOOL SRPAPI onListItemClick(VS_OBJPTR l,VS_OBJPTR v,VS_INT32 position,VS_LONG id);
};

class ClassOfXmlPullParserClass:public ClassOfObjectBaseClass{
public:
    ClassOfXmlPullParserClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfXmlPullParserClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfXmlPullParserClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfXmlPullParserClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfXmlResourceParserClass:public ClassOfXmlPullParserClass{
public:
    ClassOfXmlResourceParserClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfXmlResourceParserClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfXmlResourceParserClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfXmlResourceParserClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfIntentClass:public ClassOfObjectBaseClass{
public:
    ClassOfIntentClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfIntentClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfIntentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfIntentClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfNetworkInfoClass:public ClassOfObjectBaseClass{
public:
    ClassOfNetworkInfoClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfNetworkInfoClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfNetworkInfoClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfNetworkInfoClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfInputEventClass:public ClassOfObjectBaseClass{
public:
    ClassOfInputEventClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfInputEventClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfInputEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfInputEventClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAdapterClass:public ClassOfObjectBaseClass{
public:
    ClassOfAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_getCount(void * In_Value);
    void * Get_F_getCount();

    void Put_F_getItem(void * In_Value);
    void * Get_F_getItem();

    void Put_F_getItemId(void * In_Value);
    void * Get_F_getItemId();

    void Put_F_getViewTypeCount(void * In_Value);
    void * Get_F_getViewTypeCount();

    void Put_F_getItemViewType(void * In_Value);
    void * Get_F_getItemViewType();

    void Put_F_getView(void * In_Value);
    void * Get_F_getView();

    void Put_F_isEmpty(void * In_Value);
    void * Get_F_isEmpty();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_getCount, put=Put_F_getCount)) void * F_getCount;
    __declspec(property(get=Get_F_getItem, put=Put_F_getItem)) void * F_getItem;
    __declspec(property(get=Get_F_getItemId, put=Put_F_getItemId)) void * F_getItemId;
    __declspec(property(get=Get_F_getViewTypeCount, put=Put_F_getViewTypeCount)) void * F_getViewTypeCount;
    __declspec(property(get=Get_F_getItemViewType, put=Put_F_getItemViewType)) void * F_getItemViewType;
    __declspec(property(get=Get_F_getView, put=Put_F_getView)) void * F_getView;
    __declspec(property(get=Get_F_isEmpty, put=Put_F_isEmpty)) void * F_isEmpty;
#endif

public:
    //--Function Define
    VS_INT32 SRPAPI getCount();
    VS_INT32 SRPAPI getItem(VS_INT32 position);
    VS_LONG SRPAPI getItemId(VS_INT32 position);
    VS_INT32 SRPAPI getViewTypeCount();
    VS_INT32 SRPAPI getItemViewType(VS_INT32 position);
    VS_OBJPTR SRPAPI getView(VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);
    VS_BOOL SRPAPI isEmpty();
};

class ClassOfTabSpecClass:public ClassOfObjectBaseClass{
public:
    ClassOfTabSpecClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTabSpecClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTabSpecClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTabSpecClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfBitmapShaderClass:public ClassOfShaderClass{
public:
    ClassOfBitmapShaderClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBitmapShaderClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBitmapShaderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBitmapShaderClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfBroadcastReceiverClass:public ClassOfObjectBaseClass{
public:
    ClassOfBroadcastReceiverClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBroadcastReceiverClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBroadcastReceiverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBroadcastReceiverClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onReceive(void * In_Value);
    void * Get_F_onReceive();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onReceive, put=Put_F_onReceive)) void * F_onReceive;
#endif

public:
    //--Function Define
    void SRPAPI onReceive(VS_OBJPTR intent);
};

class ClassOfFileDescriptorClass:public ClassOfObjectBaseClass{
public:
    ClassOfFileDescriptorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfFileDescriptorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRemoteViewsClass:public ClassOfObjectBaseClass{
public:
    ClassOfRemoteViewsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRemoteViewsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRemoteViewsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRemoteViewsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTabContentFactoryClass:public ClassOfObjectBaseClass{
public:
    ClassOfTabContentFactoryClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTabContentFactoryClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTabContentFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTabContentFactoryClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_createTabContent(void * In_Value);
    void * Get_F_createTabContent();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_createTabContent, put=Put_F_createTabContent)) void * F_createTabContent;
#endif

public:
    //--Function Define
    VS_OBJPTR SRPAPI createTabContent(VS_CHAR * tag);
};

class ClassOfBitmapClass:public ClassOfObjectBaseClass{
public:
    ClassOfBitmapClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBitmapClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBitmapClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBitmapClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSensorEventClass:public ClassOfObjectBaseClass{
public:
    ClassOfSensorEventClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSensorEventClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSensorEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSensorEventClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCellLocationClass:public ClassOfObjectBaseClass{
public:
    ClassOfCellLocationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCellLocationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCellLocationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfGsmCellLocationClass:public ClassOfCellLocationClass{
public:
    ClassOfGsmCellLocationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfGsmCellLocationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfGsmCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfGsmCellLocationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfFileClass:public ClassOfObjectBaseClass{
public:
    ClassOfFileClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfFileClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfFileClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfFileClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMediaRecorderClass:public ClassOfObjectBaseClass{
public:
    ClassOfMediaRecorderClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMediaRecorderClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMediaRecorderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMediaRecorderClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onError();
    void Put_E_onError(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onInfo();
    void Put_E_onInfo(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onError, put=Put_E_onError)) VSSystemEvent_EventProc E_onError;
    __declspec(property(get=Get_E_onInfo, put=Put_E_onInfo)) VSSystemEvent_EventProc E_onInfo;
#endif

};

class ClassOfDialogClass:public ClassOfObjectBaseClass{
public:
    ClassOfDialogClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDialogClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDialogClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onKey();
    void Put_E_onKey(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onCancel();
    void Put_E_onCancel(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDismiss();
    void Put_E_onDismiss(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onShow();
    void Put_E_onShow(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onKey, put=Put_E_onKey)) VSSystemEvent_EventProc E_onKey;
    __declspec(property(get=Get_E_onCancel, put=Put_E_onCancel)) VSSystemEvent_EventProc E_onCancel;
    __declspec(property(get=Get_E_onDismiss, put=Put_E_onDismiss)) VSSystemEvent_EventProc E_onDismiss;
    __declspec(property(get=Get_E_onShow, put=Put_E_onShow)) VSSystemEvent_EventProc E_onShow;
#endif

};

class ClassOfAlertDialogClass:public ClassOfDialogClass{
public:
    ClassOfAlertDialogClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAlertDialogClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAlertDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAlertDialogClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onMultiChoiceClick();
    void Put_E_onMultiChoiceClick(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onClick();
    void Put_E_onClick(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onMultiChoiceClick, put=Put_E_onMultiChoiceClick)) VSSystemEvent_EventProc E_onMultiChoiceClick;
    __declspec(property(get=Get_E_onClick, put=Put_E_onClick)) VSSystemEvent_EventProc E_onClick;
#endif

};

class ClassOfProgressDialogClass:public ClassOfAlertDialogClass{
public:
    ClassOfProgressDialogClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfProgressDialogClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfProgressDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfProgressDialogClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRectFClass:public ClassOfSRPObject{
public:
    ClassOfRectFClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRectFClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRectFClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRectFClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--Attribute Get/Put Function Define
    VS_FLOAT Get_left();
    void Put_left(VS_FLOAT In_Value);

    VS_FLOAT Get_top();
    void Put_top(VS_FLOAT In_Value);

    VS_FLOAT Get_right();
    void Put_right(VS_FLOAT In_Value);

    VS_FLOAT Get_bottom();
    void Put_bottom(VS_FLOAT In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--Attribute Property Define
    __declspec(property(get=Get_left, put=Put_left)) VS_FLOAT left;
    __declspec(property(get=Get_top, put=Put_top)) VS_FLOAT top;
    __declspec(property(get=Get_right, put=Put_right)) VS_FLOAT right;
    __declspec(property(get=Get_bottom, put=Put_bottom)) VS_FLOAT bottom;
#endif

};

class ClassOfSubMenuClass:public ClassOfObjectBaseClass{
public:
    ClassOfSubMenuClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSubMenuClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSubMenuClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSubMenuClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfVibratorClass:public ClassOfObjectBaseClass{
public:
    ClassOfVibratorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfVibratorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfVibratorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfVibratorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfPathClass:public ClassOfObjectBaseClass{
public:
    ClassOfPathClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfPathClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfPathClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfPathClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfContentObserverClass:public ClassOfObjectBaseClass{
public:
    ClassOfContentObserverClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContentObserverClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContentObserverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContentObserverClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_deliverSelfNotifications(void * In_Value);
    void * Get_F_deliverSelfNotifications();

    void Put_F_onChange(void * In_Value);
    void * Get_F_onChange();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_deliverSelfNotifications, put=Put_F_deliverSelfNotifications)) void * F_deliverSelfNotifications;
    __declspec(property(get=Get_F_onChange, put=Put_F_onChange)) void * F_onChange;
#endif

public:
    //--Function Define
    VS_BOOL SRPAPI deliverSelfNotifications();
    void SRPAPI onChange(VS_BOOL selfChange);
};

class ClassOfBitmapFactoryClass:public ClassOfObjectBaseClass{
public:
    ClassOfBitmapFactoryClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBitmapFactoryClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBitmapFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBitmapFactoryClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTextViewClass:public ClassOfViewClass{
public:
    ClassOfTextViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTextViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTextViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onTextChanged();
    void Put_E_onTextChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_beforeTextChanged();
    void Put_E_beforeTextChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_afterTextChanged();
    void Put_E_afterTextChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onTextChanged, put=Put_E_onTextChanged)) VSSystemEvent_EventProc E_onTextChanged;
    __declspec(property(get=Get_E_beforeTextChanged, put=Put_E_beforeTextChanged)) VSSystemEvent_EventProc E_beforeTextChanged;
    __declspec(property(get=Get_E_afterTextChanged, put=Put_E_afterTextChanged)) VSSystemEvent_EventProc E_afterTextChanged;
#endif

};

class ClassOfDigitalClockClass:public ClassOfTextViewClass{
public:
    ClassOfDigitalClockClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDigitalClockClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDigitalClockClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDigitalClockClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfEditTextClass:public ClassOfTextViewClass{
public:
    ClassOfEditTextClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfEditTextClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfEditTextClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfEditTextClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAutoCompleteTextViewClass:public ClassOfEditTextClass{
public:
    ClassOfAutoCompleteTextViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAutoCompleteTextViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAutoCompleteTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAutoCompleteTextViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfUriClass:public ClassOfObjectBaseClass{
public:
    ClassOfUriClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfUriClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfUriClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfUriClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfOutputStreamClass:public ClassOfObjectBaseClass{
public:
    ClassOfOutputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfOutputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfFileOutputStreamClass:public ClassOfOutputStreamClass{
public:
    ClassOfFileOutputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfFileOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfFileOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfFileOutputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfKeyEventClass:public ClassOfInputEventClass{
public:
    ClassOfKeyEventClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfKeyEventClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfKeyEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfKeyEventClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTimePickerDialogClass:public ClassOfAlertDialogClass{
public:
    ClassOfTimePickerDialogClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTimePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTimePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTimePickerDialogClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onTimeSet();
    void Put_E_onTimeSet(VSSystemEvent_EventProc In_Value);


public:
    //--PubFunction Get/Put Function Define
    void Put_F_onTimeChanged(void * In_Value);
    void * Get_F_onTimeChanged();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onTimeSet, put=Put_E_onTimeSet)) VSSystemEvent_EventProc E_onTimeSet;
#endif

#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onTimeChanged, put=Put_F_onTimeChanged)) void * F_onTimeChanged;
#endif

public:
    //--Function Define
    void SRPAPI onTimeChanged(VS_INT32 hourOfDay,VS_INT32 minute);
};

class ClassOfSmsManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfSmsManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSmsManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSmsManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSmsManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCursorClass:public ClassOfObjectBaseClass{
public:
    ClassOfCursorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCursorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCursorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCursorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfWindowClass:public ClassOfObjectBaseClass{
public:
    ClassOfWindowClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfWindowClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfWindowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfWindowClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMediaPlayerClass:public ClassOfObjectBaseClass{
public:
    ClassOfMediaPlayerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMediaPlayerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMediaPlayerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMediaPlayerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onBufferingUpdate();
    void Put_E_onBufferingUpdate(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onCompletion();
    void Put_E_onCompletion(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onError();
    void Put_E_onError(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onInfo();
    void Put_E_onInfo(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onPrepared();
    void Put_E_onPrepared(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onSeekComplete();
    void Put_E_onSeekComplete(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onVideoSizeChanged();
    void Put_E_onVideoSizeChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onBufferingUpdate, put=Put_E_onBufferingUpdate)) VSSystemEvent_EventProc E_onBufferingUpdate;
    __declspec(property(get=Get_E_onCompletion, put=Put_E_onCompletion)) VSSystemEvent_EventProc E_onCompletion;
    __declspec(property(get=Get_E_onError, put=Put_E_onError)) VSSystemEvent_EventProc E_onError;
    __declspec(property(get=Get_E_onInfo, put=Put_E_onInfo)) VSSystemEvent_EventProc E_onInfo;
    __declspec(property(get=Get_E_onPrepared, put=Put_E_onPrepared)) VSSystemEvent_EventProc E_onPrepared;
    __declspec(property(get=Get_E_onSeekComplete, put=Put_E_onSeekComplete)) VSSystemEvent_EventProc E_onSeekComplete;
    __declspec(property(get=Get_E_onVideoSizeChanged, put=Put_E_onVideoSizeChanged)) VSSystemEvent_EventProc E_onVideoSizeChanged;
#endif

};

class ClassOfContentResolverClass:public ClassOfObjectBaseClass{
public:
    ClassOfContentResolverClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContentResolverClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContentResolverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContentResolverClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfResourcesClass:public ClassOfObjectBaseClass{
public:
    ClassOfResourcesClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfResourcesClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfResourcesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfResourcesClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfFileInputStreamClass:public ClassOfInputStreamClass{
public:
    ClassOfFileInputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfFileInputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfFileInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfFileInputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfEnvironmentClass:public ClassOfObjectBaseClass{
public:
    ClassOfEnvironmentClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfEnvironmentClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfEnvironmentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfEnvironmentClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAndroidInitClass:public ClassOfSRPObject{
public:
    ClassOfAndroidInitClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAndroidInitClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAndroidInitClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAndroidInitClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onInitClass();
    void Put_E_onInitClass(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onInitClass, put=Put_E_onInitClass)) VSSystemEvent_EventProc E_onInitClass;
#endif

};

class ClassOfImageViewClass:public ClassOfViewClass{
public:
    ClassOfImageViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfImageViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfImageViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfImageViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfQuickContactBadgeClass:public ClassOfImageViewClass{
public:
    ClassOfQuickContactBadgeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfQuickContactBadgeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfQuickContactBadgeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfQuickContactBadgeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfImageButtonClass:public ClassOfImageViewClass{
public:
    ClassOfImageButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfImageButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfImageButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfImageButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfZoomButtonClass:public ClassOfImageButtonClass{
public:
    ClassOfZoomButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfZoomButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfZoomButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfZoomButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfByteArrayInputStreamClass:public ClassOfInputStreamClass{
public:
    ClassOfByteArrayInputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfByteArrayInputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfByteArrayInputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfByteArrayInputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSimplePackageManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfSimplePackageManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSimplePackageManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSimplePackageManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSimplePackageManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfNotificationClass:public ClassOfObjectBaseClass{
public:
    ClassOfNotificationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfNotificationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfNotificationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfNotificationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCheckedTextViewClass:public ClassOfTextViewClass{
public:
    ClassOfCheckedTextViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCheckedTextViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCheckedTextViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCheckedTextViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfLayoutInflaterClass:public ClassOfObjectBaseClass{
public:
    ClassOfLayoutInflaterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfLayoutInflaterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfLayoutInflaterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfLayoutInflaterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSweepGradientClass:public ClassOfShaderClass{
public:
    ClassOfSweepGradientClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSweepGradientClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSweepGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSweepGradientClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfMotionEventClass:public ClassOfObjectBaseClass{
public:
    ClassOfMotionEventClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfMotionEventClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfMotionEventClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfMotionEventClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAssetFileDescriptorClass:public ClassOfFileDescriptorClass{
public:
    ClassOfAssetFileDescriptorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAssetFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAssetFileDescriptorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAssetFileDescriptorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfWebSettingsClass:public ClassOfObjectBaseClass{
public:
    ClassOfWebSettingsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfWebSettingsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfWebSettingsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfWebSettingsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfColorStateListClass:public ClassOfObjectBaseClass{
public:
    ClassOfColorStateListClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfColorStateListClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfColorStateListClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfColorStateListClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfBaseAdapterClass:public ClassOfObjectBaseClass{
public:
    ClassOfBaseAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBaseAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBaseAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBaseAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onCreateAndroid(void * In_Value);
    void * Get_F_onCreateAndroid();

    void Put_F_getCount(void * In_Value);
    void * Get_F_getCount();

    void Put_F_getItem(void * In_Value);
    void * Get_F_getItem();

    void Put_F_getItemId(void * In_Value);
    void * Get_F_getItemId();

    void Put_F_getViewTypeCount(void * In_Value);
    void * Get_F_getViewTypeCount();

    void Put_F_getItemViewType(void * In_Value);
    void * Get_F_getItemViewType();

    void Put_F_getView(void * In_Value);
    void * Get_F_getView();

    void Put_F_isEmpty(void * In_Value);
    void * Get_F_isEmpty();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onCreateAndroid, put=Put_F_onCreateAndroid)) void * F_onCreateAndroid;
    __declspec(property(get=Get_F_getCount, put=Put_F_getCount)) void * F_getCount;
    __declspec(property(get=Get_F_getItem, put=Put_F_getItem)) void * F_getItem;
    __declspec(property(get=Get_F_getItemId, put=Put_F_getItemId)) void * F_getItemId;
    __declspec(property(get=Get_F_getViewTypeCount, put=Put_F_getViewTypeCount)) void * F_getViewTypeCount;
    __declspec(property(get=Get_F_getItemViewType, put=Put_F_getItemViewType)) void * F_getItemViewType;
    __declspec(property(get=Get_F_getView, put=Put_F_getView)) void * F_getView;
    __declspec(property(get=Get_F_isEmpty, put=Put_F_isEmpty)) void * F_isEmpty;
#endif

public:
    //--Function Define
    void SRPAPI onCreateAndroid();
    VS_INT32 SRPAPI getCount();
    VS_INT32 SRPAPI getItem(VS_INT32 position);
    VS_LONG SRPAPI getItemId(VS_INT32 position);
    VS_INT32 SRPAPI getViewTypeCount();
    VS_INT32 SRPAPI getItemViewType(VS_INT32 position);
    VS_OBJPTR SRPAPI getView(VS_INT32 position,VS_OBJPTR convertView,VS_OBJPTR parent);
    VS_BOOL SRPAPI isEmpty();
};

class ClassOfSimpleAdapterClass:public ClassOfBaseAdapterClass{
public:
    ClassOfSimpleAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSimpleAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCursorAdapterClass:public ClassOfBaseAdapterClass{
public:
    ClassOfCursorAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCursorAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_bindView(void * In_Value);
    void * Get_F_bindView();

    void Put_F_newView(void * In_Value);
    void * Get_F_newView();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_bindView, put=Put_F_bindView)) void * F_bindView;
    __declspec(property(get=Get_F_newView, put=Put_F_newView)) void * F_newView;
#endif

public:
    //--Function Define
    void SRPAPI bindView(VS_OBJPTR view,VS_OBJPTR cursor);
    VS_OBJPTR SRPAPI newView(VS_OBJPTR cursor,VS_OBJPTR parent);
};

class ClassOfStringArrayAdapterClass:public ClassOfBaseAdapterClass{
public:
    ClassOfStringArrayAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfStringArrayAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfStringArrayAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfStringArrayAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_getView(void * In_Value);
    void * Get_F_getView();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_getView, put=Put_F_getView)) void * F_getView;
#endif

public:
    //--Function Define
    VS_OBJPTR SRPAPI getView(VS_INT32 Position,VS_OBJPTR convertView,VS_OBJPTR parent);
};

class ClassOfSensorManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfSensorManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSensorManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSensorManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSensorManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onAccuracyChanged();
    void Put_E_onAccuracyChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onSensorChanged();
    void Put_E_onSensorChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onAccuracyChanged, put=Put_E_onAccuracyChanged)) VSSystemEvent_EventProc E_onAccuracyChanged;
    __declspec(property(get=Get_E_onSensorChanged, put=Put_E_onSensorChanged)) VSSystemEvent_EventProc E_onSensorChanged;
#endif

};

class ClassOfDrawableClass:public ClassOfObjectBaseClass{
public:
    ClassOfDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfDrawableContainerClass:public ClassOfDrawableClass{
public:
    ClassOfDrawableContainerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDrawableContainerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDrawableContainerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDrawableContainerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfStateListDrawableClass:public ClassOfDrawableContainerClass{
public:
    ClassOfStateListDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfStateListDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfStateListDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfStateListDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfColorDrawableClass:public ClassOfDrawableClass{
public:
    ClassOfColorDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfColorDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfColorDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfColorDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfBitmapDrawableClass:public ClassOfDrawableClass{
public:
    ClassOfBitmapDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBitmapDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBitmapDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBitmapDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfShapeDrawableClass:public ClassOfDrawableClass{
public:
    ClassOfShapeDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfShapeDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfShapeDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfShapeDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfLayerDrawableClass:public ClassOfDrawableClass{
public:
    ClassOfLayerDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfLayerDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfLayerDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfLayerDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTransitionDrawableClass:public ClassOfLayerDrawableClass{
public:
    ClassOfTransitionDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTransitionDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTransitionDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTransitionDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfViewGroupClass:public ClassOfViewClass{
public:
    ClassOfViewGroupClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewGroupClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewGroupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewGroupClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onInterceptTouchEvent(void * In_Value);
    void * Get_F_onInterceptTouchEvent();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onInterceptTouchEvent, put=Put_F_onInterceptTouchEvent)) void * F_onInterceptTouchEvent;
#endif

public:
    //--Function Define
    VS_BOOL SRPAPI onInterceptTouchEvent(VS_OBJPTR event);
};

class ClassOfRelativeLayoutClass:public ClassOfViewGroupClass{
public:
    ClassOfRelativeLayoutClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRelativeLayoutClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRelativeLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRelativeLayoutClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAbsoluteLayoutClass:public ClassOfViewGroupClass{
public:
    ClassOfAbsoluteLayoutClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAbsoluteLayoutClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAbsoluteLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAbsoluteLayoutClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfLinearLayoutClass:public ClassOfViewGroupClass{
public:
    ClassOfLinearLayoutClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfLinearLayoutClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfLinearLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfLinearLayoutClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTableRowClass:public ClassOfLinearLayoutClass{
public:
    ClassOfTableRowClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTableRowClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTableRowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTableRowClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTableLayoutClass:public ClassOfLinearLayoutClass{
public:
    ClassOfTableLayoutClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTableLayoutClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTableLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTableLayoutClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRadioGroupClass:public ClassOfLinearLayoutClass{
public:
    ClassOfRadioGroupClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRadioGroupClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRadioGroupClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRadioGroupClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onCheckedChanged();
    void Put_E_onCheckedChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onChildViewAdded();
    void Put_E_onChildViewAdded(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onChildViewRemoved();
    void Put_E_onChildViewRemoved(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onCheckedChanged, put=Put_E_onCheckedChanged)) VSSystemEvent_EventProc E_onCheckedChanged;
    __declspec(property(get=Get_E_onChildViewAdded, put=Put_E_onChildViewAdded)) VSSystemEvent_EventProc E_onChildViewAdded;
    __declspec(property(get=Get_E_onChildViewRemoved, put=Put_E_onChildViewRemoved)) VSSystemEvent_EventProc E_onChildViewRemoved;
#endif

};

class ClassOfSlidingDrawerClass:public ClassOfViewGroupClass{
public:
    ClassOfSlidingDrawerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSlidingDrawerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSlidingDrawerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSlidingDrawerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onDrawerClosed();
    void Put_E_onDrawerClosed(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDrawerOpened();
    void Put_E_onDrawerOpened(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onScrollEnded();
    void Put_E_onScrollEnded(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onScrollStarted();
    void Put_E_onScrollStarted(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onDrawerClosed, put=Put_E_onDrawerClosed)) VSSystemEvent_EventProc E_onDrawerClosed;
    __declspec(property(get=Get_E_onDrawerOpened, put=Put_E_onDrawerOpened)) VSSystemEvent_EventProc E_onDrawerOpened;
    __declspec(property(get=Get_E_onScrollEnded, put=Put_E_onScrollEnded)) VSSystemEvent_EventProc E_onScrollEnded;
    __declspec(property(get=Get_E_onScrollStarted, put=Put_E_onScrollStarted)) VSSystemEvent_EventProc E_onScrollStarted;
#endif

};

class ClassOfFrameLayoutClass:public ClassOfViewGroupClass{
public:
    ClassOfFrameLayoutClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfFrameLayoutClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfFrameLayoutClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfFrameLayoutClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfScrollViewClass:public ClassOfFrameLayoutClass{
public:
    ClassOfScrollViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfScrollViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfScrollViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfScrollViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTimePickerClass:public ClassOfFrameLayoutClass{
public:
    ClassOfTimePickerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTimePickerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTimePickerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTimePickerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onTimeChanged();
    void Put_E_onTimeChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onTimeChanged, put=Put_E_onTimeChanged)) VSSystemEvent_EventProc E_onTimeChanged;
#endif

};

class ClassOfDatePickerClass:public ClassOfFrameLayoutClass{
public:
    ClassOfDatePickerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDatePickerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDatePickerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDatePickerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onDateChanged();
    void Put_E_onDateChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onDateChanged, put=Put_E_onDateChanged)) VSSystemEvent_EventProc E_onDateChanged;
#endif

};

class ClassOfViewAnimatorClass:public ClassOfFrameLayoutClass{
public:
    ClassOfViewAnimatorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewAnimatorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewAnimatorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewAnimatorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfViewSwitcherClass:public ClassOfViewAnimatorClass{
public:
    ClassOfViewSwitcherClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewSwitcherClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewSwitcherClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTextSwitcherClass:public ClassOfViewSwitcherClass{
public:
    ClassOfTextSwitcherClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTextSwitcherClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTextSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTextSwitcherClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfViewFlipperClass:public ClassOfViewAnimatorClass{
public:
    ClassOfViewFlipperClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewFlipperClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewFlipperClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewFlipperClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTabHostClass:public ClassOfFrameLayoutClass{
public:
    ClassOfTabHostClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTabHostClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTabHostClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTabHostClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onTabChanged();
    void Put_E_onTabChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onTabChanged, put=Put_E_onTabChanged)) VSSystemEvent_EventProc E_onTabChanged;
#endif

};

class ClassOfImageSwitcherClass:public ClassOfViewSwitcherClass{
public:
    ClassOfImageSwitcherClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfImageSwitcherClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfImageSwitcherClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfImageSwitcherClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAnimationUtilsClass:public ClassOfObjectBaseClass{
public:
    ClassOfAnimationUtilsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAnimationUtilsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAnimationUtilsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAnimationUtilsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSoundPoolClass:public ClassOfObjectBaseClass{
public:
    ClassOfSoundPoolClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSoundPoolClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSoundPoolClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSoundPoolClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTwoLineListItemClass:public ClassOfRelativeLayoutClass{
public:
    ClassOfTwoLineListItemClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTwoLineListItemClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTwoLineListItemClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTwoLineListItemClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfDatePickerDialogClass:public ClassOfAlertDialogClass{
public:
    ClassOfDatePickerDialogClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDatePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDatePickerDialogClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDatePickerDialogClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onDateSet();
    void Put_E_onDateSet(VSSystemEvent_EventProc In_Value);


public:
    //--PubFunction Get/Put Function Define
    void Put_F_onDateChanged(void * In_Value);
    void * Get_F_onDateChanged();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onDateSet, put=Put_E_onDateSet)) VSSystemEvent_EventProc E_onDateSet;
#endif

#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onDateChanged, put=Put_F_onDateChanged)) void * F_onDateChanged;
#endif

public:
    //--Function Define
    void SRPAPI onDateChanged(VS_INT32 onDateChanged,VS_INT32 month,VS_INT32 day);
};

class ClassOfSensorClass:public ClassOfObjectBaseClass{
public:
    ClassOfSensorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSensorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSensorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSensorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfPendingIntentClass:public ClassOfObjectBaseClass{
public:
    ClassOfPendingIntentClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfPendingIntentClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfPendingIntentClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfPendingIntentClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onSendFinished();
    void Put_E_onSendFinished(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onSendFinished, put=Put_E_onSendFinished)) VSSystemEvent_EventProc E_onSendFinished;
#endif

};

class ClassOfSharedPreferencesClass:public ClassOfObjectBaseClass{
public:
    ClassOfSharedPreferencesClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSharedPreferencesClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSharedPreferencesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSharedPreferencesClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAnimationDrawableClass:public ClassOfDrawableContainerClass{
public:
    ClassOfAnimationDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAnimationDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAnimationDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAnimationDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfHorizontalScrollViewClass:public ClassOfFrameLayoutClass{
public:
    ClassOfHorizontalScrollViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfHorizontalScrollViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfHorizontalScrollViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfHorizontalScrollViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAbsSeekBarClass:public ClassOfProgressBarClass{
public:
    ClassOfAbsSeekBarClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAbsSeekBarClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAbsSeekBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAbsSeekBarClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSeekBarClass:public ClassOfAbsSeekBarClass{
public:
    ClassOfSeekBarClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSeekBarClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSeekBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSeekBarClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onProgressChanged();
    void Put_E_onProgressChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onStartTrackingTouch();
    void Put_E_onStartTrackingTouch(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onStopTrackingTouch();
    void Put_E_onStopTrackingTouch(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onProgressChanged, put=Put_E_onProgressChanged)) VSSystemEvent_EventProc E_onProgressChanged;
    __declspec(property(get=Get_E_onStartTrackingTouch, put=Put_E_onStartTrackingTouch)) VSSystemEvent_EventProc E_onStartTrackingTouch;
    __declspec(property(get=Get_E_onStopTrackingTouch, put=Put_E_onStopTrackingTouch)) VSSystemEvent_EventProc E_onStopTrackingTouch;
#endif

};

class ClassOfRatingBarClass:public ClassOfAbsSeekBarClass{
public:
    ClassOfRatingBarClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRatingBarClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRatingBarClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRatingBarClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onRatingChanged();
    void Put_E_onRatingChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onRatingChanged, put=Put_E_onRatingChanged)) VSSystemEvent_EventProc E_onRatingChanged;
#endif

};

class ClassOfPopupWindowClass:public ClassOfObjectBaseClass{
public:
    ClassOfPopupWindowClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfPopupWindowClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfPopupWindowClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfPopupWindowClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onDismiss();
    void Put_E_onDismiss(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onDismiss, put=Put_E_onDismiss)) VSSystemEvent_EventProc E_onDismiss;
#endif

};

class ClassOfButtonClass:public ClassOfTextViewClass{
public:
    ClassOfButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCompoundButtonClass:public ClassOfButtonClass{
public:
    ClassOfCompoundButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCompoundButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCompoundButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCompoundButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onCheckedChanged();
    void Put_E_onCheckedChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onCheckedChanged, put=Put_E_onCheckedChanged)) VSSystemEvent_EventProc E_onCheckedChanged;
#endif

};

class ClassOfToggleButtonClass:public ClassOfCompoundButtonClass{
public:
    ClassOfToggleButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfToggleButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfToggleButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfToggleButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRadioButtonClass:public ClassOfCompoundButtonClass{
public:
    ClassOfRadioButtonClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRadioButtonClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRadioButtonClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRadioButtonClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCheckBoxClass:public ClassOfCompoundButtonClass{
public:
    ClassOfCheckBoxClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCheckBoxClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCheckBoxClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCheckBoxClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfGradientDrawableClass:public ClassOfDrawableClass{
public:
    ClassOfGradientDrawableClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfGradientDrawableClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfGradientDrawableClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfGradientDrawableClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfAdapterViewClass:public ClassOfViewGroupClass{
public:
    ClassOfAdapterViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAdapterViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAdapterViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAdapterViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onItemClick();
    void Put_E_onItemClick(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onItemLongClick();
    void Put_E_onItemLongClick(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onItemSelected();
    void Put_E_onItemSelected(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onNothingSelected();
    void Put_E_onNothingSelected(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onItemClick, put=Put_E_onItemClick)) VSSystemEvent_EventProc E_onItemClick;
    __declspec(property(get=Get_E_onItemLongClick, put=Put_E_onItemLongClick)) VSSystemEvent_EventProc E_onItemLongClick;
    __declspec(property(get=Get_E_onItemSelected, put=Put_E_onItemSelected)) VSSystemEvent_EventProc E_onItemSelected;
    __declspec(property(get=Get_E_onNothingSelected, put=Put_E_onNothingSelected)) VSSystemEvent_EventProc E_onNothingSelected;
#endif

};

class ClassOfAbsSpinnerClass:public ClassOfAdapterViewClass{
public:
    ClassOfAbsSpinnerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAbsSpinnerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAbsSpinnerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAbsSpinnerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSpinnerClass:public ClassOfAbsSpinnerClass{
public:
    ClassOfSpinnerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSpinnerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSpinnerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSpinnerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfGalleryClass:public ClassOfAbsSpinnerClass{
public:
    ClassOfGalleryClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfGalleryClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfGalleryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfGalleryClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onDown(void * In_Value);
    void * Get_F_onDown();

    void Put_F_onFling(void * In_Value);
    void * Get_F_onFling();

    void Put_F_onLongPress(void * In_Value);
    void * Get_F_onLongPress();

    void Put_F_onScroll(void * In_Value);
    void * Get_F_onScroll();

    void Put_F_onShowPress(void * In_Value);
    void * Get_F_onShowPress();

    void Put_F_onSingleTapUp(void * In_Value);
    void * Get_F_onSingleTapUp();

    void Put_F_onTouchEvent(void * In_Value);
    void * Get_F_onTouchEvent();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onDown, put=Put_F_onDown)) void * F_onDown;
    __declspec(property(get=Get_F_onFling, put=Put_F_onFling)) void * F_onFling;
    __declspec(property(get=Get_F_onLongPress, put=Put_F_onLongPress)) void * F_onLongPress;
    __declspec(property(get=Get_F_onScroll, put=Put_F_onScroll)) void * F_onScroll;
    __declspec(property(get=Get_F_onShowPress, put=Put_F_onShowPress)) void * F_onShowPress;
    __declspec(property(get=Get_F_onSingleTapUp, put=Put_F_onSingleTapUp)) void * F_onSingleTapUp;
    __declspec(property(get=Get_F_onTouchEvent, put=Put_F_onTouchEvent)) void * F_onTouchEvent;
#endif

public:
    //--Function Define
    VS_BOOL SRPAPI onDown(VS_OBJPTR e);
    VS_BOOL SRPAPI onFling(VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT velocityX,VS_FLOAT velocityY);
    VS_BOOL SRPAPI onLongPress(VS_OBJPTR e);
    VS_BOOL SRPAPI onScroll(VS_OBJPTR e1,VS_OBJPTR e2,VS_FLOAT distanceX,VS_FLOAT distanceY);
    void SRPAPI onShowPress(VS_OBJPTR e);
    VS_BOOL SRPAPI onSingleTapUp(VS_OBJPTR e);
    VS_BOOL SRPAPI onTouchEvent(VS_OBJPTR event);
};

class ClassOfAbsListViewClass:public ClassOfAdapterViewClass{
public:
    ClassOfAbsListViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfAbsListViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfAbsListViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfAbsListViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onScroll();
    void Put_E_onScroll(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onScrollStateChanged();
    void Put_E_onScrollStateChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onMovedToScrapHeap();
    void Put_E_onMovedToScrapHeap(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onScroll, put=Put_E_onScroll)) VSSystemEvent_EventProc E_onScroll;
    __declspec(property(get=Get_E_onScrollStateChanged, put=Put_E_onScrollStateChanged)) VSSystemEvent_EventProc E_onScrollStateChanged;
    __declspec(property(get=Get_E_onMovedToScrapHeap, put=Put_E_onMovedToScrapHeap)) VSSystemEvent_EventProc E_onMovedToScrapHeap;
#endif

};

class ClassOfListViewClass:public ClassOfAbsListViewClass{
public:
    ClassOfListViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfListViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfListViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfListViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfGridViewClass:public ClassOfAbsListViewClass{
public:
    ClassOfGridViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfGridViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfGridViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfGridViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfByteArrayOutputStreamClass:public ClassOfOutputStreamClass{
public:
    ClassOfByteArrayOutputStreamClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfByteArrayOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfByteArrayOutputStreamClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfByteArrayOutputStreamClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfDisplayMetricsClass:public ClassOfObjectBaseClass{
public:
    ClassOfDisplayMetricsClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDisplayMetricsClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDisplayMetricsClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDisplayMetricsClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfTelephonyManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfTelephonyManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfTelephonyManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfTelephonyManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfTelephonyManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onCallForwardingIndicatorChanged();
    void Put_E_onCallForwardingIndicatorChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onCallStateChanged();
    void Put_E_onCallStateChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onCellLocationChanged();
    void Put_E_onCellLocationChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDataActivity();
    void Put_E_onDataActivity(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onDataConnectionStateChanged();
    void Put_E_onDataConnectionStateChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onMessageWaitingIndicatorChanged();
    void Put_E_onMessageWaitingIndicatorChanged(VSSystemEvent_EventProc In_Value);

    VSSystemEvent_EventProc Get_E_onSignalStrengthChanged();
    void Put_E_onSignalStrengthChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onCallForwardingIndicatorChanged, put=Put_E_onCallForwardingIndicatorChanged)) VSSystemEvent_EventProc E_onCallForwardingIndicatorChanged;
    __declspec(property(get=Get_E_onCallStateChanged, put=Put_E_onCallStateChanged)) VSSystemEvent_EventProc E_onCallStateChanged;
    __declspec(property(get=Get_E_onCellLocationChanged, put=Put_E_onCellLocationChanged)) VSSystemEvent_EventProc E_onCellLocationChanged;
    __declspec(property(get=Get_E_onDataActivity, put=Put_E_onDataActivity)) VSSystemEvent_EventProc E_onDataActivity;
    __declspec(property(get=Get_E_onDataConnectionStateChanged, put=Put_E_onDataConnectionStateChanged)) VSSystemEvent_EventProc E_onDataConnectionStateChanged;
    __declspec(property(get=Get_E_onMessageWaitingIndicatorChanged, put=Put_E_onMessageWaitingIndicatorChanged)) VSSystemEvent_EventProc E_onMessageWaitingIndicatorChanged;
    __declspec(property(get=Get_E_onSignalStrengthChanged, put=Put_E_onSignalStrengthChanged)) VSSystemEvent_EventProc E_onSignalStrengthChanged;
#endif

};

class ClassOfCdmaCellLocationClass:public ClassOfCellLocationClass{
public:
    ClassOfCdmaCellLocationClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCdmaCellLocationClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCdmaCellLocationClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCdmaCellLocationClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfEditorClass:public ClassOfObjectBaseClass{
public:
    ClassOfEditorClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfEditorClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfEditorClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfEditorClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfViewFactoryClass:public ClassOfObjectBaseClass{
public:
    ClassOfViewFactoryClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfViewFactoryClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfViewFactoryClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfViewFactoryClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_makeView(void * In_Value);
    void * Get_F_makeView();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_makeView, put=Put_F_makeView)) void * F_makeView;
#endif

public:
    //--Function Define
    VS_OBJPTR SRPAPI makeView();
};

class ClassOfInputMethodManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfInputMethodManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfInputMethodManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfInputMethodManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfInputMethodManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRadialGradientClass:public ClassOfShaderClass{
public:
    ClassOfRadialGradientClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRadialGradientClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRadialGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRadialGradientClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfStarSimpleAdapterClass:public ClassOfBaseAdapterClass{
public:
    ClassOfStarSimpleAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfStarSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfStarSimpleAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfStarSimpleAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfWebViewClientClass:public ClassOfObjectBaseClass{
public:
    ClassOfWebViewClientClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfWebViewClientClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfWebViewClientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfWebViewClientClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_doUpdateVisitedHistory(void * In_Value);
    void * Get_F_doUpdateVisitedHistory();

    void Put_F_onLoadResource(void * In_Value);
    void * Get_F_onLoadResource();

    void Put_F_onPageFinished(void * In_Value);
    void * Get_F_onPageFinished();

    void Put_F_onPageStarted(void * In_Value);
    void * Get_F_onPageStarted();

    void Put_F_onReceivedError(void * In_Value);
    void * Get_F_onReceivedError();

    void Put_F_onReceivedLoginRequest(void * In_Value);
    void * Get_F_onReceivedLoginRequest();

    void Put_F_onScaleChanged(void * In_Value);
    void * Get_F_onScaleChanged();

    void Put_F_onUnhandledKeyEvent(void * In_Value);
    void * Get_F_onUnhandledKeyEvent();

    void Put_F_shouldOverrideKeyEvent(void * In_Value);
    void * Get_F_shouldOverrideKeyEvent();

    void Put_F_shouldOverrideUrlLoading(void * In_Value);
    void * Get_F_shouldOverrideUrlLoading();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_doUpdateVisitedHistory, put=Put_F_doUpdateVisitedHistory)) void * F_doUpdateVisitedHistory;
    __declspec(property(get=Get_F_onLoadResource, put=Put_F_onLoadResource)) void * F_onLoadResource;
    __declspec(property(get=Get_F_onPageFinished, put=Put_F_onPageFinished)) void * F_onPageFinished;
    __declspec(property(get=Get_F_onPageStarted, put=Put_F_onPageStarted)) void * F_onPageStarted;
    __declspec(property(get=Get_F_onReceivedError, put=Put_F_onReceivedError)) void * F_onReceivedError;
    __declspec(property(get=Get_F_onReceivedLoginRequest, put=Put_F_onReceivedLoginRequest)) void * F_onReceivedLoginRequest;
    __declspec(property(get=Get_F_onScaleChanged, put=Put_F_onScaleChanged)) void * F_onScaleChanged;
    __declspec(property(get=Get_F_onUnhandledKeyEvent, put=Put_F_onUnhandledKeyEvent)) void * F_onUnhandledKeyEvent;
    __declspec(property(get=Get_F_shouldOverrideKeyEvent, put=Put_F_shouldOverrideKeyEvent)) void * F_shouldOverrideKeyEvent;
    __declspec(property(get=Get_F_shouldOverrideUrlLoading, put=Put_F_shouldOverrideUrlLoading)) void * F_shouldOverrideUrlLoading;
#endif

public:
    //--Function Define
    void SRPAPI doUpdateVisitedHistory(VS_OBJPTR view,VS_CHAR * url,VS_BOOL isReload);
    void SRPAPI onLoadResource(VS_OBJPTR view,VS_CHAR * url);
    void SRPAPI onPageFinished(VS_OBJPTR view,VS_CHAR * url);
    void SRPAPI onPageStarted(VS_OBJPTR view,VS_CHAR * url,VS_OBJPTR favicon);
    void SRPAPI onReceivedError(VS_OBJPTR view,VS_INT32 errorCode,VS_CHAR * description,VS_CHAR * failingUrl);
    void SRPAPI onReceivedLoginRequest(VS_OBJPTR view,VS_CHAR * realm,VS_CHAR * account,VS_CHAR * args);
    void SRPAPI onScaleChanged(VS_OBJPTR view,VS_FLOAT oldScale,VS_FLOAT newScale);
    void SRPAPI onUnhandledKeyEvent(VS_OBJPTR view,VS_OBJPTR event);
    VS_BOOL SRPAPI shouldOverrideKeyEvent(VS_OBJPTR view,VS_OBJPTR event);
    VS_BOOL SRPAPI shouldOverrideUrlLoading(VS_OBJPTR view,VS_CHAR * url);
};

class ClassOfRectShapeClass:public ClassOfShapeClass{
public:
    ClassOfRectShapeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRectShapeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRectShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRectShapeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfOvalShapeClass:public ClassOfRectShapeClass{
public:
    ClassOfOvalShapeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfOvalShapeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfOvalShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfOvalShapeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfRoundRectShapeClass:public ClassOfRectShapeClass{
public:
    ClassOfRoundRectShapeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfRoundRectShapeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfRoundRectShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfRoundRectShapeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfArcShapeClass:public ClassOfRectShapeClass{
public:
    ClassOfArcShapeClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfArcShapeClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfArcShapeClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfArcShapeClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfBundleClass:public ClassOfObjectBaseClass{
public:
    ClassOfBundleClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfBundleClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfBundleClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfBundleClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfStringHashMapClass:public ClassOfObjectBaseClass{
public:
    ClassOfStringHashMapClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfStringHashMapClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfStringHashMapClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfStringHashMapClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfLinearGradientClass:public ClassOfShaderClass{
public:
    ClassOfLinearGradientClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfLinearGradientClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfLinearGradientClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfLinearGradientClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfWebViewClass:public ClassOfAbsoluteLayoutClass{
public:
    ClassOfWebViewClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfWebViewClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfWebViewClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfWebViewClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--OutEvent Get/Put Function Define
    VSSystemEvent_EventProc Get_E_onProgressChanged();
    void Put_E_onProgressChanged(VSSystemEvent_EventProc In_Value);


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--OutEvent Property Define
    __declspec(property(get=Get_E_onProgressChanged, put=Put_E_onProgressChanged)) VSSystemEvent_EventProc E_onProgressChanged;
#endif

};

class ClassOfCommonDataKinds_EmailClass:public ClassOfObjectBaseClass{
public:
    ClassOfCommonDataKinds_EmailClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCommonDataKinds_EmailClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCommonDataKinds_EmailClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCommonDataKinds_EmailClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfCanvasClass:public ClassOfObjectBaseClass{
public:
    ClassOfCanvasClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfCanvasClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfCanvasClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfCanvasClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfDataSetObserverClass:public ClassOfObjectBaseClass{
public:
    ClassOfDataSetObserverClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfDataSetObserverClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfDataSetObserverClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfDataSetObserverClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
public:
    //--PubFunction Get/Put Function Define
    void Put_F_onChanged(void * In_Value);
    void * Get_F_onChanged();

    void Put_F_onInvalidated(void * In_Value);
    void * Get_F_onInvalidated();


#if( VS_OS_TYPE == VS_OS_WINDOW )
public:
    //--PubFunction Property Define
    __declspec(property(get=Get_F_onChanged, put=Put_F_onChanged)) void * F_onChanged;
    __declspec(property(get=Get_F_onInvalidated, put=Put_F_onInvalidated)) void * F_onInvalidated;
#endif

public:
    //--Function Define
    void SRPAPI onChanged();
    void SRPAPI onInvalidated();
};

class ClassOfResourceCursorAdapterClass:public ClassOfCursorAdapterClass{
public:
    ClassOfResourceCursorAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfResourceCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfResourceCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfResourceCursorAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfSimpleCursorAdapterClass:public ClassOfResourceCursorAdapterClass{
public:
    ClassOfSimpleCursorAdapterClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfSimpleCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfSimpleCursorAdapterClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfSimpleCursorAdapterClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfIBinderClass:public ClassOfObjectBaseClass{
public:
    ClassOfIBinderClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfIBinderClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfIBinderClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfIBinderClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfConnectivityManagerClass:public ClassOfObjectBaseClass{
public:
    ClassOfConnectivityManagerClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfConnectivityManagerClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfConnectivityManagerClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfConnectivityManagerClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

class ClassOfContentValuesClass:public ClassOfObjectBaseClass{
public:
    ClassOfContentValuesClass();  //--Not Create a Class Object, Use WrapObject() to attach 
    ClassOfContentValuesClass(class ClassOfSRPInterface *In_SRPInterface);  //--Create a Class Object
    ClassOfContentValuesClass(class ClassOfSRPInterface *In_SRPInterface,void *SRPObject);  //--Create a Class Object and wrap SRPObject
    virtual VS_CHAR *SRPAPI GetSelfName();
    static class ClassOfContentValuesClass *SRPAPI GetSRPWrap( class ClassOfSRPInterface *In_SRPInterface,void *SRPObject,VS_ULONG In_ClassLayer = 0xFFFFFFFF);
};

/*--------------------------------------------------*/

#pragma pack()

#endif

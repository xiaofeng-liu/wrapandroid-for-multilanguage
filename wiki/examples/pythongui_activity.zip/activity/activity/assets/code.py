SrvGroup = libstarpy._GetSrvGroup()
Service = SrvGroup._GetService("","")

#--get activity
StarActivity = Service.ActivityClass.getCurrent();

#--button        
myEdit = StarActivity.findViewById("EditTextClass",StarActivity.getResource("id/widget38"));
myButton = StarActivity.findViewById("ButtonClass",StarActivity.getResource("id/widget39"));
def myButton_onClick(self, Ev) :
    MyIntent = Service.IntentClass._New(); 
    MyIntent.setClassName("ChildActivity");
    MyIntent.putStringExtra("value",myEdit.getText());
    StarActivity.startActivityForResult(MyIntent,1);
    MyIntent._Free();
    return;
myButton.onClick = myButton_onClick; 
myButton.setOnClickListener(); 

#--receive result
myText = StarActivity.findViewById("EditTextClass",StarActivity.getResource("id/widget42"));
myText.setTextColor(0xFFFF0000)
def StarActivity_onActivityResult(self,requestCode, resultCode, data) :
    print( requestCode, resultCode, data )
    if( requestCode == 1 and data != None ) :
        myText.setText(data.getStringExtra("value"))
StarActivity.onActivityResult = StarActivity_onActivityResult; 

def StarActivity_onSaveInstanceState(self,savedInstanceState) :
    print("StarActivity onSaveInstanceState......")
StarActivity.onSaveInstanceState = StarActivity_onSaveInstanceState 

def StarActivity_onRestoreInstanceState(self,savedInstanceState) :
    print("StarActivity onRestoreInstanceState......")
StarActivity.onRestoreInstanceState = StarActivity_onRestoreInstanceState 

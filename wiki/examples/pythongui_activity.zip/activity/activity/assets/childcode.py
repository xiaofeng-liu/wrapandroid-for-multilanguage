SrvGroup = libstarpy._GetSrvGroup()
Service = SrvGroup._GetService("","")

#--get activity, global python name space
ChildStarActivity = Service.ActivityClass.getCurrent();

#--button     
child_intent = ChildStarActivity.getIntent();   
ChildText = ChildStarActivity.findViewById("TextViewClass",ChildStarActivity.getResource("id/widget33"));
ChildText.setText(child_intent.getStringExtra("value"))
ChildText.setTextColor(0xFFFF0000)

childEdit = ChildStarActivity.findViewById("EditTextClass",ChildStarActivity.getResource("id/widget36"));
childButton = ChildStarActivity.findViewById("ButtonClass",ChildStarActivity.getResource("id/widget37"));

def childButton_onClick(self, Ev) :
    MyIntent = Service.IntentClass._New(); 
    MyIntent.putStringExtra("value",childEdit.getText());
    ChildStarActivity.setResult1(0,MyIntent);
    MyIntent._Free();
    ChildStarActivity.finish();
    return;
childButton.onClick = childButton_onClick; 
childButton.setOnClickListener(); 

#--Activity lifecycle
def ChildStarActivity_onStart(self) :
    print("ChildStarActivity onStart......")
ChildStarActivity.onStart = ChildStarActivity_onStart    
       
def ChildStarActivity_onStop(self) :
    print("ChildStarActivity onStop......")
ChildStarActivity.onStop = ChildStarActivity_onStop 

def ChildStarActivity_onPause(self) :
    print("ChildStarActivity onPause......")
ChildStarActivity.onPause = ChildStarActivity_onPause 

def ChildStarActivity_onResume(self) :
    print("ChildStarActivity onResume......")
ChildStarActivity.onResume = ChildStarActivity_onResume 

def ChildStarActivity_onDestroy(self) :
    print("ChildStarActivity onDestroy......")
ChildStarActivity.onDestroy = ChildStarActivity_onDestroy 

def ChildStarActivity_onKeyDown(self,keyCode,event) :
    if( keyCode == Service.AndroidConstantClass.getInt("KeyEvent","KEYCODE_BACK") ) :
        MyIntent = Service.IntentClass._New(); 
        MyIntent.putStringExtra("value","press key back");
        ChildStarActivity.setResult1(0,MyIntent);
        MyIntent._Free();
        ChildStarActivity.finish();   
        return True,True; 
ChildStarActivity.onKeyDown = ChildStarActivity_onKeyDown

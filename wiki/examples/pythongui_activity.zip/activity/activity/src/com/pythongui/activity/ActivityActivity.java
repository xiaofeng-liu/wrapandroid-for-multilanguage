package com.pythongui.activity;

import android.app.Activity;
import android.os.Bundle;

import com.srplab.wrapandroid.*;

public class ActivityActivity extends WrapAndroidActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        StarActivity._Call("DoAssetsFile", "python", "code.py");
    }
}
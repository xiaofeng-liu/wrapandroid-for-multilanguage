package com.pythongui.activity;

import android.os.Bundle;
import com.srplab.wrapandroid.*;

public class ChildActivity extends WrapAndroidActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.child);
        StarActivity._Call("DoAssetsFile", "python", "childcode.py");
    }           
}